"""Synthetic Indian retail-banking transaction generator with labelled fraud.

No real customer data is used anywhere in development or testing. Fraud is
injected using realistic typologies so the model, rules and dashboards can be
exercised end to end:

  ATO          new device, night-time, large transfer to a new beneficiary
  CARD_TEST    burst of tiny card authorisations, then a large one
  MULE         many accounts paying one beneficiary, which forwards the money out
  STRUCTURING  repeated cash deposits just under the ₹10 lakh CTR threshold
  IMPOSSIBLE   transactions from cities thousands of km apart within minutes

Usage:
  python data/generate_synthetic.py --customers 2000 --days 30 --out data/out/transactions.jsonl
"""

from __future__ import annotations

import argparse
import json
import pathlib
import random
from datetime import datetime, timedelta, timezone

CITIES = {
    "Bengaluru": (12.97, 77.59), "Mumbai": (19.08, 72.88), "Delhi": (28.61, 77.21), "Chennai": (13.08, 80.27),
    "Hyderabad": (17.39, 78.49), "Pune": (18.52, 73.86), "Kolkata": (22.57, 88.36), "Ahmedabad": (23.02, 72.57),
}
MCC_NORMAL = ["5411", "5812", "5541", "4121", "5311", "5732", "4900", "5912"]
CHANNEL_MIX = [("UPI", 0.62), ("CARD", 0.18), ("IMPS", 0.08), ("NETBANKING", 0.05), ("NEFT", 0.03),
               ("ATM", 0.03), ("WALLET", 0.01)]


def pick_channel(rng):
    x, acc = rng.random(), 0.0
    for ch, p in CHANNEL_MIX:
        acc += p
        if x <= acc:
            return ch
    return "UPI"


class Gen:
    def __init__(self, customers: int, days: int, seed: int):
        self.rng = random.Random(seed)
        self.days = days
        self.start = datetime.now(timezone.utc).replace(microsecond=0) - timedelta(days=days)
        self.n = 0
        self.customers = []
        for i in range(customers):
            city = self.rng.choice(list(CITIES))
            self.customers.append({
                "customer_id": f"CUST-{i:06d}", "account_id": f"ACC-{i:06d}", "city": city,
                "device": f"dev-{i:06d}-a", "spend_mu": self.rng.uniform(5.5, 8.5),  # log-INR
                "daily_rate": self.rng.uniform(0.6, 4.0),
                "payees": [f"payee-{self.rng.randrange(50000):05d}" for _ in range(self.rng.randint(4, 15))],
            })

    def _txn(self, c, ts, amount, label=0, typology="", **kw):
        self.n += 1
        lat, lon = CITIES[kw.pop("city", c["city"])]
        channel = kw.pop("channel", None) or pick_channel(self.rng)
        t = {
            "transaction_id": f"SYN-{self.n:09d}", "account_id": c["account_id"], "customer_id": c["customer_id"],
            "amount": round(max(amount, 1.0), 2), "currency": "INR", "direction": kw.pop("direction", "DEBIT"),
            "channel": channel, "event_time": ts.isoformat(),
            "counterparty_id": kw.pop("counterparty_id", self.rng.choice(c["payees"])),
            "merchant_category_code": kw.pop("mcc", self.rng.choice(MCC_NORMAL)),
            "device_id": kw.pop("device_id", c["device"]),
            "geo": {"lat": round(lat + self.rng.uniform(-.05, .05), 4), "lon": round(lon + self.rng.uniform(-.05, .05), 4)},
            "country": "IN", "is_international": kw.pop("is_international", False),
            "card_present": True if channel in ("CARD",) and self.rng.random() < 0.6 else None,
        }
        if channel in ("ATM", "BRANCH_CASH"):
            t["counterparty_id"] = None
            t["merchant_category_code"] = "6011"
        t.update(kw)
        return {**t, "_label": label, "_typology": typology}

    def normal(self):
        out = []
        for c in self.customers:
            n = int(c["daily_rate"] * self.days)
            for _ in range(n):
                ts = self.start + timedelta(seconds=self.rng.uniform(0, self.days * 86400))
                # Most activity in waking hours IST (UTC+5:30)
                hour = ts.hour
                if 18 < hour or hour < 1:  # 23:30-06:30 IST
                    ts -= timedelta(hours=self.rng.uniform(6, 10))
                amt = self.rng.lognormvariate(c["spend_mu"], 0.7)
                out.append(self._txn(c, ts, amt))
            # monthly salary credit
            out.append(self._txn(c, self.start + timedelta(days=self.rng.randint(0, min(5, self.days - 1)), hours=5),
                                 self.rng.lognormvariate(10.8, 0.4), direction="CREDIT", channel="NEFT",
                                 counterparty_id="employer-" + c["customer_id"][-3:]))
        return out

    def inject(self, rate: float):
        out, rng = [], self.rng
        victims = rng.sample(self.customers, max(5, int(len(self.customers) * rate)))
        for k, c in enumerate(victims):
            ts = self.start + timedelta(days=rng.uniform(self.days * 0.5, self.days - 0.2))
            kind = ["ATO", "CARD_TEST", "MULE", "STRUCTURING", "IMPOSSIBLE"][k % 5]
            if kind == "ATO":
                night = ts.replace(hour=20, minute=rng.randint(0, 59))  # ~01:30-02:30 IST
                for j in range(rng.randint(1, 3)):
                    out.append(self._txn(c, night + timedelta(minutes=4 * j), rng.uniform(40000, 250000), 1, kind,
                                         device_id=f"dev-attacker-{k}", counterparty_id=f"bene-new-{k}-{j}", channel="IMPS"))
            elif kind == "CARD_TEST":
                tok = f"tok_card_{k}"
                for j in range(rng.randint(6, 12)):
                    out.append(self._txn(c, ts + timedelta(seconds=40 * j), rng.uniform(1, 49), 1, kind, channel="CARD",
                                         card_token=tok, counterparty_id=f"m-online-{j}", mcc="5967", device_id=f"dev-bot-{k}"))
                out.append(self._txn(c, ts + timedelta(minutes=9), rng.uniform(30000, 90000), 1, kind, channel="CARD",
                                     card_token=tok, mcc="5944", device_id=f"dev-bot-{k}"))
            elif kind == "MULE":
                mule = f"mule-bene-{k}"
                senders = rng.sample(self.customers, min(25, len(self.customers)))
                for j, s in enumerate(senders):
                    out.append(self._txn(s, ts + timedelta(minutes=10 * j), rng.uniform(5000, 49000), 1, kind,
                                         counterparty_id=mule, channel="UPI"))
                out.append(self._txn(c, ts, rng.uniform(150000, 400000), 1, kind, direction="CREDIT",
                                     counterparty_id=f"src-{k}", channel="IMPS"))
                out.append(self._txn(c, ts + timedelta(hours=2), rng.uniform(150000, 400000), 1, kind,
                                     counterparty_id=f"offshore-{k}", channel="IMPS"))
            elif kind == "STRUCTURING":
                for j in range(rng.randint(3, 5)):
                    out.append(self._txn(c, ts + timedelta(hours=2 * j), rng.uniform(905000, 995000), 1, kind,
                                         channel="BRANCH_CASH", direction="CREDIT", device_id=None))
            else:  # IMPOSSIBLE
                far = "Kolkata" if c["city"] != "Kolkata" else "Ahmedabad"
                out.append(self._txn(c, ts, rng.uniform(2000, 8000), 0, ""))
                out.append(self._txn(c, ts + timedelta(minutes=15), rng.uniform(20000, 80000), 1, kind, city=far,
                                     channel="CARD", device_id=f"dev-clone-{k}"))
        return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customers", type=int, default=2000)
    ap.add_argument("--days", type=int, default=30)
    ap.add_argument("--fraud-rate", type=float, default=0.03)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default="data/out/transactions.jsonl")
    a = ap.parse_args()
    g = Gen(a.customers, a.days, a.seed)
    rows = g.normal() + g.inject(a.fraud_rate)
    rows.sort(key=lambda r: r["event_time"])
    path = pathlib.Path(a.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    frauds = sum(r["_label"] for r in rows)
    print(f"wrote {len(rows):,} transactions ({frauds:,} fraudulent, {frauds / len(rows):.2%}) to {path}")


if __name__ == "__main__":
    main()
