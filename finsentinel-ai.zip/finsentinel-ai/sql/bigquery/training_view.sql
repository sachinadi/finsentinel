-- View `training_examples` (created by Terraform, infra/terraform/bigquery.tf).
-- Training examples = feature snapshots logged at decision time + analyst labels.
-- Point-in-time correct by construction: features are exactly what the model saw.
-- Unlabelled APPROVE decisions older than 45 days (no chargeback / complaint) are
-- treated as negatives; that window matches typical dispute timelines.
WITH latest_label AS (
  SELECT transaction_id, ARRAY_AGG(label ORDER BY closed_at DESC LIMIT 1)[OFFSET(0)] AS label,
         ARRAY_AGG(typologies ORDER BY closed_at DESC LIMIT 1)[OFFSET(0)] AS typologies
  FROM `${project}.${dataset}.case_feedback`
  WHERE label IS NOT NULL
  GROUP BY transaction_id
)
SELECT
  s.transaction_id,
  s.event_time,
  (SELECT MAX(IF(f.name = 'log_amount', f.value, NULL)) FROM UNNEST(s.features) f) AS log_amount,
  (SELECT MAX(IF(f.name = 'amount_zscore', f.value, NULL)) FROM UNNEST(s.features) f) AS amount_zscore,
  (SELECT MAX(IF(f.name = 'txn_count_1h', f.value, NULL)) FROM UNNEST(s.features) f) AS txn_count_1h,
  (SELECT MAX(IF(f.name = 'txn_count_24h', f.value, NULL)) FROM UNNEST(s.features) f) AS txn_count_24h,
  (SELECT MAX(IF(f.name = 'amount_sum_24h_log', f.value, NULL)) FROM UNNEST(s.features) f) AS amount_sum_24h_log,
  (SELECT MAX(IF(f.name = 'seconds_since_last_txn_log', f.value, NULL)) FROM UNNEST(s.features) f) AS seconds_since_last_txn_log,
  (SELECT MAX(IF(f.name = 'is_new_device', f.value, NULL)) FROM UNNEST(s.features) f) AS is_new_device,
  (SELECT MAX(IF(f.name = 'distinct_devices_7d', f.value, NULL)) FROM UNNEST(s.features) f) AS distinct_devices_7d,
  (SELECT MAX(IF(f.name = 'is_new_counterparty', f.value, NULL)) FROM UNNEST(s.features) f) AS is_new_counterparty,
  (SELECT MAX(IF(f.name = 'counterparty_fanin_24h', f.value, NULL)) FROM UNNEST(s.features) f) AS counterparty_fanin_24h,
  (SELECT MAX(IF(f.name = 'geo_velocity_kmh', f.value, NULL)) FROM UNNEST(s.features) f) AS geo_velocity_kmh,
  (SELECT MAX(IF(f.name = 'is_night_ist', f.value, NULL)) FROM UNNEST(s.features) f) AS is_night_ist,
  (SELECT MAX(IF(f.name = 'is_international', f.value, NULL)) FROM UNNEST(s.features) f) AS is_international,
  (SELECT MAX(IF(f.name = 'card_present', f.value, NULL)) FROM UNNEST(s.features) f) AS card_present,
  (SELECT MAX(IF(f.name = 'channel_risk', f.value, NULL)) FROM UNNEST(s.features) f) AS channel_risk,
  (SELECT MAX(IF(f.name = 'mcc_risk', f.value, NULL)) FROM UNNEST(s.features) f) AS mcc_risk,
  (SELECT MAX(IF(f.name = 'small_txn_burst_10m', f.value, NULL)) FROM UNNEST(s.features) f) AS small_txn_burst_10m,
  (SELECT MAX(IF(f.name = 'near_threshold_cash_24h', f.value, NULL)) FROM UNNEST(s.features) f) AS near_threshold_cash_24h,
  (SELECT MAX(IF(f.name = 'passthrough_ratio_24h', f.value, NULL)) FROM UNNEST(s.features) f) AS passthrough_ratio_24h,
  (SELECT MAX(IF(f.name = 'is_credit', f.value, NULL)) FROM UNNEST(s.features) f) AS is_credit,
  COALESCE(l.label, 0) AS label,
  ARRAY_TO_STRING(l.typologies, ',') AS typology
FROM `${project}.${dataset}.transactions_scored` s
LEFT JOIN latest_label l USING (transaction_id)
WHERE ARRAY_LENGTH(s.features) > 0
  AND (l.label IS NOT NULL OR s.event_time < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 45 DAY))
