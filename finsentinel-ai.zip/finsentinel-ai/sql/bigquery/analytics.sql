-- Operational analytics for fraud & risk leadership (run in BigQuery / Looker).
-- Replace ${project}/${dataset}.

-- 1. Daily decision mix, volume and p95 scoring latency
SELECT DATE(event_time, 'Asia/Kolkata') AS day, decision, COUNT(*) AS txns,
       ROUND(SUM(amount)) AS amount_inr, APPROX_QUANTILES(latency_ms, 100)[OFFSET(95)] AS p95_latency_ms
FROM `${project}.${dataset}.transactions_scored`
WHERE event_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY)
GROUP BY 1, 2 ORDER BY 1 DESC, 2;

-- 2. Rule precision: which rules generate confirmed fraud vs. noise (tune or retire rules)
SELECT h.code, COUNT(*) AS alerts, COUNTIF(f.label = 1) AS confirmed, COUNTIF(f.label = 0) AS false_positive,
       SAFE_DIVIDE(COUNTIF(f.label = 1), COUNTIF(f.label IS NOT NULL)) AS precision
FROM `${project}.${dataset}.transactions_scored` s, UNNEST(s.rule_hits) h
LEFT JOIN `${project}.${dataset}.case_feedback` f USING (transaction_id)
WHERE s.event_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
GROUP BY 1 ORDER BY alerts DESC;

-- 3. Model drift: weekly mean ML score and alert rate by model version
SELECT DATE_TRUNC(DATE(event_time), WEEK) AS week, model_version, COUNT(*) AS n,
       AVG(ml_score) AS mean_ml_score, COUNTIF(decision != 'APPROVE') / COUNT(*) AS alert_rate
FROM `${project}.${dataset}.transactions_scored`
GROUP BY 1, 2 ORDER BY 1 DESC;

-- 4. Degraded-mode detector: share of decisions made by the fallback scorecard
SELECT TIMESTAMP_TRUNC(scored_at, HOUR) AS hour,
       COUNTIF(model_version LIKE '%fallback%') / COUNT(*) AS fallback_share
FROM `${project}.${dataset}.transactions_scored`
WHERE scored_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
GROUP BY 1 ORDER BY 1 DESC;

-- 5. Document fraud: failure rate of integrity checks by document type
SELECT doc_type, COUNT(*) AS docs, COUNTIF(risk_level = 'HIGH') / COUNT(*) AS high_risk_rate,
       APPROX_TOP_COUNT(fc, 5) AS top_failed_checks
FROM `${project}.${dataset}.document_results` LEFT JOIN UNNEST(failed_checks) fc
GROUP BY 1;
