"""Test harness: offline mode, fakeredis, and per-service module loading."""

from __future__ import annotations

import importlib
import os
import pathlib
import sys

import fakeredis
import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SERVICES = ROOT / "services"

os.environ.update({
    "AUTH_MODE": "dev",
    "ENVIRONMENT": "test",
    "GEMINI_ENABLED": "false",
    "DOCAI_ENABLED": "false",
    "DLP_ENABLED": "false",
    "PARTNER_HMAC_SECRETS": '{"core-banking": "test-secret"}',
    "PII_TOKENIZATION_KEY": "test-tokenization-key",
})
sys.path.insert(0, str(SERVICES / "common"))

_SERVICE_MODULES = {"main", "rules", "scorer", "decision", "checks", "extractor", "investigator", "tools"}


def load_service(name: str):
    """Import services/<name>/main.py with its sibling modules, isolated from other services."""
    for mod in list(sys.modules):
        if mod in _SERVICE_MODULES:
            del sys.modules[mod]
    path = str(SERVICES / name)
    if path in sys.path:
        sys.path.remove(path)
    sys.path.insert(0, path)
    return importlib.import_module("main")


@pytest.fixture()
def fake_redis(monkeypatch):
    r = fakeredis.FakeRedis(decode_responses=True)
    from finsentinel_common import redis_client

    redis_client.get_redis.cache_clear()
    monkeypatch.setattr(redis_client, "get_redis", lambda: r)
    return r


@pytest.fixture()
def published(monkeypatch):
    """Capture Pub/Sub publishes instead of calling GCP."""
    sent: list[tuple[str, dict, dict]] = []

    def _publish(topic, payload, ordering_key="", **attrs):
        sent.append((topic, payload, attrs))
        return f"msg-{len(sent)}"

    from finsentinel_common import pubsub

    monkeypatch.setattr(pubsub, "publish", _publish)
    return sent
