import json
import time
from datetime import date, datetime, timezone

import pytest
from fastapi.testclient import TestClient

from conftest import load_service
from finsentinel_common.security import compute_signature


def _signed(body: dict | list):
    raw = json.dumps(body).encode()
    ts = str(int(time.time()))
    return raw, {"x-partner-id": "core-banking", "x-timestamp": ts,
                 "x-signature": compute_signature("test-secret", ts, raw), "content-type": "application/json"}


@pytest.fixture()
def ingest(fake_redis, published):
    main = load_service("ingest_api")
    return TestClient(main.app), published


TXN = {"transaction_id": "TXN-INGEST-1", "account_id": "ACC-1", "customer_id": "CUST-1", "amount": 1200.5,
       "channel": "UPI", "event_time": datetime.now(timezone.utc).isoformat()}


def test_ingest_accepts_signed_and_dedupes(ingest):
    c, sent = ingest
    raw, h = _signed(TXN)
    assert c.post("/api/v1/transactions", content=raw, headers=h).json()["status"] == "accepted"
    assert c.post("/api/v1/transactions", content=raw, headers=h).json()["status"] == "duplicate"
    assert len(sent) == 1 and sent[0][0] == "transactions"


def test_ingest_rejects_bad_signature_raw_pan_and_unknown_fields(ingest):
    c, _ = ingest
    raw, h = _signed(TXN)
    h["x-signature"] = "0" * 64
    assert c.post("/api/v1/transactions", content=raw, headers=h).status_code == 401

    raw, h = _signed({**TXN, "transaction_id": "TXN-PAN-1", "description": "paid with 4111111111111111"})
    assert c.post("/api/v1/transactions", content=raw, headers=h).status_code == 422

    raw, h = _signed({**TXN, "transaction_id": "TXN-X-1", "cvv": "123"})
    assert c.post("/api/v1/transactions", content=raw, headers=h).status_code == 422


def test_batch_partial_acceptance(ingest):
    c, _ = ingest
    good = {**TXN, "transaction_id": "TXN-B-1"}
    bad = {**TXN, "transaction_id": "TXN-B-2", "amount": -5}
    raw, h = _signed([good, bad])
    r = c.post("/api/v1/transactions:batch", content=raw, headers=h).json()
    assert r["accepted"] == 1 and r["rejected"][0]["index"] == 1


# ---------------------------------------------------------------- doc checks
def _with_check_digit(base11: str) -> str:
    load_service("doc_intel")
    import checks

    return next(base11 + str(d) for d in range(10) if checks.verhoeff_valid(base11 + str(d)))


def test_aadhaar_verhoeff_and_kyc_checks():
    load_service("doc_intel")
    import checks

    good = _with_check_digit("23456789012")
    assert checks.verhoeff_valid(good)
    bad = good[:-1] + str((int(good[-1]) + 1) % 10)
    assert not checks.verhoeff_valid(bad)

    res = checks.check_kyc({"id_type": "AADHAAR", "id_number": good, "name": "Ravi Kumar",
                            "date_of_birth": "1990-04-01"}, expected_name="Kumar Ravi", today=date(2026, 10, 1))
    assert all(c["passed"] for c in res)


def test_statement_tampering_detected():
    load_service("doc_intel")
    import checks

    stmt = {"opening_balance": 10000, "closing_balance": 95000, "transactions": [
        {"date": "2026-09-01", "credit": 50000, "debit": 0, "balance": 60000},
        {"date": "2026-09-05", "credit": 0, "debit": 5000, "balance": 95000},   # edited: should be 55000
    ], "tamper_signals": ["Font mismatch in balance column"]}
    results, level = checks.run_checks("BANK_STATEMENT", stmt)
    failed = {c["check"] for c in results if not c["passed"]}
    assert {"running_balance", "opening_to_closing"} <= failed
    assert level == "HIGH"


def test_salary_slip_arithmetic():
    load_service("doc_intel")
    import checks

    _, ok = checks.run_checks("SALARY_SLIP", {"gross_pay": 100000, "deductions_total": 12000, "net_pay": 88000,
                                              "tamper_signals": []})
    _, bad = checks.run_checks("SALARY_SLIP", {"gross_pay": 100000, "deductions_total": 12000, "net_pay": 98000,
                                               "tamper_signals": []})
    assert ok == "LOW" and bad == "HIGH"
