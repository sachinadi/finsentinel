import time

import pytest
from fastapi import HTTPException

from finsentinel_common.pii import contains_card_number, luhn_valid, mask_text, tokenize
from finsentinel_common.security import compute_signature, verify_partner_signature


def test_luhn_and_card_detection():
    assert luhn_valid("4111111111111111")
    assert not luhn_valid("4111111111111112")
    assert contains_card_number('{"note": "card 4111 1111 1111 1111"}')
    assert not contains_card_number('{"transaction_id": "TXN-1234567890123"}')  # not Luhn-valid


def test_masking_indian_and_global_identifiers():
    text = ("Card 4111111111111111, Aadhaar 2345 6789 0123, PAN ABCDE1234F, "
            "mail a.b@bank.com, phone +91 9876543210, UPI ravi@okhdfc, a/c no 123456789012")
    out = mask_text(text)
    for raw in ("4111111111111111", "2345 6789 0123", "ABCDE1234F", "a.b@bank.com", "9876543210",
                "ravi@okhdfc", "123456789012"):
        assert raw not in out, raw
    assert "****1111" in out and "XXXX-XXXX-0123" in out


def test_tokenize_is_deterministic_and_keyed():
    assert tokenize("CUST001", "k1") == tokenize("CUST001", "k1")
    assert tokenize("CUST001", "k1") != tokenize("CUST001", "k2")


def test_hmac_signature_and_replay_window():
    body, ts = b'{"a":1}', str(int(time.time()))
    sig = compute_signature("test-secret", ts, body)
    verify_partner_signature("core-banking", ts, sig, body)  # no exception

    with pytest.raises(HTTPException):
        verify_partner_signature("core-banking", ts, sig, b'{"a":2}')        # tampered body
    with pytest.raises(HTTPException):
        verify_partner_signature("unknown", ts, sig, body)                    # unknown partner
    old = str(int(time.time()) - 3600)
    with pytest.raises(HTTPException):
        verify_partner_signature("core-banking", old, compute_signature("test-secret", old, body), body)  # replay
