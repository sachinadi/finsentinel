from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from conftest import load_service


def txn(i, amount=850.0, minutes_ago=0, **kw):
    t = {
        "transaction_id": f"TXN-{i:06d}",
        "account_id": kw.pop("account_id", "ACC-1001"),
        "customer_id": "CUST-1001",
        "amount": amount,
        "channel": kw.pop("channel", "UPI"),
        "direction": kw.pop("direction", "DEBIT"),
        "event_time": (datetime.now(timezone.utc) - timedelta(minutes=minutes_ago)).isoformat(),
        "device_id": kw.pop("device_id", "dev-home"),
        "counterparty_id": kw.pop("counterparty_id", "merchant-grocer"),
        "geo": kw.pop("geo", {"lat": 12.97, "lon": 77.59}),
    }
    t.update(kw)
    return t


@pytest.fixture()
def client(fake_redis, published):
    main = load_service("fraud_engine")
    return TestClient(main.app), published


def _history(c, n=30):
    # A month of ordinary spending from the customer's usual device
    for i in range(n):
        c.post("/v1/score", json=txn(i, amount=500 + 37 * (i % 9), minutes_ago=60 * 24 * 29 - i * 60 * 23))


def test_normal_transaction_is_approved(client):
    c, sent = client
    _history(c)
    r = c.post("/v1/score", json=txn(999, amount=640.0)).json()
    assert r["decision"] == "APPROVE"
    assert len(r["features"]) == 20
    assert any(topic == "fraud-decisions" for topic, *_ in sent)


def test_account_takeover_pattern_is_flagged(client):
    c, sent = client
    _history(c)
    r = c.post("/v1/score", json=txn(1000, amount=185000.0, device_id="dev-new-android",
                                     counterparty_id="new-beneficiary")).json()
    codes = {h["code"] for h in r["rule_hits"]}
    assert "ATO_NEW_DEVICE_SPIKE" in codes
    assert r["decision"] in ("REVIEW", "BLOCK")
    assert any(topic == "fraud-alerts" for topic, *_ in sent)


def test_card_testing_burst(client):
    c, _ = client
    _history(c, 5)
    for i in range(6):
        c.post("/v1/score", json=txn(2000 + i, amount=1.0 + i, channel="CARD", card_token="tok_card_1",
                                     counterparty_id=f"m-{i}", minutes_ago=6 - i))
    r = c.post("/v1/score", json=txn(2100, amount=2.0, channel="CARD", card_token="tok_card_1")).json()
    assert "CARD_TESTING_BURST" in {h["code"] for h in r["rule_hits"]}


def test_watchlist_is_hard_block(client, fake_redis):
    c, _ = client
    fake_redis.sadd("watchlist", "sanctioned-entity-9")
    r = c.post("/v1/score", json=txn(3000, amount=100.0, counterparty_id="sanctioned-entity-9")).json()
    assert r["decision"] == "BLOCK"


def test_cash_structuring_and_ctr_flags(client):
    c, _ = client
    for i in range(3):
        c.post("/v1/score", json=txn(4000 + i, amount=960000.0, channel="BRANCH_CASH", minutes_ago=300 - i * 60,
                                     device_id=None, counterparty_id=None, geo=None))
    r = c.post("/v1/score", json=txn(4100, amount=1_200_000.0, channel="BRANCH_CASH",
                                     device_id=None, counterparty_id=None, geo=None)).json()
    assert "CASH_STRUCTURING" in {h["code"] for h in r["rule_hits"]}
    assert "CTR_REPORTABLE" in r["regulatory_flags"]


def test_duplicate_delivery_is_idempotent(client):
    c, sent = client
    first = c.post("/v1/score", json=txn(5000)).json()
    second = c.post("/v1/score", json=txn(5000)).json()
    assert second["duplicate"] is True and second["decision"] == first["decision"]
    assert sum(1 for topic, *_ in sent if topic == "fraud-decisions") == 1


def test_noisy_or_combination():
    load_service("fraud_engine")
    import decision
    from finsentinel_common.models import RuleHit

    hits = [RuleHit(code="A", score=0.5, reason="", typology="X")]
    assert decision.combine(0.2, hits) == pytest.approx(0.6)
    assert decision.decide(0.6, hits, 0.5, 0.85).value == "REVIEW"
