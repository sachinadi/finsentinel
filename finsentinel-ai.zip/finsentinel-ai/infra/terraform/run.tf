# Cloud Run services. All are private: ingress is limited to the HTTPS load balancer
# (or internal-only for the fraud engine), invocation requires IAM, egress goes through
# the VPC with no internet route. Scaling limits reflect peak-day sizing (e.g. festival
# season UPI peaks); raise max instances and quotas together.

locals {
  redis_env = {
    REDIS_HOST = google_redis_instance.features.host
    REDIS_PORT = tostring(google_redis_instance.features.port)
    REDIS_TLS  = "true"
  }
  db_env = {
    CLOUDSQL_INSTANCE = google_sql_database_instance.pg.connection_name
    DB_NAME           = google_sql_database.app.name
  }
  common_env = {
    GOOGLE_CLOUD_PROJECT = var.project_id
    REGION               = var.region
    ENVIRONMENT          = var.environment
    AUTH_MODE            = "iap"
    IAP_AUDIENCE         = "/projects/${local.project_number}/global/backendServices/"
    PUBSUB_PUSH_AUDIENCE = local.push_audience
    PUBSUB_PUSH_SA       = local.sa_email["pubsub-push"]
    BQ_DATASET           = google_bigquery_dataset.main.dataset_id
    GEMINI_MODEL         = var.gemini_model
    GEMINI_LOCATION      = var.gemini_location
  }

  services = {
    "ingest-api" = {
      ingress        = "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER", min = 2, max = 100, cpu = "1", mem = "512Mi", timeout = "30s"
      public_invoker = true # partner traffic is authenticated by HMAC + Cloud Armor, not Google identity
      env = merge(local.redis_env, {
        FRAUD_ENGINE_URL = "https://fraud-engine-${local.project_number}.${var.region}.run.app"
      })
      secrets = { PARTNER_HMAC_SECRETS = "partner-hmac-secrets", PII_TOKENIZATION_KEY = "pii-tokenization-key",
      REDIS_AUTH = "redis-auth", REDIS_CA_CERT = "redis-ca" }
    }
    "fraud-engine" = {
      ingress        = "INGRESS_TRAFFIC_INTERNAL_ONLY", min = 3, max = 200, cpu = "2", mem = "1Gi", timeout = "30s"
      public_invoker = false
      env = merge(local.redis_env, {
        VERTEX_ENDPOINT_ID = var.vertex_endpoint_live ? google_vertex_ai_endpoint.fraud.name : ""
        MODEL_VERSION      = var.model_version
        VERTEX_TIMEOUT_S   = "0.15"
        WEB_CONCURRENCY    = "4"
      })
      secrets = { PII_TOKENIZATION_KEY = "pii-tokenization-key", REDIS_AUTH = "redis-auth", REDIS_CA_CERT = "redis-ca" }
    }
    "case-service" = {
      ingress        = "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER", min = 1, max = 30, cpu = "1", mem = "1Gi", timeout = "120s"
      public_invoker = false
      env            = merge(local.db_env, { DB_IAM_USER = trimsuffix(local.sa_email["case-service"], ".gserviceaccount.com") })
      secrets        = { PII_TOKENIZATION_KEY = "pii-tokenization-key", ROLE_BINDINGS = "role-bindings" }
    }
    "doc-intel" = {
      ingress        = "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER", min = 1, max = 30, cpu = "2", mem = "2Gi", timeout = "600s"
      public_invoker = false
      env = merge(local.db_env, {
        DB_IAM_USER          = trimsuffix(local.sa_email["doc-intel"], ".gserviceaccount.com")
        RAW_DOCS_BUCKET      = google_storage_bucket.buckets["raw-docs"].name
        DOCAI_LOCATION       = var.docai_location
        DOCAI_OCR_PROCESSOR  = google_document_ai_processor.ocr.id
        DOCAI_FORM_PROCESSOR = google_document_ai_processor.form.id
      })
      secrets = { PII_TOKENIZATION_KEY = "pii-tokenization-key", ROLE_BINDINGS = "role-bindings" }
    }
    "assistant" = {
      ingress        = "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER", min = 1, max = 20, cpu = "1", mem = "1Gi", timeout = "120s"
      public_invoker = false
      env = merge(local.redis_env, local.db_env, {
        DB_IAM_USER      = trimsuffix(local.sa_email["assistant"], ".gserviceaccount.com")
        SEARCH_ENGINE_ID = google_discovery_engine_search_engine.policies.engine_id
        SEARCH_LOCATION  = var.search_location
      })
      secrets = { PII_TOKENIZATION_KEY = "pii-tokenization-key", ROLE_BINDINGS = "role-bindings",
      REDIS_AUTH = "redis-auth", REDIS_CA_CERT = "redis-ca" }
    }
    "console" = {
      ingress        = "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER", min = 1, max = 10, cpu = "1", mem = "256Mi", timeout = "30s"
      public_invoker = false
      env            = {}
      secrets        = {}
    }
  }
}

resource "google_cloud_run_v2_service" "svc" {
  for_each             = local.services
  name                 = each.key
  location             = var.region
  ingress              = each.value.ingress
  deletion_protection  = false
  invoker_iam_disabled = each.value.public_invoker
  custom_audiences     = [local.push_audience]

  template {
    service_account                  = google_service_account.sa[each.key].email
    execution_environment            = "EXECUTION_ENVIRONMENT_GEN2"
    max_instance_request_concurrency = each.key == "doc-intel" ? 10 : 80
    timeout                          = each.value.timeout

    scaling {
      min_instance_count = each.value.min
      max_instance_count = each.value.max
    }

    vpc_access {
      egress = "ALL_TRAFFIC"
      network_interfaces {
        network    = google_compute_network.vpc.id
        subnetwork = google_compute_subnetwork.run.id
      }
    }

    containers {
      image = "${local.repo}/${each.key}:${var.image_tag}"

      resources {
        limits            = { cpu = each.value.cpu, memory = each.value.mem }
        cpu_idle          = each.key != "fraud-engine" # always-on CPU for the latency-critical path
        startup_cpu_boost = true
      }

      dynamic "env" {
        for_each = each.key == "console" ? {} : merge(local.common_env, { SERVICE_NAME = each.key }, each.value.env)
        content {
          name  = env.key
          value = env.value
        }
      }

      dynamic "env" {
        for_each = each.value.secrets
        content {
          name = env.key
          value_source {
            secret_key_ref {
              secret  = google_secret_manager_secret.s[env.value].secret_id
              version = "latest"
            }
          }
        }
      }

      startup_probe {
        http_get { path = "/healthz" }
        initial_delay_seconds = 2
        period_seconds        = 3
        failure_threshold     = 10
      }
      liveness_probe {
        http_get { path = "/healthz" }
        period_seconds = 30
      }
    }
  }

  dynamic "binary_authorization" {
    for_each = var.enable_binary_authorization ? [1] : []
    content {
      use_default = true
    }
  }

  lifecycle {
    # Cloud Build rolls out new images; Terraform owns everything else.
    ignore_changes = [template[0].containers[0].image, client, client_version]
  }

  depends_on = [google_secret_manager_secret_iam_member.access, google_project_iam_member.workload]
}

# The ingest API calls the fraud engine synchronously for real-time authorisation.
resource "google_cloud_run_v2_service_iam_member" "ingest_calls_fraud" {
  name     = google_cloud_run_v2_service.svc["fraud-engine"].name
  location = var.region
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.sa["ingest-api"].email}"
}

# IAP forwards authenticated staff requests to these services.
resource "google_cloud_run_v2_service_iam_member" "iap_invoker" {
  for_each = toset(["case-service", "doc-intel", "assistant", "console"])
  name     = google_cloud_run_v2_service.svc[each.value].name
  location = var.region
  role     = "roles/run.invoker"
  member   = "serviceAccount:${local.agent.iap}"
}

# ---------------------------------------------------------------- jobs
resource "google_cloud_run_v2_job" "db_migrate" {
  name                = "db-migrate"
  location            = var.region
  deletion_protection = false

  template {
    task_count = 1
    template {
      service_account = google_service_account.sa["db-migrate"].email
      max_retries     = 1
      timeout         = "600s"
      vpc_access {
        egress = "ALL_TRAFFIC"
        network_interfaces {
          network    = google_compute_network.vpc.id
          subnetwork = google_compute_subnetwork.run.id
        }
      }
      containers {
        image   = "${local.repo}/case-service:${var.image_tag}"
        command = ["python", "migrate.py"]
        env {
          name  = "CLOUDSQL_INSTANCE"
          value = google_sql_database_instance.pg.connection_name
        }
        env {
          name  = "DB_NAME"
          value = google_sql_database.app.name
        }
        env {
          name  = "APP_DB_USERS"
          value = join(",", [for w in local.db_workloads : trimsuffix(local.sa_email[w], ".gserviceaccount.com")])
        }
        env {
          name = "DB_ADMIN_PASSWORD"
          value_source {
            secret_key_ref {
              secret  = google_secret_manager_secret.s["db-admin-password"].secret_id
              version = "latest"
            }
          }
        }
      }
    }
  }
  lifecycle {
    ignore_changes = [template[0].template[0].containers[0].image, client, client_version]
  }
  depends_on = [google_secret_manager_secret_iam_member.access, google_sql_user.iam]
}
