# ------------------------------------------------------------ audit logging
# Data Access audit logs for every service that touches customer data, and a
# sink that archives all audit logs to a retention-locked (WORM) bucket.

resource "google_project_iam_audit_config" "data_access" {
  for_each = toset(["storage.googleapis.com", "bigquery.googleapis.com", "cloudsql.googleapis.com",
    "secretmanager.googleapis.com", "aiplatform.googleapis.com", "documentai.googleapis.com",
    "cloudkms.googleapis.com", "pubsub.googleapis.com", "dlp.googleapis.com",
  "discoveryengine.googleapis.com"])
  project = var.project_id
  service = each.value
  audit_log_config { log_type = "ADMIN_READ" }
  audit_log_config { log_type = "DATA_READ" }
  audit_log_config { log_type = "DATA_WRITE" }
}

resource "google_logging_project_sink" "audit_archive" {
  name                   = "${local.name}-audit-archive"
  destination            = "storage.googleapis.com/${google_storage_bucket.buckets["audit-logs"].name}"
  filter                 = "logName:\"cloudaudit.googleapis.com\" OR jsonPayload.logger=\"audit\""
  unique_writer_identity = true
}

resource "google_storage_bucket_iam_member" "audit_sink_writer" {
  bucket = google_storage_bucket.buckets["audit-logs"].name
  role   = "roles/storage.objectCreator"
  member = google_logging_project_sink.audit_archive.writer_identity
}

# ------------------------------------------------------------ monitoring
resource "google_monitoring_notification_channel" "email" {
  display_name = "FinSentinel on-call"
  type         = "email"
  labels       = { email_address = var.alert_email }
}

resource "google_logging_metric" "scoring_fallback" {
  name   = "finsentinel/scoring_fallback"
  filter = "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"fraud-engine\" AND jsonPayload.model:\"fallback\""
  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
  }
}

resource "google_logging_metric" "pan_rejected" {
  name   = "finsentinel/raw_pan_rejected"
  filter = "resource.type=\"cloud_run_revision\" AND jsonPayload.message=\"raw PAN rejected\""
  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
  }
}

locals {
  alert_policies = {
    "Dead-lettered messages present" = {
      filter     = "resource.type=\"pubsub_subscription\" AND resource.labels.subscription_id=has_substring(\"-dlq-hold\") AND metric.type=\"pubsub.googleapis.com/subscription/num_undelivered_messages\""
      threshold  = 0
      duration   = "300s"
      aligner    = "ALIGN_MAX"
      comparison = "COMPARISON_GT"
    }
    "Transaction backlog older than 60s" = {
      filter     = "resource.type=\"pubsub_subscription\" AND resource.labels.subscription_id=\"transactions-fraud-engine\" AND metric.type=\"pubsub.googleapis.com/subscription/oldest_unacked_message_age\""
      threshold  = 60
      duration   = "120s"
      aligner    = "ALIGN_MAX"
      comparison = "COMPARISON_GT"
    }
    "Fraud engine p99 latency above 300 ms" = {
      filter     = "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"fraud-engine\" AND metric.type=\"run.googleapis.com/request_latencies\""
      threshold  = 300
      duration   = "300s"
      aligner    = "ALIGN_PERCENTILE_99"
      comparison = "COMPARISON_GT"
    }
    "Cloud Run 5xx errors" = {
      filter     = "resource.type=\"cloud_run_revision\" AND metric.type=\"run.googleapis.com/request_count\" AND metric.labels.response_code_class=\"5xx\""
      threshold  = 1
      duration   = "300s"
      aligner    = "ALIGN_RATE"
      comparison = "COMPARISON_GT"
    }
    "Model fallback scoring in use" = {
      filter     = "resource.type=\"cloud_run_revision\" AND metric.type=\"logging.googleapis.com/user/${google_logging_metric.scoring_fallback.name}\""
      threshold  = 10
      duration   = "300s"
      aligner    = "ALIGN_RATE"
      comparison = "COMPARISON_GT"
    }
    "Cloud SQL CPU above 80%" = {
      filter     = "resource.type=\"cloudsql_database\" AND metric.type=\"cloudsql.googleapis.com/database/cpu/utilization\""
      threshold  = 0.8
      duration   = "600s"
      aligner    = "ALIGN_MEAN"
      comparison = "COMPARISON_GT"
    }
  }
}

resource "google_monitoring_alert_policy" "alerts" {
  for_each              = local.alert_policies
  display_name          = "[FinSentinel] ${each.key}"
  combiner              = "OR"
  notification_channels = [google_monitoring_notification_channel.email.id]
  conditions {
    display_name = each.key
    condition_threshold {
      filter          = each.value.filter
      comparison      = each.value.comparison
      threshold_value = each.value.threshold
      duration        = each.value.duration
      aggregations {
        alignment_period   = "60s"
        per_series_aligner = each.value.aligner
      }
    }
  }
  alert_strategy {
    auto_close = "1800s"
  }
}
