# Global external Application Load Balancer:
#   * TLS 1.2+ (MODERN profile), Google-managed certificate, HTTP->HTTPS redirect
#   * Cloud Armor WAF (OWASP CRS), geo restriction, adaptive L7 DDoS protection
#   * IAP on every staff-facing backend (console, cases, documents, copilot)
#   * The partner ingest backend is NOT behind IAP; it is restricted by partner
#     CIDR allow-list, rate limiting and HMAC request signing.

resource "google_compute_global_address" "lb" {
  name = "${local.name}-lb-ip"
}

resource "google_compute_managed_ssl_certificate" "cert" {
  name = "${local.name}-cert"
  managed { domains = [var.domain] }
}

resource "google_compute_ssl_policy" "modern" {
  name            = "${local.name}-tls"
  profile         = "MODERN"
  min_tls_version = "TLS_1_2"
}

locals {
  lb_backends = {
    "console"      = { iap = true, armor = "staff" }
    "case-service" = { iap = true, armor = "staff" }
    "doc-intel"    = { iap = true, armor = "staff" }
    "assistant"    = { iap = true, armor = "staff" }
    "ingest-api"   = { iap = false, armor = "ingest" }
  }
  waf_rules = ["sqli-v33-stable", "xss-v33-stable", "lfi-v33-stable", "rfi-v33-stable", "rce-v33-stable",
  "protocolattack-v33-stable", "scannerdetection-v33-stable", "sessionfixation-v33-stable"]
}

# ---------------------------------------------------------------- Cloud Armor
resource "google_compute_security_policy" "staff" {
  name        = "${local.name}-staff-armor"
  description = "Staff console and APIs"
  adaptive_protection_config {
    layer_7_ddos_defense_config { enable = true }
  }

  dynamic "rule" {
    for_each = { for i, r in local.waf_rules : r => 1000 + i }
    content {
      action   = "deny(403)"
      priority = rule.value
      match {
        expr { expression = "evaluatePreconfiguredWaf('${rule.key}', {'sensitivity': 2})" }
      }
      description = "OWASP CRS ${rule.key}"
    }
  }

  rule {
    action      = "deny(403)"
    priority    = 2000
    description = "Geo restriction"
    match {
      expr {
        expression = "!(${join(" || ", [for c in var.allowed_country_codes : "origin.region_code == '${c}'"])})"
      }
    }
  }

  rule {
    action   = "throttle"
    priority = 3000
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"
      enforce_on_key = "IP"
      rate_limit_threshold {
        count        = 600
        interval_sec = 60
      }
    }
    description = "Per-IP rate limit"
  }

  rule {
    action   = "allow"
    priority = 2147483647
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
    description = "Default allow (IAP authenticates every request)"
  }
}

resource "google_compute_security_policy" "ingest" {
  name        = "${local.name}-ingest-armor"
  description = "Partner transaction ingest"
  adaptive_protection_config {
    layer_7_ddos_defense_config { enable = true }
  }

  dynamic "rule" {
    for_each = { for i, r in ["sqli-v33-stable", "rce-v33-stable", "protocolattack-v33-stable"] : r => 1000 + i }
    content {
      action   = "deny(403)"
      priority = rule.value
      match {
        expr { expression = "evaluatePreconfiguredWaf('${rule.key}', {'sensitivity': 1})" }
      }
    }
  }

  dynamic "rule" {
    for_each = length(var.partner_cidrs) > 0 ? [1] : []
    content {
      action      = "deny(403)"
      priority    = 1500
      description = "Only registered partner networks"
      match {
        expr {
          expression = "!(${join(" || ", [for c in var.partner_cidrs : "inIpRange(origin.ip, '${c}')"])})"
        }
      }
    }
  }

  rule {
    action   = "rate_based_ban"
    priority = 3000
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
    rate_limit_options {
      conform_action   = "allow"
      exceed_action    = "deny(429)"
      enforce_on_key   = "IP"
      ban_duration_sec = 300
      rate_limit_threshold {
        count        = 30000
        interval_sec = 60
      }
    }
  }

  rule {
    action   = "allow"
    priority = 2147483647
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
  }
}

# ------------------------------------------------------------- backends
resource "google_compute_region_network_endpoint_group" "neg" {
  for_each              = local.lb_backends
  name                  = "${local.name}-${each.key}-neg"
  region                = var.region
  network_endpoint_type = "SERVERLESS"
  cloud_run {
    service = google_cloud_run_v2_service.svc[each.key].name
  }
}

resource "google_compute_backend_service" "be" {
  for_each              = local.lb_backends
  name                  = "${local.name}-${each.key}-be"
  protocol              = "HTTPS"
  load_balancing_scheme = "EXTERNAL_MANAGED"
  security_policy       = each.value.armor == "staff" ? google_compute_security_policy.staff.id : google_compute_security_policy.ingest.id

  backend {
    group = google_compute_region_network_endpoint_group.neg[each.key].id
  }

  log_config {
    enable      = true
    sample_rate = 1.0
  }

  dynamic "iap" {
    for_each = each.value.iap ? [1] : []
    content {
      enabled = true
    }
  }
}

resource "google_iap_web_backend_service_iam_member" "staff" {
  for_each            = { for k, v in local.lb_backends : k => v if v.iap }
  web_backend_service = google_compute_backend_service.be[each.key].name
  role                = "roles/iap.httpsResourceAccessor"
  member              = var.staff_group
}

# ------------------------------------------------------------- routing
resource "google_compute_url_map" "https" {
  name            = "${local.name}-urlmap"
  default_service = google_compute_backend_service.be["console"].id

  host_rule {
    hosts        = [var.domain]
    path_matcher = "main"
  }

  path_matcher {
    name            = "main"
    default_service = google_compute_backend_service.be["console"].id

    path_rule {
      paths   = ["/api/v1/*"]
      service = google_compute_backend_service.be["ingest-api"].id
    }
    path_rule {
      paths   = ["/api/cases", "/api/cases/*", "/api/metrics", "/api/audit/*"]
      service = google_compute_backend_service.be["case-service"].id
    }
    path_rule {
      paths   = ["/api/documents", "/api/documents/*"]
      service = google_compute_backend_service.be["doc-intel"].id
    }
    path_rule {
      paths   = ["/api/assistant/*"]
      service = google_compute_backend_service.be["assistant"].id
    }
  }
}

resource "google_compute_target_https_proxy" "https" {
  name             = "${local.name}-https-proxy"
  url_map          = google_compute_url_map.https.id
  ssl_certificates = [google_compute_managed_ssl_certificate.cert.id]
  ssl_policy       = google_compute_ssl_policy.modern.id
}

resource "google_compute_global_forwarding_rule" "https" {
  name                  = "${local.name}-https"
  target                = google_compute_target_https_proxy.https.id
  ip_address            = google_compute_global_address.lb.id
  port_range            = "443"
  load_balancing_scheme = "EXTERNAL_MANAGED"
}

resource "google_compute_url_map" "redirect" {
  name = "${local.name}-http-redirect"
  default_url_redirect {
    https_redirect         = true
    redirect_response_code = "MOVED_PERMANENTLY_DEFAULT"
    strip_query            = false
  }
}

resource "google_compute_target_http_proxy" "redirect" {
  name    = "${local.name}-http-proxy"
  url_map = google_compute_url_map.redirect.id
}

resource "google_compute_global_forwarding_rule" "http" {
  name                  = "${local.name}-http"
  target                = google_compute_target_http_proxy.redirect.id
  ip_address            = google_compute_global_address.lb.id
  port_range            = "80"
  load_balancing_scheme = "EXTERNAL_MANAGED"
}
