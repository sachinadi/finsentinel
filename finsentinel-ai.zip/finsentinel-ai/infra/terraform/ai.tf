# --------------------------------------------------------------- Document AI
resource "google_document_ai_processor" "ocr" {
  location     = var.docai_location
  display_name = "${local.name}-ocr"
  type         = "OCR_PROCESSOR"
  depends_on   = [google_project_service.apis]
}

resource "google_document_ai_processor" "form" {
  location     = var.docai_location
  display_name = "${local.name}-form-parser"
  type         = "FORM_PARSER_PROCESSOR"
  depends_on   = [google_project_service.apis]
}

# ------------------------------------------------- Vertex AI prediction endpoint
# Created empty; ml/train.py registers models and deploys them here (canary first).
resource "random_integer" "endpoint_id" {
  min = 1000000000
  max = 1999999999
}

resource "google_vertex_ai_endpoint" "fraud" {
  name         = tostring(random_integer.endpoint_id.result)
  display_name = "${local.name}-fraud-model"
  description  = "Fraud scoring model (XGBoost) for the FinSentinel fraud engine"
  location     = var.region
  encryption_spec {
    kms_key_name = google_kms_crypto_key.keys["vertex"].id
  }
  depends_on = [google_kms_crypto_key_iam_member.agents]
}

# ------------------------------------------- Vertex AI Search (policy grounding)
# Only bank policies and regulatory circulars are indexed — no customer data —
# so the multi-region search location does not affect personal-data residency.
resource "google_discovery_engine_data_store" "policies" {
  location                    = var.search_location
  data_store_id               = "${local.name}-policies"
  display_name                = "FinSentinel policies and regulations"
  industry_vertical           = "GENERIC"
  content_config              = "CONTENT_REQUIRED"
  solution_types              = ["SOLUTION_TYPE_SEARCH"]
  create_advanced_site_search = false
  depends_on                  = [google_project_service.apis]
}

resource "google_discovery_engine_search_engine" "policies" {
  engine_id         = "${local.name}-policy-search"
  collection_id     = "default_collection"
  location          = var.search_location
  display_name      = "FinSentinel policy search"
  industry_vertical = "GENERIC"
  data_store_ids    = [google_discovery_engine_data_store.policies.data_store_id]
  search_engine_config {
    search_tier    = "SEARCH_TIER_ENTERPRISE"
    search_add_ons = ["SEARCH_ADD_ON_LLM"]
  }
}
