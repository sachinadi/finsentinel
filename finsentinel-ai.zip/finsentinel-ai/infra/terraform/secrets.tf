# Secrets: replicated only in the primary region, CMEK-encrypted, accessible
# per-secret by the workloads that need them. Rotate by adding a new version;
# Cloud Run picks up "latest" on the next revision/instance start.

resource "random_password" "pii_key" {
  length  = 64
  special = false
}

locals {
  # Static reader map (non-sensitive) drives for_each; values are kept separate
  # because they are sensitive.
  secret_readers = {
    "partner-hmac-secrets" = ["ingest-api"]
    "pii-tokenization-key" = ["ingest-api", "fraud-engine", "case-service", "doc-intel", "assistant"]
    "role-bindings"        = ["case-service", "doc-intel", "assistant"]
    "db-admin-password"    = ["db-migrate"]
    "redis-auth"           = ["ingest-api", "fraud-engine", "assistant"]
    "redis-ca"             = ["ingest-api", "fraud-engine", "assistant"]
  }
  secret_values = {
    "partner-hmac-secrets" = var.partner_hmac_secrets_json
    "pii-tokenization-key" = random_password.pii_key.result
    "role-bindings"        = var.role_bindings_json
    "db-admin-password"    = random_password.db_admin.result
    "redis-auth"           = google_redis_instance.features.auth_string
    "redis-ca"             = google_redis_instance.features.server_ca_certs[0].cert
  }
  secret_access = merge([
    for name, readers in local.secret_readers : { for r in readers : "${name}|${r}" => { secret = name, sa = r } }
  ]...)
}

resource "google_secret_manager_secret" "s" {
  for_each  = toset(keys(local.secret_readers))
  secret_id = "${local.name}-${each.value}"
  replication {
    user_managed {
      replicas {
        location = var.region
        customer_managed_encryption {
          kms_key_name = google_kms_crypto_key.keys["secrets"].id
        }
      }
    }
  }
  depends_on = [google_kms_crypto_key_iam_member.agents]
}

resource "google_secret_manager_secret_version" "v" {
  for_each    = toset(keys(local.secret_readers))
  secret      = google_secret_manager_secret.s[each.value].id
  secret_data = local.secret_values[each.value]
  lifecycle {
    # Rotations happen outside Terraform (new versions); don't revert them.
    ignore_changes = [secret_data]
  }
}

resource "google_secret_manager_secret_iam_member" "access" {
  for_each   = local.secret_access
  secret_id  = google_secret_manager_secret.s[each.value.secret].id
  role       = "roles/secretmanager.secretAccessor"
  member     = "serviceAccount:${local.sa_email[each.value.sa]}"
  depends_on = [google_service_account.sa]
}
