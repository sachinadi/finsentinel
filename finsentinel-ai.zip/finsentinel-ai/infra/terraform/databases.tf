# ---------------------------------------------------------------- Cloud SQL
# PostgreSQL 16, regional HA, private IP only, CMEK, IAM database auth,
# TLS enforced, PITR backups, pgAudit and connection logging.

resource "random_password" "db_admin" {
  length  = 32
  special = true
}

resource "google_sql_database_instance" "pg" {
  name                = "${local.name}-pg"
  database_version    = "POSTGRES_16"
  region              = var.region
  encryption_key_name = google_kms_crypto_key.keys["sql"].id
  deletion_protection = var.deletion_protection

  settings {
    tier                        = var.sql_tier
    edition                     = "ENTERPRISE"
    availability_type           = "REGIONAL"
    disk_type                   = "PD_SSD"
    disk_autoresize             = true
    deletion_protection_enabled = var.deletion_protection

    ip_configuration {
      ipv4_enabled                                  = false
      private_network                               = google_compute_network.vpc.id
      ssl_mode                                      = "ENCRYPTED_ONLY"
      enable_private_path_for_google_cloud_services = true
    }

    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
      start_time                     = "20:30" # 02:00 IST
      transaction_log_retention_days = 7
      backup_retention_settings {
        retained_backups = 30
      }
    }

    maintenance_window {
      day          = 7  # Sunday
      hour         = 21 # 02:30 IST
      update_track = "stable"
    }

    insights_config {
      query_insights_enabled  = true
      record_client_address   = false
      record_application_tags = true
    }

    password_validation_policy {
      enable_password_policy      = true
      min_length                  = 16
      complexity                  = "COMPLEXITY_DEFAULT"
      disallow_username_substring = true
    }

    database_flags {
      name  = "cloudsql.iam_authentication"
      value = "on"
    }
    database_flags {
      name  = "cloudsql.enable_pgaudit"
      value = "on"
    }
    database_flags {
      name  = "pgaudit.log"
      value = "ddl,role"
    }
    database_flags {
      name  = "log_connections"
      value = "on"
    }
    database_flags {
      name  = "log_disconnections"
      value = "on"
    }
    database_flags {
      name  = "log_min_duration_statement"
      value = "1000"
    }
  }

  depends_on = [google_service_networking_connection.psa, google_kms_crypto_key_iam_member.agents]
}

resource "google_sql_database" "app" {
  name     = "finsentinel"
  instance = google_sql_database_instance.pg.name
}

# Built-in admin: used only by the db-migrate job via Secret Manager.
resource "google_sql_user" "admin" {
  name     = "postgres"
  instance = google_sql_database_instance.pg.name
  password = random_password.db_admin.result
}

resource "google_sql_user" "iam" {
  for_each   = toset(local.db_workloads)
  name       = trimsuffix(local.sa_email[each.value], ".gserviceaccount.com")
  instance   = google_sql_database_instance.pg.name
  type       = "CLOUD_IAM_SERVICE_ACCOUNT"
  depends_on = [google_service_account.sa]
}

# ---------------------------------------------------------------- Memorystore
# Redis for online features, idempotency keys and chat sessions.
# HA with automatic failover, AUTH + in-transit TLS, CMEK, RDB snapshots.

resource "google_redis_instance" "features" {
  name                    = "${local.name}-features"
  tier                    = "STANDARD_HA"
  memory_size_gb          = var.redis_memory_gb
  region                  = var.region
  redis_version           = "REDIS_7_2"
  connect_mode            = "PRIVATE_SERVICE_ACCESS"
  authorized_network      = google_compute_network.vpc.id
  auth_enabled            = true
  transit_encryption_mode = "SERVER_AUTHENTICATION"
  customer_managed_key    = google_kms_crypto_key.keys["redis"].id
  redis_configs = {
    "maxmemory-policy" = "volatile-lru"
  }
  persistence_config {
    persistence_mode    = "RDB"
    rdb_snapshot_period = "ONE_HOUR"
  }
  maintenance_policy {
    weekly_maintenance_window {
      day = "SUNDAY"
      start_time {
        hours   = 21
        minutes = 0
      }
    }
  }
  depends_on = [google_service_networking_connection.psa, google_kms_crypto_key_iam_member.agents]
}
