# Private networking. Cloud Run uses Direct VPC egress with ALL_TRAFFIC, so every
# outbound call goes through this VPC. There is no Cloud NAT: workloads cannot reach
# the public internet. Google APIs and *.run.app resolve to the restricted VIP
# (199.36.153.4/30), which only serves VPC-SC-supported Google APIs.

resource "google_compute_network" "vpc" {
  name                    = "${local.name}-vpc"
  auto_create_subnetworks = false
  routing_mode            = "REGIONAL"
  depends_on              = [google_project_service.apis]
}

resource "google_compute_subnetwork" "run" {
  name                     = "${local.name}-run"
  network                  = google_compute_network.vpc.id
  region                   = var.region
  ip_cidr_range            = "10.10.0.0/22"
  private_ip_google_access = true
  log_config {
    aggregation_interval = "INTERVAL_5_SEC"
    flow_sampling        = 0.5
    metadata             = "INCLUDE_ALL_METADATA"
  }
}

# Private Service Access range for Cloud SQL and Memorystore.
resource "google_compute_global_address" "psa" {
  name          = "${local.name}-psa"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 20
  network       = google_compute_network.vpc.id
}

resource "google_service_networking_connection" "psa" {
  network                 = google_compute_network.vpc.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.psa.name]
}

# Route to the restricted Google APIs VIP.
resource "google_compute_route" "restricted_vip" {
  name             = "${local.name}-restricted-apis"
  network          = google_compute_network.vpc.name
  dest_range       = "199.36.153.4/30"
  next_hop_gateway = "default-internet-gateway"
  priority         = 100
}

# --- Egress firewall: default deny, allow only private ranges + restricted Google APIs
resource "google_compute_firewall" "deny_all_egress" {
  name               = "${local.name}-deny-all-egress"
  network            = google_compute_network.vpc.name
  direction          = "EGRESS"
  priority           = 65000
  destination_ranges = ["0.0.0.0/0"]
  deny { protocol = "all" }
  log_config { metadata = "INCLUDE_ALL_METADATA" }
}

resource "google_compute_firewall" "allow_google_apis" {
  name               = "${local.name}-allow-restricted-apis"
  network            = google_compute_network.vpc.name
  direction          = "EGRESS"
  priority           = 1000
  destination_ranges = ["199.36.153.4/30"]
  allow {
    protocol = "tcp"
    ports    = ["443"]
  }
}

resource "google_compute_firewall" "allow_private_services" {
  name               = "${local.name}-allow-private-services"
  network            = google_compute_network.vpc.name
  direction          = "EGRESS"
  priority           = 1000
  destination_ranges = ["${google_compute_global_address.psa.address}/${google_compute_global_address.psa.prefix_length}"]
  allow {
    protocol = "tcp"
    ports    = ["5432", "3307", "6378", "6379"]
  }
}

# --- Private DNS: send Google APIs and Cloud Run URLs to the restricted VIP.
resource "google_dns_managed_zone" "googleapis" {
  name       = "${local.name}-googleapis"
  dns_name   = "googleapis.com."
  visibility = "private"
  private_visibility_config {
    networks { network_url = google_compute_network.vpc.id }
  }
  depends_on = [google_project_service.apis]
}

resource "google_dns_record_set" "googleapis_a" {
  managed_zone = google_dns_managed_zone.googleapis.name
  name         = "restricted.googleapis.com."
  type         = "A"
  ttl          = 300
  rrdatas      = ["199.36.153.4", "199.36.153.5", "199.36.153.6", "199.36.153.7"]
}

resource "google_dns_record_set" "googleapis_cname" {
  managed_zone = google_dns_managed_zone.googleapis.name
  name         = "*.googleapis.com."
  type         = "CNAME"
  ttl          = 300
  rrdatas      = ["restricted.googleapis.com."]
}

resource "google_dns_managed_zone" "run_app" {
  name       = "${local.name}-run-app"
  dns_name   = "run.app."
  visibility = "private"
  private_visibility_config {
    networks { network_url = google_compute_network.vpc.id }
  }
  depends_on = [google_project_service.apis]
}

resource "google_dns_record_set" "run_app" {
  managed_zone = google_dns_managed_zone.run_app.name
  name         = "*.run.app."
  type         = "A"
  ttl          = 300
  rrdatas      = ["199.36.153.4", "199.36.153.5", "199.36.153.6", "199.36.153.7"]
}
