data "google_project" "this" {
  project_id = var.project_id
}

locals {
  name           = "${var.prefix}-${var.environment}"
  project_number = data.google_project.this.number
  repo           = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.images.repository_id}"
  push_audience  = "finsentinel-push"

  apis = [
    "aiplatform.googleapis.com", "artifactregistry.googleapis.com", "bigquery.googleapis.com",
    "binaryauthorization.googleapis.com", "cloudbuild.googleapis.com", "cloudkms.googleapis.com",
    "compute.googleapis.com", "containerscanning.googleapis.com", "datacatalog.googleapis.com",
    "discoveryengine.googleapis.com", "dlp.googleapis.com", "dns.googleapis.com", "documentai.googleapis.com",
    "iam.googleapis.com", "iap.googleapis.com", "logging.googleapis.com", "monitoring.googleapis.com",
    "pubsub.googleapis.com", "redis.googleapis.com", "run.googleapis.com", "secretmanager.googleapis.com",
    "servicenetworking.googleapis.com", "sqladmin.googleapis.com", "storage.googleapis.com",
    "accesscontextmanager.googleapis.com", "ondemandscanning.googleapis.com",
  ]
}

resource "google_project_service" "apis" {
  for_each           = toset(local.apis)
  service            = each.value
  disable_on_destroy = false
}

# Google-managed service agents that need access to CMEK keys and resources.
resource "google_project_service_identity" "agents" {
  provider = google-beta
  for_each = toset(["pubsub.googleapis.com", "sqladmin.googleapis.com", "secretmanager.googleapis.com",
  "artifactregistry.googleapis.com", "aiplatform.googleapis.com", "iap.googleapis.com"])
  service    = each.value
  depends_on = [google_project_service.apis]
}

data "google_storage_project_service_account" "gcs" {
  depends_on = [google_project_service.apis]
}

data "google_bigquery_default_service_account" "bq" {
  depends_on = [google_project_service.apis]
}

locals {
  agent = {
    pubsub    = google_project_service_identity.agents["pubsub.googleapis.com"].email
    sql       = google_project_service_identity.agents["sqladmin.googleapis.com"].email
    secrets   = google_project_service_identity.agents["secretmanager.googleapis.com"].email
    artifacts = google_project_service_identity.agents["artifactregistry.googleapis.com"].email
    vertex    = google_project_service_identity.agents["aiplatform.googleapis.com"].email
    iap       = google_project_service_identity.agents["iap.googleapis.com"].email
    gcs       = data.google_storage_project_service_account.gcs.email_address
    bq        = data.google_bigquery_default_service_account.bq.email
    redis     = "service-${local.project_number}@cloud-redis.iam.gserviceaccount.com"
  }
}
