variable "project_id" {
  type        = string
  description = "GCP project that hosts the platform (one project per environment)."
}

variable "environment" {
  type    = string
  default = "prod"
  validation {
    condition     = contains(["dev", "uat", "prod"], var.environment)
    error_message = "environment must be dev, uat or prod."
  }
}

variable "region" {
  type        = string
  default     = "asia-south1"
  description = "Primary region. asia-south1 (Mumbai) keeps payment data in India per RBI data-localisation rules."
}

variable "prefix" {
  type    = string
  default = "fs"
}

variable "domain" {
  type        = string
  description = "FQDN for the console and APIs, e.g. finsentinel.bank.example. A DNS A record must point to the LB IP."
}

variable "image_tag" {
  type        = string
  default     = "bootstrap"
  description = "Initial image tag. Cloud Build rolls out new tags afterwards (Terraform ignores image drift)."
}

variable "staff_group" {
  type        = string
  description = "Google group allowed through IAP, e.g. group:fraud-ops@bank.example."
}

variable "role_bindings_json" {
  type        = string
  sensitive   = true
  description = "Initial app-level RBAC map, stored in Secret Manager: {\"alice@bank.example\":[\"analyst\"], ...}"
}

variable "partner_hmac_secrets_json" {
  type        = string
  sensitive   = true
  description = "JSON map of partner_id -> HMAC secret for the ingest API (rotate via Secret Manager versions)."
}

variable "partner_cidrs" {
  type        = list(string)
  default     = []
  description = "Source IP ranges of partner systems allowed to call the ingest API. Empty = any (not recommended)."
}

variable "allowed_country_codes" {
  type        = list(string)
  default     = ["IN"]
  description = "Countries allowed to reach the staff console (Cloud Armor geo policy)."
}

variable "pii_reader_members" {
  type        = list(string)
  default     = []
  description = "Principals allowed to read PII-tagged BigQuery columns (e.g. group:fraud-analytics@bank.example)."
}

variable "alert_email" {
  type = string
}

variable "sql_tier" {
  type    = string
  default = "db-custom-4-16384"
}

variable "redis_memory_gb" {
  type    = number
  default = 5
}

variable "gemini_model" {
  type        = string
  default     = "gemini-3.8-flash"
  description = "Gemini model id on Vertex AI. Check Model Garden for the current stable id in your region."
}

variable "gemini_location" {
  type    = string
  default = "asia-south1"
}

variable "docai_location" {
  type        = string
  default     = "asia-south1"
  description = "Document AI location. OCR and Form Parser are available in asia-south1."
}

variable "search_location" {
  type        = string
  default     = "global"
  description = "Vertex AI Search location (global/us/eu). Only non-personal policy documents are indexed."
}

variable "vertex_endpoint_live" {
  type        = bool
  default     = false
  description = "Set true after ml/train.py has deployed a model to the endpoint; until then the scorecard is used."
}

variable "model_version" {
  type    = string
  default = "xgb-v1"
}

variable "lock_audit_retention" {
  type        = bool
  default     = false
  description = "Irreversibly lock the audit-log bucket retention policy (WORM). Enable in prod once validated."
}

variable "audit_retention_days" {
  type    = number
  default = 1825 # 5 years (PMLA record-keeping)
}

variable "access_policy_id" {
  type        = string
  default     = ""
  description = "Access Context Manager policy id. When set, a VPC Service Controls perimeter is created in dry-run mode."
}

variable "enable_binary_authorization" {
  type    = bool
  default = true
}

variable "deletion_protection" {
  type    = bool
  default = true
}
