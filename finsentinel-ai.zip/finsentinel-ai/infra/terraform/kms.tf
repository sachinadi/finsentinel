# Customer-managed encryption keys (CMEK), one per data domain, rotated every 90 days.
# Keys live in the same region as the data. Use Cloud HSM (protection_level = "HSM")
# where policy requires FIPS 140-2 Level 3.

resource "google_kms_key_ring" "main" {
  name       = "${local.name}-keyring"
  location   = var.region
  depends_on = [google_project_service.apis]
}

locals {
  # key name -> Google service agent that encrypts with it.
  # Keys of this map are static so for_each is known at plan time.
  kms_keys = {
    storage   = local.agent.gcs
    bigquery  = local.agent.bq
    pubsub    = local.agent.pubsub
    sql       = local.agent.sql
    redis     = local.agent.redis
    secrets   = local.agent.secrets
    artifacts = local.agent.artifacts
    vertex    = local.agent.vertex
  }
}

resource "google_kms_crypto_key" "keys" {
  for_each        = local.kms_keys
  name            = "${local.name}-${each.key}"
  key_ring        = google_kms_key_ring.main.id
  rotation_period = "7776000s" # 90 days
  purpose         = "ENCRYPT_DECRYPT"
  version_template {
    algorithm        = "GOOGLE_SYMMETRIC_ENCRYPTION"
    protection_level = var.environment == "prod" ? "HSM" : "SOFTWARE"
  }
  lifecycle {
    prevent_destroy = true
  }
}

resource "google_kms_crypto_key_iam_member" "agents" {
  for_each      = local.kms_keys
  crypto_key_id = google_kms_crypto_key.keys[each.key].id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = "serviceAccount:${each.value}"
}
