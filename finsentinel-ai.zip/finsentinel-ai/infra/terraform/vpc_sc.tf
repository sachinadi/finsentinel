# VPC Service Controls perimeter around the project (data-exfiltration protection).
# Created in DRY-RUN mode: violations are logged, not blocked. After a clean
# observation period, move the spec into `status` (enforced) — see README §7.4.
# Requires an organisation and an Access Context Manager policy.

resource "google_access_context_manager_service_perimeter" "finsentinel" {
  count          = var.access_policy_id == "" ? 0 : 1
  parent         = "accessPolicies/${var.access_policy_id}"
  name           = "accessPolicies/${var.access_policy_id}/servicePerimeters/${replace(local.name, "-", "_")}_perimeter"
  title          = "${local.name}-perimeter"
  perimeter_type = "PERIMETER_TYPE_REGULAR"

  use_explicit_dry_run_spec = true
  spec {
    resources = ["projects/${local.project_number}"]
    restricted_services = [
      "aiplatform.googleapis.com", "bigquery.googleapis.com", "cloudkms.googleapis.com",
      "datacatalog.googleapis.com", "discoveryengine.googleapis.com", "dlp.googleapis.com",
      "documentai.googleapis.com", "logging.googleapis.com", "pubsub.googleapis.com",
      "redis.googleapis.com", "run.googleapis.com", "secretmanager.googleapis.com",
      "sqladmin.googleapis.com", "storage.googleapis.com", "artifactregistry.googleapis.com",
    ]
    vpc_accessible_services {
      enable_restriction = true
      allowed_services   = ["RESTRICTED-SERVICES"]
    }
  }
}
