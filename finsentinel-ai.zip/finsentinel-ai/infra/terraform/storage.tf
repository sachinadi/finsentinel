locals {
  buckets = {
    "raw-docs"     = { versioning = true, retention_days = 0, archive_after = 365 }
    "policies"     = { versioning = true, retention_days = 0, archive_after = 0 }
    "ml-artifacts" = { versioning = true, retention_days = 0, archive_after = 0 }
    "audit-logs"   = { versioning = false, retention_days = var.audit_retention_days, archive_after = 90 }
  }
}

resource "google_storage_bucket" "buckets" {
  for_each                    = local.buckets
  name                        = "${var.project_id}-${local.name}-${each.key}"
  location                    = var.region
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = false

  encryption {
    default_kms_key_name = google_kms_crypto_key.keys["storage"].id
  }

  versioning {
    enabled = each.value.versioning
  }

  soft_delete_policy {
    retention_duration_seconds = 30 * 24 * 3600
  }

  dynamic "retention_policy" {
    for_each = each.value.retention_days > 0 ? [1] : []
    content {
      retention_period = each.value.retention_days * 86400
      is_locked        = var.lock_audit_retention
    }
  }

  dynamic "lifecycle_rule" {
    for_each = each.value.archive_after > 0 ? [1] : []
    content {
      condition { age = each.value.archive_after }
      action {
        type          = "SetStorageClass"
        storage_class = "ARCHIVE"
      }
    }
  }

  # Keep noncurrent versions of documents for 90 days to recover from mistakes.
  dynamic "lifecycle_rule" {
    for_each = each.value.versioning ? [1] : []
    content {
      condition {
        days_since_noncurrent_time = 90
        with_state                 = "ARCHIVED"
      }
      action { type = "Delete" }
    }
  }

  depends_on = [google_kms_crypto_key_iam_member.agents]
}

resource "google_artifact_registry_repository" "images" {
  repository_id = "finsentinel"
  location      = var.region
  format        = "DOCKER"
  kms_key_name  = google_kms_crypto_key.keys["artifacts"].id
  docker_config {
    immutable_tags = true
  }
  cleanup_policies {
    id     = "keep-recent"
    action = "KEEP"
    most_recent_versions { keep_count = 30 }
  }
  depends_on = [google_kms_crypto_key_iam_member.agents]
}
