# One service account per workload, least privilege. No service account keys are
# ever created (enforce with org policy iam.disableServiceAccountKeyCreation).

locals {
  workloads = ["ingest-api", "fraud-engine", "case-service", "doc-intel", "assistant", "console",
  "db-migrate", "ml-training", "pubsub-push", "cloud-build"]

  # project-level roles per workload
  project_roles = {
    "ingest-api" = ["roles/pubsub.publisher", "roles/logging.logWriter", "roles/monitoring.metricWriter",
    "roles/cloudtrace.agent"]
    "fraud-engine" = ["roles/pubsub.publisher", "roles/aiplatform.user", "roles/logging.logWriter",
    "roles/monitoring.metricWriter", "roles/cloudtrace.agent"]
    "case-service" = ["roles/pubsub.publisher", "roles/aiplatform.user", "roles/cloudsql.client",
      "roles/cloudsql.instanceUser", "roles/logging.logWriter", "roles/monitoring.metricWriter",
    "roles/cloudtrace.agent"]
    "doc-intel" = ["roles/pubsub.publisher", "roles/aiplatform.user", "roles/documentai.apiUser",
      "roles/dlp.user", "roles/cloudsql.client", "roles/cloudsql.instanceUser",
    "roles/logging.logWriter", "roles/monitoring.metricWriter", "roles/cloudtrace.agent"]
    "assistant" = ["roles/aiplatform.user", "roles/discoveryengine.viewer", "roles/bigquery.jobUser",
      "roles/cloudsql.client", "roles/cloudsql.instanceUser", "roles/logging.logWriter",
    "roles/monitoring.metricWriter", "roles/cloudtrace.agent"]
    "console"     = ["roles/logging.logWriter"]
    "db-migrate"  = ["roles/cloudsql.client", "roles/logging.logWriter"]
    "ml-training" = ["roles/aiplatform.user", "roles/bigquery.jobUser", "roles/logging.logWriter"]
    "pubsub-push" = []
    "cloud-build" = ["roles/run.developer", "roles/logging.logWriter", "roles/containeranalysis.notes.attacher",
    "roles/binaryauthorization.attestorsViewer", "roles/ondemandscanning.admin"]
  }
  project_bindings = merge([
    for w, roles in local.project_roles : { for r in roles : "${w}|${r}" => { sa = w, role = r } }
  ]...)

  # Deterministic emails, usable in for_each keys at plan time.
  sa_email = { for w in local.workloads : w => "${var.prefix}-${w}@${var.project_id}.iam.gserviceaccount.com" }

  # Cloud SQL IAM database users (no passwords in apps)
  db_workloads = ["case-service", "doc-intel", "assistant"]
}

resource "google_service_account" "sa" {
  for_each     = toset(local.workloads)
  account_id   = "${var.prefix}-${each.key}"
  display_name = "FinSentinel ${each.key}"
}

resource "google_project_iam_member" "workload" {
  for_each = local.project_bindings
  project  = var.project_id
  role     = each.value.role
  member   = "serviceAccount:${google_service_account.sa[each.value.sa].email}"
}

# Cloud Build may deploy Cloud Run revisions that run as the workload SAs.
resource "google_service_account_iam_member" "build_act_as" {
  for_each           = toset(["ingest-api", "fraud-engine", "case-service", "doc-intel", "assistant", "console", "db-migrate"])
  service_account_id = google_service_account.sa[each.value].name
  role               = "roles/iam.serviceAccountUser"
  member             = "serviceAccount:${google_service_account.sa["cloud-build"].email}"
}

resource "google_artifact_registry_repository_iam_member" "build_writer" {
  location   = google_artifact_registry_repository.images.location
  repository = google_artifact_registry_repository.images.name
  role       = "roles/artifactregistry.writer"
  member     = "serviceAccount:${google_service_account.sa["cloud-build"].email}"
}

# Pub/Sub service agent mints OIDC tokens for the push identity.
resource "google_service_account_iam_member" "pubsub_token_creator" {
  service_account_id = google_service_account.sa["pubsub-push"].name
  role               = "roles/iam.serviceAccountTokenCreator"
  member             = "serviceAccount:${local.agent.pubsub}"
}

# Training reads the feature/label tables, including PII-tagged columns, and writes artifacts.
resource "google_bigquery_dataset_iam_member" "training_reader" {
  dataset_id = google_bigquery_dataset.main.dataset_id
  role       = "roles/bigquery.dataViewer"
  member     = "serviceAccount:${google_service_account.sa["ml-training"].email}"
}

resource "google_bigquery_dataset_iam_member" "assistant_reader" {
  dataset_id = google_bigquery_dataset.main.dataset_id
  role       = "roles/bigquery.dataViewer"
  member     = "serviceAccount:${google_service_account.sa["assistant"].email}"
}

resource "google_storage_bucket_iam_member" "training_artifacts" {
  bucket = google_storage_bucket.buckets["ml-artifacts"].name
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${google_service_account.sa["ml-training"].email}"
}

# Vertex AI reads model artifacts when deploying; Gemini/Doc AI read uploaded documents.
resource "google_storage_bucket_iam_member" "vertex_reads_artifacts" {
  bucket = google_storage_bucket.buckets["ml-artifacts"].name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${local.agent.vertex}"
}

resource "google_storage_bucket_iam_member" "docintel_raw_docs" {
  bucket = google_storage_bucket.buckets["raw-docs"].name
  role   = "roles/storage.objectCreator"
  member = "serviceAccount:${google_service_account.sa["doc-intel"].email}"
}

resource "google_storage_bucket_iam_member" "docintel_raw_docs_read" {
  bucket = google_storage_bucket.buckets["raw-docs"].name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.sa["doc-intel"].email}"
}

# Gemini on Vertex AI reads gs:// URIs with the Vertex AI service agent.
resource "google_storage_bucket_iam_member" "vertex_reads_docs" {
  bucket = google_storage_bucket.buckets["raw-docs"].name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${local.agent.vertex}"
}

# Secret access is granted per secret (see secrets.tf), never project-wide.
