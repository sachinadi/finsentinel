terraform {
  required_version = ">= 1.6"
  required_providers {
    google      = { source = "hashicorp/google", version = ">= 6.20, < 8.0" }
    google-beta = { source = "hashicorp/google-beta", version = ">= 6.20, < 8.0" }
    random      = { source = "hashicorp/random", version = ">= 3.6" }
  }
  # Remote state in a CMEK-protected, versioned bucket (create once, see README §6.2).
  backend "gcs" {}
}

provider "google" {
  project = var.project_id
  region  = var.region
  default_labels = {
    app         = "finsentinel"
    environment = var.environment
    managed-by  = "terraform"
  }
}

provider "google-beta" {
  project = var.project_id
  region  = var.region
}
