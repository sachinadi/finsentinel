output "load_balancer_ip" {
  value       = google_compute_global_address.lb.address
  description = "Create a DNS A record for var.domain pointing here."
}

output "console_url" {
  value = "https://${var.domain}"
}

output "ingest_endpoint" {
  value = "https://${var.domain}/api/v1/transactions"
}

output "artifact_registry" {
  value = local.repo
}

output "vertex_endpoint_id" {
  value = google_vertex_ai_endpoint.fraud.name
}

output "policy_bucket" {
  value = google_storage_bucket.buckets["policies"].name
}

output "ml_artifacts_bucket" {
  value = google_storage_bucket.buckets["ml-artifacts"].name
}

output "search_data_store_id" {
  value = google_discovery_engine_data_store.policies.data_store_id
}

output "bigquery_dataset" {
  value = google_bigquery_dataset.main.dataset_id
}

output "cloud_build_service_account" {
  value = google_service_account.sa["cloud-build"].email
}

output "ml_training_service_account" {
  value = google_service_account.sa["ml-training"].email
}

output "service_urls" {
  value = { for k, s in google_cloud_run_v2_service.svc : k => s.uri }
}
