# Event backbone. Topics are CMEK-encrypted and pinned to the primary region
# (message_storage_policy) for data residency. Every push subscription has a
# dead-letter topic, exponential backoff and an OIDC identity.

locals {
  topics = ["transactions", "fraud-decisions", "fraud-alerts", "case-feedback", "doc-uploaded", "doc-results"]

  push_subscriptions = {
    "transactions-fraud-engine" = { topic = "transactions", service = "fraud-engine", path = "/pubsub/transactions", ordered = true, ack = 60 }
    "fraud-alerts-case-service" = { topic = "fraud-alerts", service = "case-service", path = "/pubsub/alerts", ordered = false, ack = 120 }
    "doc-uploaded-doc-intel"    = { topic = "doc-uploaded", service = "doc-intel", path = "/pubsub/documents", ordered = false, ack = 600 }
  }

  bq_subscriptions = {
    "fraud-decisions-bq" = { topic = "fraud-decisions", table = google_bigquery_table.transactions_scored.table_id }
    "case-feedback-bq"   = { topic = "case-feedback", table = google_bigquery_table.case_feedback.table_id }
    "doc-results-bq"     = { topic = "doc-results", table = google_bigquery_table.document_results.table_id }
  }

  dlq_for = toset(concat(keys(local.push_subscriptions), keys(local.bq_subscriptions)))
}

resource "google_pubsub_topic" "topics" {
  for_each                   = toset(local.topics)
  name                       = each.value
  kms_key_name               = google_kms_crypto_key.keys["pubsub"].id
  message_retention_duration = "604800s" # 7 days replay window
  message_storage_policy {
    allowed_persistence_regions = [var.region]
  }
  depends_on = [google_kms_crypto_key_iam_member.agents]
}

resource "google_pubsub_topic" "dlq" {
  for_each     = local.dlq_for
  name         = "${each.value}-dlq"
  kms_key_name = google_kms_crypto_key.keys["pubsub"].id
  message_storage_policy {
    allowed_persistence_regions = [var.region]
  }
  depends_on = [google_kms_crypto_key_iam_member.agents]
}

# Hold dead-lettered messages for inspection/replay; alerting watches the backlog.
resource "google_pubsub_subscription" "dlq_hold" {
  for_each                   = local.dlq_for
  name                       = "${each.value}-dlq-hold"
  topic                      = google_pubsub_topic.dlq[each.value].id
  message_retention_duration = "604800s"
  expiration_policy { ttl = "" }
}

resource "google_pubsub_subscription" "push" {
  for_each                = local.push_subscriptions
  name                    = each.key
  topic                   = google_pubsub_topic.topics[each.value.topic].id
  ack_deadline_seconds    = each.value.ack
  enable_message_ordering = each.value.ordered
  expiration_policy { ttl = "" }

  push_config {
    push_endpoint = "${google_cloud_run_v2_service.svc[each.value.service].uri}${each.value.path}"
    oidc_token {
      service_account_email = google_service_account.sa["pubsub-push"].email
      audience              = local.push_audience
    }
  }

  retry_policy {
    minimum_backoff = "5s"
    maximum_backoff = "300s"
  }

  dead_letter_policy {
    dead_letter_topic     = google_pubsub_topic.dlq[each.key].id
    max_delivery_attempts = 10
  }
}

resource "google_pubsub_subscription" "bq" {
  for_each = local.bq_subscriptions
  name     = each.key
  topic    = google_pubsub_topic.topics[each.value.topic].id
  expiration_policy { ttl = "" }

  bigquery_config {
    table               = "${var.project_id}.${google_bigquery_dataset.main.dataset_id}.${each.value.table}"
    use_table_schema    = true
    drop_unknown_fields = true
    write_metadata      = false
  }

  dead_letter_policy {
    dead_letter_topic     = google_pubsub_topic.dlq[each.key].id
    max_delivery_attempts = 10
  }

  depends_on = [google_bigquery_dataset_iam_member.pubsub_writer]
}

# Pub/Sub agent must be able to publish to DLQs and ack from the source subscriptions.
resource "google_pubsub_topic_iam_member" "dlq_publisher" {
  for_each = local.dlq_for
  topic    = google_pubsub_topic.dlq[each.value].name
  role     = "roles/pubsub.publisher"
  member   = "serviceAccount:${local.agent.pubsub}"
}

resource "google_pubsub_subscription_iam_member" "dlq_subscriber" {
  for_each = merge(
    { for k, _ in local.push_subscriptions : k => google_pubsub_subscription.push[k].name },
    { for k, _ in local.bq_subscriptions : k => google_pubsub_subscription.bq[k].name },
  )
  subscription = each.value
  role         = "roles/pubsub.subscriber"
  member       = "serviceAccount:${local.agent.pubsub}"
}

# The push identity may invoke only the services it delivers to.
resource "google_cloud_run_v2_service_iam_member" "push_invoker" {
  for_each = toset([for s in local.push_subscriptions : s.service])
  name     = google_cloud_run_v2_service.svc[each.value].name
  location = var.region
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.sa["pubsub-push"].email}"
}
