# Analytics warehouse. Every scored transaction, analyst label and document result
# streams in via Pub/Sub BigQuery subscriptions (no ETL code to maintain).
# Identifiers are protected with column-level security (policy tags).

resource "google_data_catalog_taxonomy" "pii" {
  display_name           = "${local.name}-pii"
  description            = "Column-level protection for customer identifiers"
  region                 = var.region
  activated_policy_types = ["FINE_GRAINED_ACCESS_CONTROL"]
  depends_on             = [google_project_service.apis]
}

resource "google_data_catalog_policy_tag" "restricted" {
  taxonomy     = google_data_catalog_taxonomy.pii.id
  display_name = "restricted_customer_identifier"
  description  = "Account and customer identifiers. Readers require explicit approval."
}

resource "google_data_catalog_policy_tag_iam_member" "readers" {
  for_each = toset(concat(var.pii_reader_members, [
    "serviceAccount:${local.sa_email["assistant"]}",
    "serviceAccount:${local.sa_email["ml-training"]}",
  ]))
  policy_tag = google_data_catalog_policy_tag.restricted.name
  role       = "roles/datacatalog.categoryFineGrainedReader"
  member     = each.value
  depends_on = [google_service_account.sa]
}

resource "google_bigquery_dataset" "main" {
  dataset_id                 = replace("finsentinel_${var.environment}", "-", "_")
  location                   = var.region
  description                = "FinSentinel decisions, labels and document analytics"
  delete_contents_on_destroy = false
  default_encryption_configuration {
    kms_key_name = google_kms_crypto_key.keys["bigquery"].id
  }
  depends_on = [google_kms_crypto_key_iam_member.agents]
}

resource "google_bigquery_table" "transactions_scored" {
  dataset_id          = google_bigquery_dataset.main.dataset_id
  table_id            = "transactions_scored"
  deletion_protection = var.deletion_protection
  schema = templatefile("${path.module}/../../sql/bigquery/transactions_scored.json.tftpl", {
    pii_policy_tag = google_data_catalog_policy_tag.restricted.name
  })
  time_partitioning {
    type          = "DAY"
    field         = "event_time"
    expiration_ms = null
  }
  clustering = ["decision", "channel", "customer_id"]
}

resource "google_bigquery_table" "case_feedback" {
  dataset_id          = google_bigquery_dataset.main.dataset_id
  table_id            = "case_feedback"
  deletion_protection = var.deletion_protection
  schema              = file("${path.module}/../../sql/bigquery/case_feedback.json")
  time_partitioning {
    type  = "DAY"
    field = "closed_at"
  }
}

resource "google_bigquery_table" "document_results" {
  dataset_id          = google_bigquery_dataset.main.dataset_id
  table_id            = "document_results"
  deletion_protection = var.deletion_protection
  schema              = file("${path.module}/../../sql/bigquery/document_results.json")
  time_partitioning {
    type  = "DAY"
    field = "processed_at"
  }
}

resource "google_bigquery_table" "training_examples" {
  dataset_id          = google_bigquery_dataset.main.dataset_id
  table_id            = "training_examples"
  deletion_protection = false
  view {
    query = templatefile("${path.module}/../../sql/bigquery/training_view.sql", {
      project = var.project_id
      dataset = google_bigquery_dataset.main.dataset_id
    })
    use_legacy_sql = false
  }
  depends_on = [google_bigquery_table.transactions_scored, google_bigquery_table.case_feedback]
}

# Pub/Sub service agent writes to the tables through BigQuery subscriptions.
resource "google_bigquery_dataset_iam_member" "pubsub_writer" {
  for_each   = toset(["roles/bigquery.dataEditor", "roles/bigquery.metadataViewer"])
  dataset_id = google_bigquery_dataset.main.dataset_id
  role       = each.value
  member     = "serviceAccount:${local.agent.pubsub}"
}
