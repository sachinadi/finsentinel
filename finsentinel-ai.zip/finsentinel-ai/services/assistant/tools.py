"""Tools the compliance copilot may call. Every call is authorised and audited."""

from __future__ import annotations

import logging
import re
from functools import lru_cache

from sqlalchemy import text

from finsentinel_common import audit
from finsentinel_common.config import get_settings
from finsentinel_common.db import rows, tx
from finsentinel_common.security import Principal

logger = logging.getLogger(__name__)

DECLARATIONS = [
    {
        "name": "search_policies",
        "description": "Search the bank's indexed policies, procedures and regulatory circulars "
                       "(e.g. RBI master directions, KYC/AML policy, fraud SOPs). Use for any policy or regulation question.",
        "parameters": {"type": "OBJECT", "properties": {"query": {"type": "STRING"}}, "required": ["query"]},
    },
    {
        "name": "get_case",
        "description": "Fetch a fraud/AML case summary by case id (UUID): severity, status, rule hits, AI summary.",
        "parameters": {"type": "OBJECT", "properties": {"case_id": {"type": "STRING"}}, "required": ["case_id"]},
    },
    {
        "name": "customer_risk_profile",
        "description": "90-day risk profile for a customer id from the analytics warehouse: decision counts, "
                       "volumes, typologies.",
        "parameters": {"type": "OBJECT", "properties": {"customer_id": {"type": "STRING"}}, "required": ["customer_id"]},
    },
]

_UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
_CUST = re.compile(r"^[A-Za-z0-9_\-]{4,64}$")


@lru_cache(maxsize=1)
def _search_client():
    from google.api_core.client_options import ClientOptions
    from google.cloud import discoveryengine_v1 as de

    loc = get_settings().search_location
    opts = ClientOptions(api_endpoint=f"{loc}-discoveryengine.googleapis.com") if loc != "global" else None
    return de.SearchServiceClient(client_options=opts)


def search_policies(query: str) -> dict:
    s = get_settings()
    if not s.search_engine_id:
        return {"results": [], "note": "policy search not configured in this environment"}
    from google.cloud import discoveryengine_v1 as de

    serving_config = (f"projects/{s.project_id}/locations/{s.search_location}/collections/default_collection/"
                      f"engines/{s.search_engine_id}/servingConfigs/default_search")
    req = de.SearchRequest(
        serving_config=serving_config, query=query[:500], page_size=5,
        content_search_spec=de.SearchRequest.ContentSearchSpec(
            snippet_spec=de.SearchRequest.ContentSearchSpec.SnippetSpec(return_snippet=True),
            extractive_content_spec=de.SearchRequest.ContentSearchSpec.ExtractiveContentSpec(
                max_extractive_answer_count=2),
        ),
    )
    results = []
    for i, r in enumerate(_search_client().search(req).results, start=1):
        data = dict(r.document.derived_struct_data or {})
        snippets = [dict(x).get("snippet", "") for x in data.get("snippets", [])]
        answers = [dict(x).get("content", "") for x in data.get("extractive_answers", [])]
        results.append({"ref": i, "title": data.get("title", r.document.id), "link": data.get("link", ""),
                        "extract": " ".join(answers)[:1500] or " ".join(snippets)[:800]})
    return {"results": results}


def get_case(case_id: str) -> dict:
    if not _UUID.match(case_id or ""):
        return {"error": "invalid case id"}
    with tx() as conn:
        found = rows(conn.execute(text(
            "SELECT id, severity, status, decision, risk_score, typologies, channel, amount, currency, "
            "rule_hits, ai_summary, disposition, created_at, sla_due_at FROM cases WHERE id = CAST(:id AS UUID)"),
            {"id": case_id}))
    if not found:
        return {"error": "case not found"}
    c = found[0]
    return {k: (str(v) if k in ("id", "created_at", "sla_due_at") else (float(v) if k in ("risk_score", "amount") else v))
            for k, v in c.items()}


def customer_risk_profile(customer_id: str) -> dict:
    if not _CUST.match(customer_id or ""):
        return {"error": "invalid customer id"}
    s = get_settings()
    from google.cloud import bigquery

    client = bigquery.Client(project=s.project_id, location=s.region)
    # Table path comes from deployment config, never user input; customer_id is a bound parameter.
    table = f"`{s.project_id}.{s.bq_dataset}.transactions_scored`"
    sql = f"""
      SELECT decision, COUNT(*) AS n, ROUND(SUM(amount), 2) AS total_amount,
             ARRAY_AGG(DISTINCT h.typology IGNORE NULLS LIMIT 10) AS typologies
      FROM {table} t
      LEFT JOIN UNNEST(t.rule_hits) h
      WHERE customer_id = @cid AND DATE(event_time) >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)
      GROUP BY decision"""  # nosec B608
    job = client.query(sql, job_config=bigquery.QueryJobConfig(
        query_parameters=[bigquery.ScalarQueryParameter("cid", "STRING", customer_id)],
        maximum_bytes_billed=2 * 1024**3, labels={"app": "finsentinel", "caller": "assistant"}))
    return {"customer_id": customer_id, "window_days": 90,
            "by_decision": [dict(r.items()) for r in job.result(timeout=20)]}


def execute(name: str, args: dict, principal: Principal) -> dict:
    """Authorise, run and audit a tool call."""
    handlers = {"search_policies": search_policies, "get_case": get_case,
                "customer_risk_profile": customer_risk_profile}
    if name not in handlers:
        return {"error": f"unknown tool {name}"}
    if name in ("get_case", "customer_risk_profile") and not principal.has("analyst") and not principal.has("supervisor"):
        return {"error": "not authorised for customer or case data"}
    try:
        result = handlers[name](**args)
    except TypeError:
        result = {"error": "bad arguments"}
    except Exception as exc:  # noqa: BLE001
        logger.warning("tool %s failed: %s", name, type(exc).__name__)
        result = {"error": "tool unavailable"}
    entity = args.get("case_id") or args.get("customer_id") or "policy-search"
    audit.record(principal.email, f"ASSISTANT_TOOL_{name.upper()}", "assistant", str(entity),
                 {"ok": "error" not in result})
    return result
