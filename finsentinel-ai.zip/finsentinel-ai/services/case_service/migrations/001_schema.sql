-- FinSentinel AI — operational schema (Cloud SQL for PostgreSQL 16)
-- Applied by the `db-migrate` Cloud Run job (services/case_service/migrate.py). Idempotent.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------- roles
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'finsentinel_app') THEN
    CREATE ROLE finsentinel_app NOLOGIN;
  END IF;
END $$;

-- ---------------------------------------------------------------- cases
CREATE TABLE IF NOT EXISTS cases (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id     TEXT NOT NULL UNIQUE,
  account_id         TEXT NOT NULL,
  customer_id        TEXT NOT NULL,
  severity           TEXT NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
  status             TEXT NOT NULL DEFAULT 'OPEN'
                     CHECK (status IN ('OPEN','IN_PROGRESS','PENDING_APPROVAL','CLOSED')),
  decision           TEXT NOT NULL,
  risk_score         NUMERIC(6,4) NOT NULL,
  typologies         TEXT[] NOT NULL DEFAULT '{}',
  amount             NUMERIC(18,2) NOT NULL,
  currency           CHAR(3) NOT NULL,
  channel            TEXT NOT NULL,
  rule_hits          JSONB NOT NULL DEFAULT '[]',
  top_features       JSONB NOT NULL DEFAULT '{}',
  regulatory_flags   TEXT[] NOT NULL DEFAULT '{}',
  transaction        JSONB NOT NULL,
  ai_summary         JSONB,
  assigned_to        TEXT,
  disposition        TEXT CHECK (disposition IN ('CONFIRMED_FRAUD','FALSE_POSITIVE','ESCALATED','STR_FILED','CTR_FILED')),
  disposition_notes  TEXT,
  proposed_by        TEXT,
  approved_by        TEXT,
  sla_due_at         TIMESTAMPTZ NOT NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at          TIMESTAMPTZ,
  -- Maker-checker: approver must differ from proposer.
  CONSTRAINT four_eyes CHECK (approved_by IS NULL OR approved_by <> proposed_by)
);
CREATE INDEX IF NOT EXISTS cases_queue_idx ON cases (status, severity, sla_due_at);
CREATE INDEX IF NOT EXISTS cases_customer_idx ON cases (customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS cases_assignee_idx ON cases (assigned_to) WHERE status <> 'CLOSED';

-- ------------------------------------------------------------- documents
CREATE TABLE IF NOT EXISTS documents (
  id            UUID PRIMARY KEY,
  customer_id   TEXT NOT NULL,
  doc_type      TEXT NOT NULL,
  gcs_uri       TEXT NOT NULL,
  sha256        CHAR(64) NOT NULL,
  mime_type     TEXT NOT NULL,
  size_bytes    INTEGER NOT NULL,
  status        TEXT NOT NULL DEFAULT 'UPLOADED'
                CHECK (status IN ('UPLOADED','PROCESSING','PROCESSED','FAILED','NEEDS_REVIEW')),
  extracted     JSONB,
  checks        JSONB,
  risk_level    TEXT,
  uploaded_by   TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS documents_customer_idx ON documents (customer_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS documents_dedupe_idx ON documents (customer_id, doc_type, sha256);

-- ------------------------------------------------------------- audit log
CREATE TABLE IF NOT EXISTS audit_log (
  id           BIGSERIAL PRIMARY KEY,
  ts           TIMESTAMPTZ NOT NULL DEFAULT now(),
  actor        TEXT NOT NULL,
  action       TEXT NOT NULL,
  entity_type  TEXT NOT NULL,
  entity_id    TEXT NOT NULL,
  details      JSONB NOT NULL DEFAULT '{}',
  prev_hash    CHAR(64),
  row_hash     CHAR(64)
);
CREATE INDEX IF NOT EXISTS audit_entity_idx ON audit_log (entity_type, entity_id, id);

-- Hash chain: each row commits to the previous row. Ids are assigned under the
-- lock so chain order == id order even with concurrent writers.
CREATE OR REPLACE FUNCTION audit_chain() RETURNS trigger AS $$
DECLARE prev TEXT;
BEGIN
  PERFORM pg_advisory_xact_lock(7428310);
  NEW.id := nextval(pg_get_serial_sequence('audit_log', 'id'));
  NEW.ts := clock_timestamp();
  SELECT row_hash INTO prev FROM audit_log ORDER BY id DESC LIMIT 1;
  NEW.prev_hash := COALESCE(prev, repeat('0', 64));
  NEW.row_hash := encode(sha256(convert_to(
      NEW.prev_hash || '|' || NEW.id::text || '|' || extract(epoch FROM NEW.ts)::text || '|' ||
      NEW.actor || '|' || NEW.action || '|' || NEW.entity_type || '|' || NEW.entity_id || '|' ||
      NEW.details::text, 'UTF8')), 'hex');
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS audit_chain_trg ON audit_log;
CREATE TRIGGER audit_chain_trg BEFORE INSERT ON audit_log FOR EACH ROW EXECUTE FUNCTION audit_chain();

-- Append-only: block UPDATE/DELETE even for privileged sessions that bypass grants.
CREATE OR REPLACE FUNCTION audit_immutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_log is append-only';
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS audit_immutable_trg ON audit_log;
CREATE TRIGGER audit_immutable_trg BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION audit_immutable();

-- Returns the id of the first row whose hash does not verify (NULL if intact).
CREATE OR REPLACE FUNCTION audit_verify_chain(max_rows BIGINT) RETURNS TABLE(first_broken_id BIGINT) AS $$
DECLARE r RECORD; expected_prev TEXT := repeat('0', 64); calc TEXT;
BEGIN
  FOR r IN SELECT * FROM audit_log ORDER BY id LIMIT max_rows LOOP
    calc := encode(sha256(convert_to(
        r.prev_hash || '|' || r.id::text || '|' || extract(epoch FROM r.ts)::text || '|' ||
        r.actor || '|' || r.action || '|' || r.entity_type || '|' || r.entity_id || '|' ||
        r.details::text, 'UTF8')), 'hex');
    IF r.prev_hash <> expected_prev OR r.row_hash <> calc THEN
      first_broken_id := r.id; RETURN NEXT; RETURN;
    END IF;
    expected_prev := r.row_hash;
  END LOOP;
  RETURN;
END $$ LANGUAGE plpgsql STABLE;

-- ---------------------------------------------------------------- grants
GRANT USAGE ON SCHEMA public TO finsentinel_app;
GRANT SELECT, INSERT, UPDATE ON cases, documents TO finsentinel_app;
GRANT SELECT, INSERT ON audit_log TO finsentinel_app;          -- no UPDATE/DELETE
GRANT USAGE ON SEQUENCE audit_log_id_seq TO finsentinel_app;
GRANT EXECUTE ON FUNCTION audit_verify_chain(BIGINT) TO finsentinel_app;
