"""Database migration job (runs as the `db-migrate` Cloud Run job).

Connects as the built-in `postgres` user (password from Secret Manager, only
mounted into this job), applies migrations/*.sql in order, and grants the
application role to the IAM database users of each service account.
Services themselves never hold a database password.

Usage:  python migrate.py
Env:    CLOUDSQL_INSTANCE, DB_NAME, DB_ADMIN_PASSWORD, APP_DB_USERS (comma-separated IAM users)
        or MIGRATE_DSN=postgresql://user:pass@host:5432/db for local runs.
"""

from __future__ import annotations

import asyncio
import os
import pathlib
import re

import asyncpg

MIGRATIONS = sorted((pathlib.Path(__file__).parent / "migrations").glob("*.sql"))
_IDENT = re.compile(r"^[A-Za-z0-9_.@-]+$")


async def _connect():
    dsn = os.getenv("MIGRATE_DSN")
    if dsn:
        return await asyncpg.connect(dsn)
    from google.cloud.sql.connector import Connector, IPTypes, create_async_connector

    connector: Connector = await create_async_connector()
    return await connector.connect_async(
        os.environ["CLOUDSQL_INSTANCE"], "asyncpg",
        user="postgres", password=os.environ["DB_ADMIN_PASSWORD"],
        db=os.getenv("DB_NAME", "finsentinel"), ip_type=IPTypes.PRIVATE,
    )


async def main() -> None:
    conn = await _connect()
    try:
        await conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ DEFAULT now())")
        for path in MIGRATIONS:
            done = await conn.fetchval("SELECT 1 FROM schema_migrations WHERE name = $1", path.name)
            if done:
                print(f"skip  {path.name}")
                continue
            async with conn.transaction():
                await conn.execute(path.read_text())
                await conn.execute("INSERT INTO schema_migrations(name) VALUES ($1)", path.name)
            print(f"apply {path.name}")

        for user in filter(None, (u.strip() for u in os.getenv("APP_DB_USERS", "").split(","))):
            if not _IDENT.match(user):
                raise ValueError(f"refusing suspicious db user name: {user!r}")
            exists = await conn.fetchval("SELECT 1 FROM pg_roles WHERE rolname = $1", user)
            if exists:
                await conn.execute(f'GRANT finsentinel_app TO "{user}"')
                print(f"grant finsentinel_app -> {user}")
            else:
                print(f"warn  IAM user {user} not found (create it with Terraform first)")
    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(main())
