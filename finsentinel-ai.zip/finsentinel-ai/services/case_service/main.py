"""Case Service — alert triage, investigation and maker-checker disposition.

Consumes `fraud-alerts`, opens a case with SLA and AI summary, and exposes
the analyst API used by the console. Closed cases publish labelled feedback
to `case-feedback` (BigQuery) which drives model retraining.
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Literal

from fastapi import Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import text

from finsentinel_common import audit
from finsentinel_common.config import get_settings
from finsentinel_common.db import rows, tx
from finsentinel_common.http import create_app
from finsentinel_common.logging_setup import log
from finsentinel_common.pubsub import decode_push, publish
from finsentinel_common.security import Principal, require_role, verify_pubsub_push

import investigator

logger = logging.getLogger("case_service")
settings = get_settings()
app = create_app("FinSentinel Case Service")

SLA = {"CRITICAL": timedelta(hours=1), "HIGH": timedelta(hours=4), "MEDIUM": timedelta(hours=24), "LOW": timedelta(hours=72)}
NEEDS_APPROVAL = {"HIGH", "CRITICAL"}
POSITIVE = {"CONFIRMED_FRAUD", "STR_FILED"}

analyst = require_role("analyst", "supervisor")
supervisor = require_role("supervisor")
auditor = require_role("auditor", "supervisor")


def severity_for(decision: dict) -> str:
    hits = decision.get("rule_hits", [])
    if any(h.get("hard_block") for h in hits) or (decision["decision"] == "BLOCK" and decision["risk_score"] >= 0.95):
        return "CRITICAL"
    if decision["decision"] == "BLOCK":
        return "HIGH"
    if decision["decision"] == "REVIEW" and decision["risk_score"] >= 0.7:
        return "MEDIUM"
    return "LOW"


def _jsonable(case: dict) -> dict:
    out = {}
    for k, v in case.items():
        if isinstance(v, datetime):
            out[k] = v.isoformat()
        elif isinstance(v, uuid.UUID):
            out[k] = str(v)
        elif hasattr(v, "is_finite"):  # Decimal
            out[k] = float(v)
        else:
            out[k] = v
    return out


def _load(conn, case_id: str, lock: bool = False) -> dict:
    q = "SELECT * FROM cases WHERE id = CAST(:id AS UUID)" + (" FOR UPDATE" if lock else "")  # nosec B608 - constant suffix
    found = rows(conn.execute(text(q), {"id": case_id}))
    if not found:
        raise HTTPException(404, "case not found")
    return _jsonable(found[0])


# ------------------------------------------------------------------ ingest
@app.post("/pubsub/alerts", dependencies=[Depends(verify_pubsub_push)])
async def on_alert(request: Request):
    payload, _, _ = decode_push(await request.json())
    d, t = payload["decision"], payload["transaction"]
    sev = severity_for(d)
    typologies = sorted({h["typology"] for h in d.get("rule_hits", [])}) or (
        ["REGULATORY"] if d["decision"] == "APPROVE" else ["MODEL_SCORE"])
    now = datetime.now(timezone.utc)
    case = {
        **d, "transaction": t, "severity": sev, "typologies": typologies,
    }
    with tx() as conn:
        inserted = conn.execute(text("""
            INSERT INTO cases (transaction_id, account_id, customer_id, severity, decision, risk_score,
                               typologies, amount, currency, channel, rule_hits, top_features,
                               regulatory_flags, transaction, sla_due_at)
            VALUES (:tid, :acct, :cust, :sev, :dec, :risk, :typ, :amt, :cur, :chan,
                    CAST(:hits AS JSONB), CAST(:feat AS JSONB), :flags, CAST(:txn AS JSONB), :sla)
            ON CONFLICT (transaction_id) DO NOTHING
            RETURNING id
        """), dict(tid=d["transaction_id"], acct=d["account_id"], cust=d["customer_id"], sev=sev,
                   dec=d["decision"], risk=d["risk_score"], typ=typologies, amt=d["amount"],
                   cur=d["currency"], chan=d["channel"], hits=json.dumps(d.get("rule_hits", [])),
                   feat=json.dumps(d.get("top_features", {})), flags=d.get("regulatory_flags", []),
                   txn=json.dumps(t), sla=now + SLA[sev])).first()
        if inserted is None:
            return {"status": "duplicate"}
        case_id = str(inserted[0])
        prior = conn.execute(text(
            "SELECT count(*) FROM cases WHERE customer_id = :c AND created_at > now() - interval '180 days' "
            "AND id <> CAST(:id AS UUID)"), {"c": d["customer_id"], "id": case_id}).scalar()
        audit.record("system:fraud-engine", "CASE_OPENED", "case", case_id,
                     {"severity": sev, "risk": d["risk_score"], "typologies": typologies}, conn=conn)

    # AI summary outside the DB transaction (network call); failures don't lose the case.
    summary = investigator.summarise(case, prior_cases=int(prior or 0))
    with tx() as conn:
        conn.execute(text("UPDATE cases SET ai_summary = CAST(:s AS JSONB), updated_at = now() WHERE id = CAST(:id AS UUID)"),
                     {"s": json.dumps(summary), "id": case_id})
        audit.record("system:gemini", "AI_SUMMARY_GENERATED", "case", case_id,
                     {"model": settings.gemini_model, "generated_by": summary.get("generated_by")}, conn=conn)
    log(logger, logging.INFO, "case opened", case_id=case_id, severity=sev)
    return {"status": "created", "case_id": case_id}


# --------------------------------------------------------------- analyst API
@app.get("/api/cases")
def list_cases(
    status: str | None = Query(None, pattern="^(OPEN|IN_PROGRESS|PENDING_APPROVAL|CLOSED)$"),
    severity: str | None = Query(None, pattern="^(LOW|MEDIUM|HIGH|CRITICAL)$"),
    mine: bool = False,
    limit: int = Query(50, ge=1, le=200),
    p: Principal = Depends(analyst),
):
    clauses, params = [], {"lim": limit}
    if status:
        clauses.append("status = :status")
        params["status"] = status
    if severity:
        clauses.append("severity = :sev")
        params["sev"] = severity
    if mine:
        clauses.append("assigned_to = :me")
        params["me"] = p.email
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    # `where` is assembled only from constant clause strings; all values are bound parameters.
    q = f"""SELECT id, transaction_id, customer_id, severity, status, decision, risk_score, typologies,
                   amount, currency, channel, assigned_to, sla_due_at, created_at
            FROM cases {where}
            ORDER BY CASE severity WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END,
                     sla_due_at
            LIMIT :lim"""  # nosec B608
    with tx() as conn:
        return {"cases": [_jsonable(r) for r in rows(conn.execute(text(q), params))]}


@app.get("/api/cases/{case_id}")
def get_case(case_id: str, p: Principal = Depends(analyst)):
    with tx() as conn:
        case = _load(conn, case_id)
        audit.record(p.email, "CASE_VIEWED", "case", case_id, conn=conn)
    return case


class AssignBody(BaseModel):
    assignee: str | None = Field(default=None, max_length=254)


@app.post("/api/cases/{case_id}/assign")
def assign(case_id: str, body: AssignBody, p: Principal = Depends(analyst)):
    assignee = body.assignee or p.email
    if assignee != p.email and not p.has("supervisor"):
        raise HTTPException(403, "only supervisors can assign to others")
    with tx() as conn:
        case = _load(conn, case_id, lock=True)
        if case["status"] == "CLOSED":
            raise HTTPException(409, "case is closed")
        conn.execute(text("UPDATE cases SET assigned_to = :a, status = 'IN_PROGRESS', updated_at = now() "
                          "WHERE id = CAST(:id AS UUID)"), {"a": assignee, "id": case_id})
        audit.record(p.email, "CASE_ASSIGNED", "case", case_id, {"assignee": assignee}, conn=conn)
    return {"status": "IN_PROGRESS", "assigned_to": assignee}


class DispositionBody(BaseModel):
    disposition: Literal["CONFIRMED_FRAUD", "FALSE_POSITIVE", "ESCALATED", "STR_FILED", "CTR_FILED"]
    notes: str = Field(min_length=10, max_length=4000)


@app.post("/api/cases/{case_id}/disposition")
def propose_disposition(case_id: str, body: DispositionBody, p: Principal = Depends(analyst)):
    with tx() as conn:
        case = _load(conn, case_id, lock=True)
        if case["status"] in ("CLOSED", "PENDING_APPROVAL"):
            raise HTTPException(409, f"case is {case['status']}")
        needs_checker = case["severity"] in NEEDS_APPROVAL or body.disposition == "STR_FILED"
        new_status = "PENDING_APPROVAL" if needs_checker else "CLOSED"
        conn.execute(text("""
            UPDATE cases SET disposition = :d, disposition_notes = :n, proposed_by = :by, status = :st,
                   closed_at = CASE WHEN CAST(:st AS TEXT) = 'CLOSED' THEN now() ELSE NULL END, updated_at = now()
            WHERE id = CAST(:id AS UUID)"""),
            {"d": body.disposition, "n": body.notes, "by": p.email, "st": new_status, "id": case_id})
        audit.record(p.email, "DISPOSITION_PROPOSED", "case", case_id,
                     {"disposition": body.disposition, "status": new_status}, conn=conn)
    if new_status == "CLOSED":
        _publish_feedback(case, body.disposition, p.email)
    return {"status": new_status}


class ApprovalBody(BaseModel):
    approve: bool
    notes: str = Field(min_length=5, max_length=4000)


@app.post("/api/cases/{case_id}/approve")
def approve(case_id: str, body: ApprovalBody, p: Principal = Depends(supervisor)):
    with tx() as conn:
        case = _load(conn, case_id, lock=True)
        if case["status"] != "PENDING_APPROVAL":
            raise HTTPException(409, "case is not pending approval")
        if case["proposed_by"] == p.email:
            raise HTTPException(403, "maker-checker: you cannot approve your own disposition")
        if body.approve:
            conn.execute(text("UPDATE cases SET status='CLOSED', approved_by=:by, closed_at=now(), updated_at=now() "
                              "WHERE id = CAST(:id AS UUID)"), {"by": p.email, "id": case_id})
        else:
            conn.execute(text("UPDATE cases SET status='IN_PROGRESS', disposition=NULL, proposed_by=NULL, "
                              "updated_at=now() WHERE id = CAST(:id AS UUID)"), {"id": case_id})
        audit.record(p.email, "DISPOSITION_APPROVED" if body.approve else "DISPOSITION_REJECTED", "case", case_id,
                     {"notes_len": len(body.notes)}, conn=conn)
    if body.approve:
        _publish_feedback(case, case["disposition"], case["proposed_by"])
    return {"status": "CLOSED" if body.approve else "IN_PROGRESS"}


@app.post("/api/cases/{case_id}/regenerate-summary")
def regenerate(case_id: str, p: Principal = Depends(analyst)):
    with tx() as conn:
        case = _load(conn, case_id)
    summary = investigator.summarise(case, prior_cases=0)
    with tx() as conn:
        conn.execute(text("UPDATE cases SET ai_summary = CAST(:s AS JSONB), updated_at = now() WHERE id = CAST(:id AS UUID)"),
                     {"s": json.dumps(summary), "id": case_id})
        audit.record(p.email, "AI_SUMMARY_REGENERATED", "case", case_id, conn=conn)
    return summary


@app.get("/api/cases/{case_id}/audit")
def case_audit(case_id: str, p: Principal = Depends(analyst)):
    with tx() as conn:
        events = rows(conn.execute(text(
            "SELECT id, ts, actor, action, details FROM audit_log WHERE entity_type='case' AND entity_id=:id ORDER BY id"),
            {"id": case_id}))
    return {"events": [_jsonable(e) for e in events]}


@app.get("/api/metrics")
def metrics(p: Principal = Depends(analyst)):
    with tx() as conn:
        by_status = rows(conn.execute(text("SELECT status, severity, count(*) AS n FROM cases GROUP BY 1,2")))
        by_typology = rows(conn.execute(text(
            "SELECT unnest(typologies) AS typology, count(*) AS n FROM cases "
            "WHERE created_at > now() - interval '30 days' GROUP BY 1 ORDER BY 2 DESC")))
        perf = conn.execute(text("""
            SELECT count(*) FILTER (WHERE status <> 'CLOSED' AND sla_due_at < now())          AS sla_breached,
                   avg(extract(epoch FROM closed_at - created_at)/3600)
                       FILTER (WHERE closed_at > now() - interval '30 days')                 AS avg_hours_to_close,
                   count(*) FILTER (WHERE disposition = 'FALSE_POSITIVE' AND closed_at > now() - interval '30 days') AS fp_30d,
                   count(*) FILTER (WHERE closed_at > now() - interval '30 days')            AS closed_30d
            FROM cases""")).first()
    closed = perf.closed_30d or 0
    return {
        "by_status": by_status,
        "by_typology_30d": by_typology,
        "sla_breached": perf.sla_breached or 0,
        "avg_hours_to_close_30d": round(float(perf.avg_hours_to_close or 0), 2),
        "false_positive_rate_30d": round((perf.fp_30d or 0) / closed, 4) if closed else None,
    }


@app.get("/api/audit/verify")
def verify_audit(p: Principal = Depends(auditor)):
    result = audit.verify_chain()
    audit.record(p.email, "AUDIT_CHAIN_VERIFIED", "audit_log", "all", result)
    return result


def _publish_feedback(case: dict, disposition: str, analyst_email: str) -> None:
    label = 1 if disposition in POSITIVE else (0 if disposition == "FALSE_POSITIVE" else None)
    publish(settings.topic_feedback, {
        "transaction_id": case["transaction_id"],
        "case_id": case["id"],
        "label": label,
        "disposition": disposition,
        "severity": case["severity"],
        "typologies": case["typologies"],
        "analyst": analyst_email,
        "closed_at": datetime.now(timezone.utc).isoformat(),
    })
