"""Online feature computation for fraud scoring.

This single module is used by BOTH the real-time fraud engine and the
offline training job (ml/build_features.py replays history through it),
which eliminates training/serving skew — a leading cause of fraud models
degrading silently in production.

State lives in Memorystore for Redis with bounded TTLs so memory stays
proportional to active accounts, not to history. Features are computed
*before* the current transaction updates the state (point-in-time correct).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30))

# Fixed order -> model input vector. Changing this requires retraining.
FEATURE_ORDER: list[str] = [
    "log_amount",
    "amount_zscore",
    "txn_count_1h",
    "txn_count_24h",
    "amount_sum_24h_log",
    "seconds_since_last_txn_log",
    "is_new_device",
    "distinct_devices_7d",
    "is_new_counterparty",
    "counterparty_fanin_24h",
    "geo_velocity_kmh",
    "is_night_ist",
    "is_international",
    "card_present",
    "channel_risk",
    "mcc_risk",
    "small_txn_burst_10m",
    "near_threshold_cash_24h",
    "passthrough_ratio_24h",
    "is_credit",
]

CHANNEL_RISK = {
    "UPI": 0.5, "CARD": 0.6, "IMPS": 0.6, "NEFT": 0.3, "RTGS": 0.3,
    "ATM": 0.5, "BRANCH_CASH": 0.4, "NETBANKING": 0.5, "WALLET": 0.6,
}
# Higher-risk merchant category codes: gambling, quasi-cash/crypto, money
# transfer, direct marketing, securities/brokers, jewellery.
MCC_RISK = {"7995": 1.0, "6051": 0.9, "4829": 0.8, "5967": 0.7, "6211": 0.6, "5944": 0.6, "6012": 0.5}

WINDOW_24H = 86400
WINDOW_7D = 7 * 86400
SMALL_TXN_INR = 100.0


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


@dataclass
class TxnView:
    """Minimal view of a transaction needed for features (decoupled from pydantic)."""

    transaction_id: str
    account_id: str
    amount: float
    direction: str
    channel: str
    ts: float  # epoch seconds
    counterparty_id: str | None = None
    device_id: str | None = None
    lat: float | None = None
    lon: float | None = None
    is_international: bool = False
    card_present: bool | None = None
    mcc: str | None = None

    @classmethod
    def from_model(cls, t) -> "TxnView":
        return cls(
            transaction_id=t.transaction_id, account_id=t.account_id, amount=float(t.amount),
            direction=t.direction.value, channel=t.channel.value, ts=t.event_time.timestamp(),
            counterparty_id=t.counterparty_id, device_id=t.device_id,
            lat=t.geo.lat if t.geo else None, lon=t.geo.lon if t.geo else None,
            is_international=t.is_international, card_present=t.card_present, mcc=t.merchant_category_code,
        )


class FeatureStore:
    def __init__(self, redis_client, ctr_threshold: float = 1_000_000):
        self.r = redis_client
        self.ctr_threshold = ctr_threshold

    @staticmethod
    def _k(account: str, suffix: str) -> str:
        # Hash tag {account} keeps an account's keys in one Redis Cluster slot.
        return f"f:{{{account}}}:{suffix}"

    def compute_and_update(self, t: TxnView) -> dict[str, float]:
        feats = self.compute(t)
        self.update(t)
        return feats

    # ------------------------------------------------------------------ read
    def compute(self, t: TxnView) -> dict[str, float]:
        a = t.account_id
        day = datetime.fromtimestamp(t.ts, tz=timezone.utc)
        hll_keys = [f"f:cp:{t.counterparty_id}:fanin:{(day - timedelta(days=d)).strftime('%Y%m%d')}" for d in (0, 1)] \
            if t.counterparty_id else []

        p = self.r.pipeline(transaction=False)
        p.zrangebyscore(self._k(a, "tx"), t.ts - WINDOW_24H, t.ts)
        p.hgetall(self._k(a, "stats"))
        p.sismember(self._k(a, "dev"), t.device_id or "")
        p.zcount(self._k(a, "dev7"), t.ts - WINDOW_7D, "+inf")
        p.sismember(self._k(a, "cp"), t.counterparty_id or "")
        if hll_keys:
            p.pfcount(*hll_keys)
        res = p.execute()
        recent, stats, dev_known, dev7, cp_known = res[:5]
        fanin = res[5] if hll_keys else 0

        count_1h = count_24h = small_burst = near_thresh = 0
        sum_24h = credits = debits = 0.0
        for member in recent:
            _, ts_s, amt_s, direction, channel = member.split("|")
            ts_v, amt = float(ts_s), float(amt_s)
            count_24h += 1
            sum_24h += amt
            if ts_v >= t.ts - 3600:
                count_1h += 1
            if ts_v >= t.ts - 600 and amt < SMALL_TXN_INR:
                small_burst += 1
            if channel in ("BRANCH_CASH", "ATM") and 0.9 * self.ctr_threshold <= amt < self.ctr_threshold:
                near_thresh += 1
            if direction == "CREDIT":
                credits += amt
            else:
                debits += amt
        if t.direction == "CREDIT":
            credits += t.amount
        else:
            debits += t.amount

        n = float(stats.get("n", 0) or 0)
        mean = float(stats.get("mean", 0) or 0)
        m2 = float(stats.get("m2", 0) or 0)
        log_amt = math.log1p(t.amount)
        std = math.sqrt(m2 / (n - 1)) if n > 1 else 0.0
        zscore = (log_amt - mean) / std if std > 1e-6 else (0.0 if n == 0 else min(abs(log_amt - mean) * 3, 10.0))

        last_ts = float(stats.get("last_ts", 0) or 0)
        since_last = t.ts - last_ts if last_ts else 30 * 86400.0
        velocity = 0.0
        if t.lat is not None and stats.get("last_lat") not in (None, "") and last_ts:
            km = haversine_km(float(stats["last_lat"]), float(stats["last_lon"]), t.lat, t.lon)
            velocity = km / max((t.ts - last_ts) / 3600.0, 1 / 60)

        hour_ist = datetime.fromtimestamp(t.ts, tz=IST).hour
        passthrough = min(credits, debits) / max(credits, debits) if credits > 0 and debits > 0 else 0.0

        return {
            "log_amount": round(log_amt, 4),
            "amount_zscore": round(max(min(zscore, 10.0), -10.0), 4),
            "txn_count_1h": float(count_1h),
            "txn_count_24h": float(count_24h),
            "amount_sum_24h_log": round(math.log1p(sum_24h), 4),
            "seconds_since_last_txn_log": round(math.log1p(max(since_last, 0)), 4),
            "is_new_device": 0.0 if (not t.device_id or dev_known or n == 0) else 1.0,
            "distinct_devices_7d": float(dev7),
            "is_new_counterparty": 0.0 if (not t.counterparty_id or cp_known or n == 0) else 1.0,
            "counterparty_fanin_24h": float(fanin),
            "geo_velocity_kmh": round(min(velocity, 20000.0), 2),
            "is_night_ist": 1.0 if 0 <= hour_ist < 5 else 0.0,
            "is_international": 1.0 if t.is_international else 0.0,
            "card_present": -1.0 if t.card_present is None else float(t.card_present),
            "channel_risk": CHANNEL_RISK.get(t.channel, 0.5),
            "mcc_risk": MCC_RISK.get(t.mcc or "", 0.0),
            "small_txn_burst_10m": float(small_burst),
            "near_threshold_cash_24h": float(near_thresh),
            "passthrough_ratio_24h": round(passthrough, 4),
            "is_credit": 1.0 if t.direction == "CREDIT" else 0.0,
        }

    # ----------------------------------------------------------------- write
    def update(self, t: TxnView) -> None:
        a = t.account_id
        stats = self.r.hgetall(self._k(a, "stats"))
        n = float(stats.get("n", 0) or 0)
        mean = float(stats.get("mean", 0) or 0)
        m2 = float(stats.get("m2", 0) or 0)
        # Welford's online mean/variance on log-amount (debits only = spend profile).
        if t.direction == "DEBIT":
            x = math.log1p(t.amount)
            n += 1
            delta = x - mean
            mean += delta / n
            m2 += delta * (x - mean)

        p = self.r.pipeline(transaction=True)
        member = f"{t.transaction_id}|{t.ts}|{t.amount}|{t.direction}|{t.channel}"
        p.zadd(self._k(a, "tx"), {member: t.ts})
        p.zremrangebyscore(self._k(a, "tx"), "-inf", t.ts - WINDOW_24H)
        p.expire(self._k(a, "tx"), WINDOW_24H + 3600)
        mapping = {"n": n, "mean": mean, "m2": m2, "last_ts": t.ts}
        if t.lat is not None:
            mapping.update(last_lat=t.lat, last_lon=t.lon)
        p.hset(self._k(a, "stats"), mapping=mapping)
        p.expire(self._k(a, "stats"), 400 * 86400)
        if t.device_id:
            p.sadd(self._k(a, "dev"), t.device_id)
            p.expire(self._k(a, "dev"), 400 * 86400)
            p.zadd(self._k(a, "dev7"), {t.device_id: t.ts})
            p.zremrangebyscore(self._k(a, "dev7"), "-inf", t.ts - WINDOW_7D)
            p.expire(self._k(a, "dev7"), WINDOW_7D)
        if t.counterparty_id:
            p.sadd(self._k(a, "cp"), t.counterparty_id)
            p.expire(self._k(a, "cp"), 400 * 86400)
            if t.direction == "DEBIT":
                day = datetime.fromtimestamp(t.ts, tz=timezone.utc).strftime("%Y%m%d")
                hll = f"f:cp:{t.counterparty_id}:fanin:{day}"
                p.pfadd(hll, a)
                p.expire(hll, 3 * 86400)
        p.execute()


def to_vector(features: dict[str, float]) -> list[float]:
    return [float(features[name]) for name in FEATURE_ORDER]
