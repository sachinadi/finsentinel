"""Environment-driven configuration.

All configuration comes from environment variables (12-factor). Secrets are
injected by Cloud Run from Secret Manager as environment variables, never
baked into images or committed to source control.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from functools import lru_cache


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def _float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


@dataclass(frozen=True)
class Settings:
    # --- Runtime / environment -------------------------------------------
    service_name: str = field(default_factory=lambda: os.getenv("SERVICE_NAME", "finsentinel"))
    environment: str = field(default_factory=lambda: os.getenv("ENVIRONMENT", "dev"))
    project_id: str = field(default_factory=lambda: os.getenv("GOOGLE_CLOUD_PROJECT", "local-project"))
    region: str = field(default_factory=lambda: os.getenv("REGION", "asia-south1"))

    # AUTH_MODE: "iap" (production, behind HTTPS LB + IAP) or "dev" (local only).
    auth_mode: str = field(default_factory=lambda: os.getenv("AUTH_MODE", "iap"))
    iap_audience: str = field(default_factory=lambda: os.getenv("IAP_AUDIENCE", ""))
    # JSON: {"alice@bank.com": ["analyst"], "bob@bank.com": ["analyst","supervisor"]}
    role_bindings_json: str = field(default_factory=lambda: os.getenv("ROLE_BINDINGS", "{}"))
    # Pub/Sub push authentication
    pubsub_push_audience: str = field(default_factory=lambda: os.getenv("PUBSUB_PUSH_AUDIENCE", ""))
    pubsub_push_sa: str = field(default_factory=lambda: os.getenv("PUBSUB_PUSH_SA", ""))

    # --- Secrets (injected from Secret Manager) --------------------------
    partner_hmac_secrets_json: str = field(default_factory=lambda: os.getenv("PARTNER_HMAC_SECRETS", "{}"))
    pii_tokenization_key: str = field(default_factory=lambda: os.getenv("PII_TOKENIZATION_KEY", "dev-only-key-change-me"))

    # --- Data plane --------------------------------------------------------
    redis_host: str = field(default_factory=lambda: os.getenv("REDIS_HOST", "localhost"))
    redis_port: int = field(default_factory=lambda: _int("REDIS_PORT", 6379))
    redis_auth: str = field(default_factory=lambda: os.getenv("REDIS_AUTH", ""))
    redis_tls: bool = field(default_factory=lambda: _bool("REDIS_TLS", False))
    redis_ca_cert: str = field(default_factory=lambda: os.getenv("REDIS_CA_CERT", ""))

    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", ""))
    cloudsql_instance: str = field(default_factory=lambda: os.getenv("CLOUDSQL_INSTANCE", ""))
    db_name: str = field(default_factory=lambda: os.getenv("DB_NAME", "finsentinel"))
    db_iam_user: str = field(default_factory=lambda: os.getenv("DB_IAM_USER", ""))

    # Pub/Sub topics
    topic_transactions: str = field(default_factory=lambda: os.getenv("TOPIC_TRANSACTIONS", "transactions"))
    topic_decisions: str = field(default_factory=lambda: os.getenv("TOPIC_DECISIONS", "fraud-decisions"))
    topic_alerts: str = field(default_factory=lambda: os.getenv("TOPIC_ALERTS", "fraud-alerts"))
    topic_feedback: str = field(default_factory=lambda: os.getenv("TOPIC_FEEDBACK", "case-feedback"))
    topic_doc_uploaded: str = field(default_factory=lambda: os.getenv("TOPIC_DOC_UPLOADED", "doc-uploaded"))
    topic_doc_results: str = field(default_factory=lambda: os.getenv("TOPIC_DOC_RESULTS", "doc-results"))

    # BigQuery
    bq_dataset: str = field(default_factory=lambda: os.getenv("BQ_DATASET", "finsentinel"))

    # Storage
    raw_docs_bucket: str = field(default_factory=lambda: os.getenv("RAW_DOCS_BUCKET", "local-raw-docs"))
    local_storage_dir: str = field(default_factory=lambda: os.getenv("LOCAL_STORAGE_DIR", "/tmp/finsentinel-docs"))  # noqa: S108  # nosec B108 - dev only

    # --- AI ----------------------------------------------------------------
    gemini_enabled: bool = field(default_factory=lambda: _bool("GEMINI_ENABLED", True))
    gemini_location: str = field(default_factory=lambda: os.getenv("GEMINI_LOCATION", "asia-south1"))
    # Keep the model configurable: Gemini model IDs are versioned and retired on a schedule.
    gemini_model: str = field(default_factory=lambda: os.getenv("GEMINI_MODEL", "gemini-3.8-flash"))
    gemini_timeout_s: float = field(default_factory=lambda: _float("GEMINI_TIMEOUT_S", 30.0))

    vertex_endpoint_id: str = field(default_factory=lambda: os.getenv("VERTEX_ENDPOINT_ID", ""))
    vertex_timeout_s: float = field(default_factory=lambda: _float("VERTEX_TIMEOUT_S", 0.15))
    model_version: str = field(default_factory=lambda: os.getenv("MODEL_VERSION", "heuristic-v1"))

    docai_enabled: bool = field(default_factory=lambda: _bool("DOCAI_ENABLED", True))
    docai_location: str = field(default_factory=lambda: os.getenv("DOCAI_LOCATION", "asia-south1"))
    docai_ocr_processor: str = field(default_factory=lambda: os.getenv("DOCAI_OCR_PROCESSOR", ""))
    docai_form_processor: str = field(default_factory=lambda: os.getenv("DOCAI_FORM_PROCESSOR", ""))
    dlp_enabled: bool = field(default_factory=lambda: _bool("DLP_ENABLED", True))

    search_engine_id: str = field(default_factory=lambda: os.getenv("SEARCH_ENGINE_ID", ""))
    search_location: str = field(default_factory=lambda: os.getenv("SEARCH_LOCATION", "global"))

    # --- Fraud decision thresholds (tunable without redeploying code) ------
    review_threshold: float = field(default_factory=lambda: _float("REVIEW_THRESHOLD", 0.50))
    block_threshold: float = field(default_factory=lambda: _float("BLOCK_THRESHOLD", 0.85))
    # Cash Transaction Report threshold (INR) — PMLA rules.
    ctr_threshold_inr: float = field(default_factory=lambda: _float("CTR_THRESHOLD_INR", 1_000_000))

    # Internal service URLs
    fraud_engine_url: str = field(default_factory=lambda: os.getenv("FRAUD_ENGINE_URL", "http://localhost:8082"))

    @property
    def is_dev(self) -> bool:
        return self.auth_mode == "dev"

    @property
    def role_bindings(self) -> dict[str, list[str]]:
        return json.loads(self.role_bindings_json or "{}")

    @property
    def partner_hmac_secrets(self) -> dict[str, str]:
        return json.loads(self.partner_hmac_secrets_json or "{}")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    s = Settings()
    if s.environment == "prod" and s.auth_mode != "iap":
        raise RuntimeError("AUTH_MODE must be 'iap' in production")
    if s.environment == "prod" and s.pii_tokenization_key.startswith("dev-only"):
        raise RuntimeError("PII_TOKENIZATION_KEY must come from Secret Manager in production")
    return s
