"""Authentication and authorization.

Three trust boundaries:

1. Human users (analysts, supervisors) reach the APIs only through the
   HTTPS load balancer with Identity-Aware Proxy. IAP signs every request
   with `x-goog-iap-jwt-assertion`; we verify that JWT (signature, issuer,
   audience) — the Cloud Run ingress setting alone is not trusted.
2. Pub/Sub push deliveries carry a Google-signed OIDC token for a dedicated
   invoker service account; we verify audience and the SA email.
3. External partners (core banking, payment switch) call the ingest API
   with an HMAC-SHA256 signature over timestamp + body, with a 5-minute
   replay window. Secrets are per-partner and stored in Secret Manager.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import time
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Request, status

from .config import get_settings

logger = logging.getLogger(__name__)

IAP_ISSUER = "https://cloud.google.com/iap"
IAP_CERTS_URL = "https://www.gstatic.com/iap/verify/public_key"
REPLAY_WINDOW_S = 300


@dataclass(frozen=True)
class Principal:
    email: str
    roles: frozenset[str]

    def has(self, role: str) -> bool:
        return role in self.roles or "admin" in self.roles


def _verify_iap_jwt(token: str, audience: str) -> dict:
    """Verify signature, expiry and audience of an IAP-signed JWT.

    IAP_AUDIENCE is either the exact backend audience
    ("/projects/NUM/global/backendServices/ID") or, to avoid a Terraform
    dependency cycle, the project prefix ("/projects/NUM/global/backendServices/"),
    which accepts any IAP-protected backend in this project only.
    """
    from google.auth.transport import requests as ga_requests
    from google.oauth2 import id_token

    if not audience:
        raise ValueError("IAP_AUDIENCE not configured")
    if audience.endswith("/"):
        claims = id_token.verify_token(token, ga_requests.Request(), audience=None, certs_url=IAP_CERTS_URL)
        if not str(claims.get("aud", "")).startswith(audience):
            raise ValueError("audience outside this project")
        return claims
    return id_token.verify_token(token, ga_requests.Request(), audience=audience, certs_url=IAP_CERTS_URL)


def get_principal(request: Request) -> Principal:
    settings = get_settings()
    if settings.is_dev:
        email = request.headers.get("x-dev-user", "dev.analyst@example.com")
        roles = request.headers.get("x-dev-roles", "analyst,supervisor").split(",")
        return Principal(email=email, roles=frozenset(r.strip() for r in roles if r.strip()))

    assertion = request.headers.get("x-goog-iap-jwt-assertion")
    if not assertion:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "missing IAP assertion")
    try:
        claims = _verify_iap_jwt(assertion, settings.iap_audience)
    except Exception as exc:  # noqa: BLE001 - any verification failure is a 401
        logger.warning("IAP JWT verification failed: %s", type(exc).__name__)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid IAP assertion") from exc
    if claims.get("iss") != IAP_ISSUER:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid issuer")
    email = (claims.get("email") or "").lower()
    roles = settings.role_bindings.get(email, [])
    if not roles:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "no role assigned")
    return Principal(email=email, roles=frozenset(roles))


def require_role(*roles: str):
    """FastAPI dependency: caller must hold at least one of `roles`."""

    def _dep(principal: Principal = Depends(get_principal)) -> Principal:
        if not any(principal.has(r) for r in roles):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"requires role: {'|'.join(roles)}")
        return principal

    return _dep


def verify_pubsub_push(request: Request) -> None:
    """Verify the OIDC token Pub/Sub attaches to push requests."""
    settings = get_settings()
    if settings.is_dev:
        return
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "missing bearer token")
    from google.auth.transport import requests as ga_requests
    from google.oauth2 import id_token

    try:
        claims = id_token.verify_oauth2_token(
            auth.split(" ", 1)[1], ga_requests.Request(), audience=settings.pubsub_push_audience
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid push token") from exc
    if not claims.get("email_verified") or claims.get("email") != settings.pubsub_push_sa:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "unexpected push identity")


def compute_signature(secret: str, timestamp: str, body: bytes) -> str:
    msg = timestamp.encode() + b"." + body
    return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()


def verify_partner_signature(partner_id: str, timestamp: str, signature: str, body: bytes) -> None:
    """Raise 401 unless the request is signed by a known partner within the replay window."""
    secrets = get_settings().partner_hmac_secrets
    secret = secrets.get(partner_id or "")
    if not secret:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "unknown partner")
    try:
        ts = int(timestamp)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "bad timestamp") from exc
    if abs(time.time() - ts) > REPLAY_WINDOW_S:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "timestamp outside replay window")
    expected = compute_signature(secret, timestamp, body)
    if not hmac.compare_digest(expected, signature or ""):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "bad signature")


def fetch_id_token(audience: str) -> str | None:
    """ID token for service-to-service calls (Cloud Run -> Cloud Run)."""
    if get_settings().is_dev:
        return None
    from google.auth.transport import requests as ga_requests
    from google.oauth2 import id_token

    return id_token.fetch_id_token(ga_requests.Request(), audience)
