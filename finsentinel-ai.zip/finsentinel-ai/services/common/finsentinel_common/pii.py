"""PII detection, masking and keyed pseudonymisation.

Used in three places:
  * the log filter (nothing sensitive ever reaches Cloud Logging),
  * the ingest API (raw card numbers are rejected — PCI DSS scope reduction),
  * the LLM boundary (prompts and answers are redacted before/after Gemini).

Indian identifiers are covered alongside international ones: Aadhaar,
PAN (tax ID), IFSC-adjacent account numbers, UPI VPAs and mobile numbers.
"""

from __future__ import annotations

import hashlib
import hmac
import re

_CARD_RE = re.compile(r"\b(?:\d[ -]?){13,19}\b")
_AADHAAR_RE = re.compile(r"\b[2-9]\d{3}[ -]?\d{4}[ -]?\d{4}\b")
_PAN_TAX_RE = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")
_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
_UPI_RE = re.compile(r"\b[\w.-]{2,}@(?:ok\w+|ybl|ibl|axl|upi|paytm|apl|[a-z]{3,})\b", re.I)
_PHONE_RE = re.compile(r"(?<!\d)(?:\+?91[ -]?)?[6-9]\d{9}(?!\d)")
_ACCOUNT_RE = re.compile(r"(?i)\b(?:a/?c|acct|account)(?:\s*(?:no\.?|number))?\s*[:#]?\s*(\d{9,18})\b")


def luhn_valid(number: str) -> bool:
    digits = [int(c) for c in number if c.isdigit()]
    if len(digits) < 13 or len(digits) > 19:
        return False
    checksum = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


def contains_card_number(text: str) -> bool:
    """True if text contains something that looks like a real PAN (Luhn-valid)."""
    return any(luhn_valid(m.group()) for m in _CARD_RE.finditer(text or ""))


def _mask_card(m: re.Match) -> str:
    raw = m.group()
    digits = re.sub(r"\D", "", raw)
    if not luhn_valid(digits):
        return raw
    return f"[CARD ****{digits[-4:]}]"


def mask_text(text: str) -> str:
    """Irreversibly mask PII in free text. Safe for logs and LLM prompts."""
    if not text:
        return text
    out = _CARD_RE.sub(_mask_card, text)
    out = _AADHAAR_RE.sub(lambda m: "[AADHAAR XXXX-XXXX-" + re.sub(r"\D", "", m.group())[-4:] + "]", out)
    out = _PAN_TAX_RE.sub(lambda m: f"[PAN {m.group()[:2]}XXXXXXX{m.group()[-1]}]", out)
    out = _EMAIL_RE.sub("[EMAIL]", out)
    out = _UPI_RE.sub("[UPI-ID]", out)
    out = _PHONE_RE.sub(lambda m: f"[PHONE ******{m.group()[-4:]}]", out)
    out = _ACCOUNT_RE.sub(lambda m: m.group().replace(m.group(1), f"XXXXX{m.group(1)[-4:]}"), out)
    return out


def tokenize(value: str, key: str) -> str:
    """Deterministic keyed pseudonym (HMAC-SHA256). Same input -> same token,
    so joins and velocity features still work, but the raw value cannot be
    recovered without the key held in Secret Manager."""
    digest = hmac.new(key.encode(), value.encode(), hashlib.sha256).hexdigest()
    return f"tok_{digest[:32]}"


def mask_mapping(data, depth: int = 0):
    """Recursively mask string values in dicts/lists (for structured logs)."""
    if depth > 6:
        return data
    if isinstance(data, dict):
        return {k: mask_mapping(v, depth + 1) for k, v in data.items()}
    if isinstance(data, list):
        return [mask_mapping(v, depth + 1) for v in data]
    if isinstance(data, str):
        return mask_text(data)
    return data
