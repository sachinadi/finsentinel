"""Cloud SQL (PostgreSQL) access.

Production uses the Cloud SQL Python Connector with **IAM database
authentication** over **private IP** — there are no database passwords in
the services at all. Locally, DATABASE_URL points at the docker-compose
Postgres.
"""

from __future__ import annotations

from contextlib import contextmanager
from functools import lru_cache
from typing import Iterator

import sqlalchemy
from sqlalchemy.engine import Connection, Engine

from .config import get_settings


@lru_cache(maxsize=1)
def get_engine() -> Engine:
    s = get_settings()
    pool_kwargs = dict(pool_size=5, max_overflow=5, pool_timeout=10, pool_recycle=1800, pool_pre_ping=True)
    if s.database_url:
        return sqlalchemy.create_engine(s.database_url, **pool_kwargs)

    from google.cloud.sql.connector import Connector, IPTypes

    connector = Connector(refresh_strategy="lazy")

    def _connect():
        return connector.connect(
            s.cloudsql_instance,
            "pg8000",
            user=s.db_iam_user,
            db=s.db_name,
            enable_iam_auth=True,
            ip_type=IPTypes.PRIVATE,
        )

    return sqlalchemy.create_engine("postgresql+pg8000://", creator=_connect, **pool_kwargs)


@contextmanager
def tx() -> Iterator[Connection]:
    """Transactional connection (commit on success, rollback on error)."""
    with get_engine().begin() as conn:
        yield conn


def rows(result) -> list[dict]:
    return [dict(r._mapping) for r in result]
