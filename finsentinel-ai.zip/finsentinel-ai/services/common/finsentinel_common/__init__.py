"""Shared library for all FinSentinel AI services.

Everything that must behave identically across services lives here:
configuration, structured logging with PII scrubbing, authentication,
the canonical transaction schema, the online feature definitions
(shared with model training to avoid training/serving skew), the
Gemini client wrapper, database access and audit logging.
"""

__version__ = "1.0.0"
