"""FastAPI app factory with security headers, request tracing and health checks."""

from __future__ import annotations

import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .config import get_settings
from .logging_setup import configure_logging, log, set_trace

logger = logging.getLogger("http")

SECURITY_HEADERS = {
    "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
}


def create_app(title: str) -> FastAPI:
    settings = get_settings()
    configure_logging()
    app = FastAPI(
        title=title,
        version="1.0.0",
        # Do not expose interactive docs in production.
        docs_url=None if settings.environment == "prod" else "/docs",
        redoc_url=None,
        openapi_url=None if settings.environment == "prod" else "/openapi.json",
    )

    @app.middleware("http")
    async def _middleware(request: Request, call_next):
        set_trace(request.headers.get("x-cloud-trace-context"))
        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:  # noqa: BLE001
            logger.exception("unhandled error")
            response = JSONResponse({"error": "internal_error", "request_id": request_id}, status_code=500)
        elapsed = (time.perf_counter() - start) * 1000
        for k, v in SECURITY_HEADERS.items():
            response.headers.setdefault(k, v)
        response.headers["x-request-id"] = request_id
        if request.url.path not in ("/healthz", "/readyz"):
            log(logger, logging.INFO, "request", method=request.method, path=request.url.path,
                status=response.status_code, latency_ms=round(elapsed, 2), request_id=request_id)
        return response

    @app.get("/healthz", include_in_schema=False)
    async def healthz():
        return {"status": "ok", "service": settings.service_name}

    return app
