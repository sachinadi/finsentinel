"""Thin, safety-conscious wrapper around Gemini on Vertex AI (google-genai SDK).

Design choices for a regulated environment:
  * Vertex AI endpoint in-region (default asia-south1) — prompts and data stay
    in the chosen region and are not used to train Google models.
  * Every prompt is PII-masked before leaving the service (pii.mask_text).
  * Structured output (JSON schema) for anything a downstream system reads,
    so the model cannot "free-text" its way into a decision.
  * Low temperature, bounded output, explicit timeouts and retries.
  * GEMINI_ENABLED=false gives a deterministic offline mode for tests/local.
  * Gemini never makes the approve/block decision — it explains, summarises
    and extracts; decisions come from rules + the calibrated ML model.
"""

from __future__ import annotations

import json
import logging
import random
import time
from functools import lru_cache
from typing import Any, Callable

from .config import get_settings
from .pii import mask_text

logger = logging.getLogger(__name__)

SAFETY_CATEGORIES = (
    "HARM_CATEGORY_HATE_SPEECH",
    "HARM_CATEGORY_DANGEROUS_CONTENT",
    "HARM_CATEGORY_HARASSMENT",
    "HARM_CATEGORY_SEXUALLY_EXPLICIT",
)


class GeminiUnavailable(RuntimeError):
    pass


@lru_cache(maxsize=1)
def _client():
    from google import genai
    from google.genai import types

    s = get_settings()
    return genai.Client(
        vertexai=True,
        project=s.project_id,
        location=s.gemini_location,
        http_options=types.HttpOptions(timeout=int(s.gemini_timeout_s * 1000)),
    )


def _safety():
    from google.genai import types

    return [
        types.SafetySetting(category=c, threshold="BLOCK_MEDIUM_AND_ABOVE") for c in SAFETY_CATEGORIES
    ]


def _with_retries(fn: Callable[[], Any], attempts: int = 3) -> Any:
    for i in range(attempts):
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001
            retryable = any(code in str(exc) for code in ("429", "500", "503", "DEADLINE", "UNAVAILABLE"))
            if i == attempts - 1 or not retryable:
                raise GeminiUnavailable(str(exc)) from exc
            time.sleep((2**i) + random.random())
    raise GeminiUnavailable("exhausted retries")


def generate_json(
    prompt: str,
    schema: dict,
    system: str,
    fallback: Callable[[], dict],
    parts: list | None = None,
    max_output_tokens: int = 2048,
    mask: bool = True,
) -> dict:
    """Generate a JSON object conforming to `schema`. Returns fallback() offline/on failure."""
    s = get_settings()
    if not s.gemini_enabled:
        return fallback()
    from google.genai import types

    contents: list = list(parts or [])
    contents.append(mask_text(prompt) if mask else prompt)
    config = types.GenerateContentConfig(
        system_instruction=system,
        temperature=0.1,
        max_output_tokens=max_output_tokens,
        response_mime_type="application/json",
        response_schema=schema,
        safety_settings=_safety(),
        labels={"app": "finsentinel", "service": s.service_name},
    )
    try:
        resp = _with_retries(
            lambda: _client().models.generate_content(model=s.gemini_model, contents=contents, config=config)
        )
        text = resp.text or "{}"
        return json.loads(text)
    except (GeminiUnavailable, json.JSONDecodeError) as exc:
        logger.warning("Gemini structured call failed, using fallback: %s", type(exc).__name__)
        result = fallback()
        result["_fallback"] = True
        return result


def chat_with_tools(
    system: str,
    history: list[dict],
    tools: list[dict],
    tool_executor: Callable[[str, dict], dict],
    max_steps: int = 4,
) -> tuple[str, list[dict]]:
    """Manual function-calling loop so every tool call is authorised and audited.

    history: [{"role": "user"|"model", "text": "..."}]
    tools:   [{"name":..., "description":..., "parameters": {json schema}}]
    Returns (final_text, tool_trace).
    """
    s = get_settings()
    if not s.gemini_enabled:
        return ("[offline mode] Gemini is disabled in this environment.", [])
    from google.genai import types

    contents = [
        types.Content(role=h["role"], parts=[types.Part.from_text(text=mask_text(h["text"]))])
        for h in history
    ]
    config = types.GenerateContentConfig(
        system_instruction=system,
        temperature=0.2,
        max_output_tokens=2048,
        tools=[types.Tool(function_declarations=[types.FunctionDeclaration(**t) for t in tools])],
        automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True),
        safety_settings=_safety(),
        labels={"app": "finsentinel", "service": s.service_name},
    )
    trace: list[dict] = []
    for _ in range(max_steps):
        resp = _with_retries(
            lambda: _client().models.generate_content(model=s.gemini_model, contents=contents, config=config)
        )
        calls = resp.function_calls or []
        if not calls:
            return (resp.text or "").strip(), trace
        contents.append(resp.candidates[0].content)
        response_parts = []
        for call in calls:
            args = dict(call.args or {})
            result = tool_executor(call.name, args)
            trace.append({"tool": call.name, "args": args, "ok": "error" not in result})
            # Tool output is masked too: it re-enters the model context.
            response_parts.append(
                types.Part.from_function_response(name=call.name, response=json.loads(mask_text(json.dumps(result, default=str))))
            )
        contents.append(types.Content(role="user", parts=response_parts))
    return "I could not complete this request within the allowed number of steps.", trace
