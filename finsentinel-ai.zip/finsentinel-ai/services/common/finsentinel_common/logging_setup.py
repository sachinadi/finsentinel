"""Structured JSON logging compatible with Cloud Logging, with PII scrubbing.

Cloud Run forwards stdout to Cloud Logging; JSON lines with a `severity`
field are parsed into structured entries. Trace correlation uses the
`X-Cloud-Trace-Context` header so a transaction can be followed across
ingest -> Pub/Sub -> fraud engine -> case service.
"""

from __future__ import annotations

import contextvars
import json
import logging
import sys
from datetime import datetime, timezone

from .config import get_settings
from .pii import mask_mapping, mask_text

_trace_ctx: contextvars.ContextVar[str | None] = contextvars.ContextVar("trace", default=None)


def set_trace(header_value: str | None) -> None:
    if not header_value:
        _trace_ctx.set(None)
        return
    trace_id = header_value.split("/")[0]
    settings = get_settings()
    _trace_ctx.set(f"projects/{settings.project_id}/traces/{trace_id}")


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "severity": record.levelname,
            "message": mask_text(record.getMessage()),
            "time": datetime.now(timezone.utc).isoformat(),
            "logger": record.name,
            "service": get_settings().service_name,
        }
        extra = getattr(record, "fields", None)
        if extra:
            payload.update(mask_mapping(extra))
        trace = _trace_ctx.get()
        if trace:
            payload["logging.googleapis.com/trace"] = trace
        if record.exc_info:
            payload["exception"] = mask_text(self.formatException(record.exc_info))
        return json.dumps(payload, default=str)


def configure_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level)
    # Quiet chatty libraries
    for noisy in ("urllib3", "google.auth", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def log(logger: logging.Logger, level: int, message: str, **fields) -> None:
    logger.log(level, message, extra={"fields": fields})
