"""Canonical data contracts shared across services."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, field_validator


_FUTURE_SKEW = timedelta(minutes=5)


class Channel(str, Enum):
    UPI = "UPI"
    CARD = "CARD"
    IMPS = "IMPS"
    NEFT = "NEFT"
    RTGS = "RTGS"
    ATM = "ATM"
    BRANCH_CASH = "BRANCH_CASH"
    NETBANKING = "NETBANKING"
    WALLET = "WALLET"


class Direction(str, Enum):
    DEBIT = "DEBIT"
    CREDIT = "CREDIT"


class Decision(str, Enum):
    APPROVE = "APPROVE"
    REVIEW = "REVIEW"
    BLOCK = "BLOCK"


class GeoPoint(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)


class Transaction(BaseModel):
    """A payment event as received from core banking / switch / UPI gateway.

    Card numbers must arrive already tokenised (network or vault token);
    the ingest API rejects anything that looks like a raw PAN.
    """

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    transaction_id: str = Field(min_length=6, max_length=64, pattern=r"^[A-Za-z0-9_\-:.]+$")
    account_id: str = Field(min_length=4, max_length=64)
    customer_id: str = Field(min_length=4, max_length=64)
    amount: Decimal = Field(gt=0, max_digits=18, decimal_places=2)
    currency: str = Field(default="INR", pattern=r"^[A-Z]{3}$")
    direction: Direction = Direction.DEBIT
    channel: Channel
    event_time: datetime
    counterparty_id: str | None = Field(default=None, max_length=128)
    merchant_id: str | None = Field(default=None, max_length=64)
    merchant_category_code: str | None = Field(default=None, pattern=r"^\d{4}$")
    card_token: str | None = Field(default=None, max_length=128)
    device_id: str | None = Field(default=None, max_length=128)
    ip_address: str | None = Field(default=None, max_length=45)
    geo: GeoPoint | None = None
    country: str = Field(default="IN", pattern=r"^[A-Z]{2}$")
    is_international: bool = False
    card_present: bool | None = None
    description: str | None = Field(default=None, max_length=256)

    @field_validator("event_time")
    @classmethod
    def _tz_aware(cls, v: datetime) -> datetime:
        if v.tzinfo is None:
            v = v.replace(tzinfo=timezone.utc)
        if v > datetime.now(timezone.utc) + _FUTURE_SKEW:
            raise ValueError("event_time is in the future")
        return v


class RuleHit(BaseModel):
    code: str
    score: float = Field(ge=0, le=1)
    reason: str
    typology: str
    hard_block: bool = False


class FraudDecision(BaseModel):
    transaction_id: str
    account_id: str
    customer_id: str
    amount: float
    currency: str
    channel: str
    event_time: str
    decision: Decision
    risk_score: float
    ml_score: float
    model_version: str
    rule_hits: list[RuleHit]
    top_features: dict[str, float]
    # Full feature snapshot as served — logged to BigQuery so retraining uses
    # exactly what the model saw (no training/serving skew).
    features: dict[str, float] = {}
    regulatory_flags: list[str]
    latency_ms: float
    scored_at: str

    def to_bigquery_row(self) -> dict:
        """Shape matching sql/bigquery/transactions_scored.json (Pub/Sub -> BQ subscription)."""
        row = self.model_dump(mode="json")
        row["rule_hits"] = [h.model_dump(mode="json") for h in self.rule_hits]
        row["top_features"] = [{"name": k, "value": v} for k, v in self.top_features.items()]
        row["features"] = [{"name": k, "value": v} for k, v in self.features.items()]
        return row
