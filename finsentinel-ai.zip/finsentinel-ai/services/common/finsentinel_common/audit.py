"""Tamper-evident audit trail.

Every human or AI action that touches a case, document or customer record is
written to `audit_log`. A database trigger (services/case_service/migrations/001_schema.sql) chains
each row to the previous one with SHA-256, so deleting or editing a row breaks
the chain and is detectable by `verify_chain()`. The table is append-only:
the application role has INSERT/SELECT but no UPDATE/DELETE.
Cloud Audit Logs (Admin + Data Access) cover the platform layer separately.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from sqlalchemy import text

from .db import tx
from .logging_setup import log
from .pii import mask_mapping

logger = logging.getLogger("audit")


def record(actor: str, action: str, entity_type: str, entity_id: str, details: dict[str, Any] | None = None,
           conn=None) -> None:
    details = mask_mapping(details or {})
    stmt = text(
        "INSERT INTO audit_log (actor, action, entity_type, entity_id, details) "
        "VALUES (:actor, :action, :etype, :eid, CAST(:details AS JSONB))"
    )
    params = dict(actor=actor, action=action, etype=entity_type, eid=entity_id, details=json.dumps(details, default=str))
    if conn is not None:
        conn.execute(stmt, params)
    else:
        with tx() as c:
            c.execute(stmt, params)
    log(logger, logging.INFO, "audit", actor=actor, action=action, entity_type=entity_type, entity_id=entity_id)


def verify_chain(limit: int = 100000) -> dict:
    """Recompute the hash chain; returns the first broken id if any."""
    with tx() as c:
        result = c.execute(text("SELECT * FROM audit_verify_chain(:lim)"), {"lim": limit}).first()
    return {"ok": result is None or result[0] is None, "first_broken_id": None if result is None else result[0]}
