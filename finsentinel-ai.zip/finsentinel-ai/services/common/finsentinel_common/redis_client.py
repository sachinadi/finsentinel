"""Memorystore for Redis client (TLS + AUTH in production)."""

from __future__ import annotations

from functools import lru_cache

import redis

from .config import get_settings


@lru_cache(maxsize=1)
def get_redis() -> redis.Redis:
    s = get_settings()
    kwargs = dict(
        host=s.redis_host,
        port=s.redis_port,
        password=s.redis_auth or None,
        socket_timeout=0.25,           # fraud path has a tight latency budget
        socket_connect_timeout=1.0,
        health_check_interval=30,
        decode_responses=True,
        max_connections=64,
    )
    if s.redis_tls:
        kwargs.update(ssl=True, ssl_ca_data=s.redis_ca_cert or None, ssl_cert_reqs="required")
    return redis.Redis(**kwargs)


def idempotent_once(key: str, ttl_s: int = 86400) -> bool:
    """Return True the first time `key` is seen within ttl (SET NX)."""
    return bool(get_redis().set(f"idem:{key}", "1", nx=True, ex=ttl_s))
