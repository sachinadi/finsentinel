"""Pub/Sub publishing and push-envelope decoding."""

from __future__ import annotations

import base64
import json
import logging
from functools import lru_cache
from typing import Any

from fastapi import HTTPException

from .config import get_settings

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def _publisher():
    from google.cloud import pubsub_v1

    # Ordering is enabled so all events for one account are processed in order
    # (velocity features depend on it). Batching keeps throughput high.
    return pubsub_v1.PublisherClient(
        publisher_options=pubsub_v1.types.PublisherOptions(enable_message_ordering=True),
        batch_settings=pubsub_v1.types.BatchSettings(max_messages=500, max_latency=0.01),
    )


def topic_path(topic: str) -> str:
    return _publisher().topic_path(get_settings().project_id, topic)


def publish(topic: str, payload: dict[str, Any], ordering_key: str = "", **attributes: str) -> str:
    data = json.dumps(payload, default=str, separators=(",", ":")).encode()
    future = _publisher().publish(topic_path(topic), data, ordering_key=ordering_key, **attributes)
    try:
        return future.result(timeout=10)
    except Exception:
        if ordering_key:
            # A failed publish pauses the ordering key; resume so later messages flow.
            _publisher().resume_publish(topic_path(topic), ordering_key)
        raise


def decode_push(envelope: dict) -> tuple[dict, dict, str]:
    """Return (payload, attributes, message_id) from a Pub/Sub push body."""
    message = (envelope or {}).get("message")
    if not message or "data" not in message:
        raise HTTPException(400, "invalid Pub/Sub envelope")
    try:
        payload = json.loads(base64.b64decode(message["data"]))
    except (ValueError, json.JSONDecodeError) as exc:
        # Malformed messages are acked with 200 by callers after logging,
        # but here we surface a 400 so they land in the dead-letter topic.
        raise HTTPException(400, "undecodable message") from exc
    return payload, message.get("attributes", {}) or {}, message.get("messageId", "")
