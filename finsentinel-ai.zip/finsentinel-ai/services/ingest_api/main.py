"""Ingest API — the only internet-facing write path (for partner systems).

Partners (core banking, card switch, UPI gateway) POST transactions here.
Controls applied, in order:
  1. Cloud Armor at the load balancer: WAF rules, per-IP rate limits, geo policy.
  2. HMAC-SHA256 request signing per partner + 5-minute replay window.
  3. Strict schema validation (unknown fields rejected).
  4. PCI DSS scope reduction: any Luhn-valid card number anywhere in the
     payload is rejected — only tokenised cards are accepted.
  5. Idempotency-Key support so partner retries never double-count.
Accepted events are published to Pub/Sub ordered by account_id; `mode=sync`
additionally returns a real-time decision for authorisation flows.
"""

from __future__ import annotations

import json
import logging

import httpx
from fastapi import Header, HTTPException, Query, Request
from pydantic import ValidationError

from finsentinel_common.config import get_settings
from finsentinel_common.http import create_app
from finsentinel_common.logging_setup import log
from finsentinel_common.models import Transaction
from finsentinel_common.pii import contains_card_number
from finsentinel_common.pubsub import publish
from finsentinel_common.redis_client import get_redis
from finsentinel_common.security import fetch_id_token, verify_partner_signature

logger = logging.getLogger("ingest_api")
settings = get_settings()
app = create_app("FinSentinel Ingest API")

MAX_BODY_BYTES = 1_000_000
MAX_BATCH = 500
SYNC_TIMEOUT_S = 0.3

_http = httpx.Client(timeout=SYNC_TIMEOUT_S, limits=httpx.Limits(max_connections=200, max_keepalive_connections=50))


async def _authenticated_body(request: Request, partner_id: str, timestamp: str, signature: str) -> bytes:
    body = await request.body()
    if len(body) > MAX_BODY_BYTES:
        raise HTTPException(413, "payload too large")
    verify_partner_signature(partner_id, timestamp, signature, body)
    if contains_card_number(body.decode("utf-8", errors="ignore")):
        log(logger, logging.WARNING, "raw PAN rejected", partner=partner_id)
        raise HTTPException(422, "raw card numbers are not accepted; send a card token")
    return body


def _validate(item: dict) -> Transaction:
    try:
        return Transaction.model_validate(item)
    except ValidationError as exc:
        raise HTTPException(422, json.loads(exc.json(include_url=False, include_input=False))) from exc


def _publish(txn: Transaction, partner_id: str) -> str:
    return publish(
        settings.topic_transactions,
        txn.model_dump(mode="json"),
        ordering_key=txn.account_id,
        partner=partner_id,
        channel=txn.channel.value,
    )


def _sync_score(txn: Transaction) -> dict:
    url = f"{settings.fraud_engine_url}/v1/score"
    headers = {}
    token = fetch_id_token(settings.fraud_engine_url)
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        resp = _http.post(url, content=txn.model_dump_json(), headers={**headers, "content-type": "application/json"})
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPError as exc:
        # Fail-safe for authorisation: degrade to REVIEW (step-up / OTP) instead of silently approving.
        log(logger, logging.ERROR, "sync scoring unavailable", error=type(exc).__name__)
        return {"transaction_id": txn.transaction_id, "decision": "REVIEW", "degraded": True}


@app.post("/api/v1/transactions", status_code=202)
async def ingest_one(
    request: Request,
    mode: str = Query("async", pattern="^(async|sync)$"),
    x_partner_id: str = Header(...),
    x_timestamp: str = Header(...),
    x_signature: str = Header(...),
    idempotency_key: str | None = Header(default=None),
):
    body = await _authenticated_body(request, x_partner_id, x_timestamp, x_signature)
    txn = _validate(json.loads(body))
    key = f"ingest:{x_partner_id}:{idempotency_key or txn.transaction_id}"
    if not get_redis().set(key, "1", nx=True, ex=86400):
        return {"status": "duplicate", "transaction_id": txn.transaction_id}

    result: dict = {"status": "accepted", "transaction_id": txn.transaction_id}
    try:
        if mode == "sync":
            result["decision"] = _sync_score(txn)
        result["message_id"] = _publish(txn, x_partner_id)
    except Exception:
        get_redis().delete(key)  # allow the partner's retry to succeed
        raise
    return result


@app.post("/api/v1/transactions:batch", status_code=202)
async def ingest_batch(
    request: Request,
    x_partner_id: str = Header(...),
    x_timestamp: str = Header(...),
    x_signature: str = Header(...),
):
    body = await _authenticated_body(request, x_partner_id, x_timestamp, x_signature)
    items = json.loads(body)
    if not isinstance(items, list) or not 0 < len(items) <= MAX_BATCH:
        raise HTTPException(422, f"body must be a list of 1..{MAX_BATCH} transactions")
    accepted, duplicates, rejected = [], [], []
    r = get_redis()
    for idx, item in enumerate(items):
        try:
            txn = Transaction.model_validate(item)
        except ValidationError as exc:
            rejected.append({"index": idx, "errors": exc.error_count()})
            continue
        key = f"ingest:{x_partner_id}:{txn.transaction_id}"
        if not r.set(key, "1", nx=True, ex=86400):
            duplicates.append(txn.transaction_id)
            continue
        try:
            _publish(txn, x_partner_id)
        except Exception:  # noqa: BLE001
            r.delete(key)
            rejected.append({"index": idx, "errors": "publish_failed_retry"})
            continue
        accepted.append(txn.transaction_id)
    log(logger, logging.INFO, "batch ingested", partner=x_partner_id, accepted=len(accepted),
        duplicates=len(duplicates), rejected=len(rejected))
    return {"accepted": len(accepted), "duplicates": duplicates, "rejected": rejected}
