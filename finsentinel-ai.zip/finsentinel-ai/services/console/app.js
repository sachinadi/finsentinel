// FinSentinel analyst console. No framework, no inline script (strict CSP).
// All server data is rendered with textContent — never innerHTML — to prevent XSS.
"use strict";

const $ = (sel, root = document) => root.querySelector(sel);

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v);
  }
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    node.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return node;
}

function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2600);
}

async function api(path, opts = {}) {
  const res = await fetch(path, { credentials: "same-origin", ...opts });
  if (res.status === 401) { location.reload(); throw new Error("session expired"); }
  const body = res.headers.get("content-type")?.includes("json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error(typeof body === "object" ? (body.detail?.toString?.() || JSON.stringify(body)) : body);
  return body;
}
const post = (path, data) => api(path, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(data) });

const inr = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 });
const fmtTime = (iso) => iso ? new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "—";

// ------------------------------------------------------------------ tabs
document.querySelectorAll("nav [role=tab]").forEach((b) => b.addEventListener("click", () => {
  document.querySelectorAll("nav [role=tab]").forEach((x) => x.setAttribute("aria-selected", x === b));
  document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === `view-${b.dataset.view}`));
  if (b.dataset.view === "metrics") loadMetrics();
}));

// ----------------------------------------------------------------- queue
let selectedCase = null;

async function loadQueue() {
  const params = new URLSearchParams();
  const st = $("#f-status").value, sev = $("#f-sev").value;
  if (st) params.set("status", st);
  if (sev) params.set("severity", sev);
  if ($("#f-mine").checked) params.set("mine", "true");
  const tbody = $("#case-table tbody");
  try {
    const { cases } = await api(`/api/cases?${params}`);
    const shown = st ? cases : cases.filter((c) => c.status !== "CLOSED");
    tbody.replaceChildren(...shown.map((c) => {
      const overdue = c.status !== "CLOSED" && new Date(c.sla_due_at) < new Date();
      return el("tr", { onclick: () => openCase(c.id), class: c.id === selectedCase ? "sel" : "" },
        el("td", { class: `sev ${c.severity}` }, c.severity),
        el("td", {}, (c.typologies || []).join(", ")),
        el("td", {}, c.channel),
        el("td", { class: "num" }, `${c.currency} ${inr.format(c.amount)}`),
        el("td", { class: "num" }, Number(c.risk_score).toFixed(2)),
        el("td", {}, c.status.replace("_", " ")),
        el("td", { class: overdue ? "overdue" : "" }, fmtTime(c.sla_due_at)));
    }));
    if (!shown.length) tbody.replaceChildren(el("tr", {}, el("td", { colspan: 7 }, "No cases match these filters.")));
  } catch (e) { toast(`Could not load cases: ${e.message}`); }
}

async function openCase(id) {
  selectedCase = id;
  const pane = $("#case-detail");
  pane.classList.remove("empty");
  pane.replaceChildren("Loading…");
  try {
    const [c, { events }] = await Promise.all([api(`/api/cases/${id}`), api(`/api/cases/${id}/audit`)]);
    pane.replaceChildren(renderCase(c, events));
    document.querySelectorAll("#case-table tbody tr").forEach((tr) => tr.classList.remove("sel"));
  } catch (e) { pane.replaceChildren(`Error: ${e.message}`); }
}

function renderCase(c, events) {
  const ai = c.ai_summary || {};
  const t = c.transaction || {};
  const frag = el("div", {},
    el("h2", {}, `${c.severity} · ${c.decision} · ${c.currency} ${inr.format(c.amount)}`),
    el("div", {}, ...(c.typologies || []).map((x) => el("span", { class: "tag" }, x)), el("span", { class: "tag" }, c.status)),
    el("h3", {}, "AI investigation summary"),
    el("div", { class: "ai" },
      el("p", {}, ai.summary || "Summary pending…"),
      ai.evidence?.length ? el("ul", { class: "tight" }, ai.evidence.map((x) => el("li", {}, x))) : null,
      ai.recommended_actions?.length ? el("div", {}, el("strong", {}, "Recommended: "),
        el("ul", { class: "tight" }, ai.recommended_actions.map((x) => el("li", {}, x)))) : null,
      ai.str_draft?.grounds_of_suspicion ? el("details", {}, el("summary", {}, "Draft STR grounds of suspicion"),
        el("p", {}, ai.str_draft.grounds_of_suspicion)) : null,
      el("p", { class: "fine" }, `${ai.disclaimer || ""} Confidence: ${ai.confidence || "—"}.`)),
    el("h3", {}, "Rule hits"),
    el("ul", { class: "tight" }, (c.rule_hits || []).map((h) => el("li", {}, `${h.code} (${h.score}) — ${h.reason}`))),
    el("h3", {}, "Model signals"),
    el("dl", { class: "kv" }, Object.entries(c.top_features || {}).flatMap(([k, v]) => [el("dt", {}, k), el("dd", {}, v)])),
    el("h3", {}, "Transaction"),
    el("dl", { class: "kv" },
      ["channel", "direction", "event_time", "merchant_category_code", "country", "is_international"]
        .flatMap((k) => [el("dt", {}, k), el("dd", {}, t[k] ?? "—")])),
    el("h3", {}, "Actions"),
    renderActions(c),
    el("h3", {}, "Audit trail"),
    el("ul", { class: "tight" }, events.map((e) => el("li", {}, `${fmtTime(e.ts)} · ${e.actor} · ${e.action}`))));
  return frag;
}

function renderActions(c) {
  const box = el("div", { class: "actions" });
  if (c.status === "CLOSED") { box.append(`Closed as ${c.disposition}${c.approved_by ? ` (approved by ${c.approved_by})` : ""}.`); return box; }
  if (c.status === "PENDING_APPROVAL") {
    const notes = el("textarea", { rows: 2, placeholder: "Checker notes (required)" });
    box.append(`Proposed ${c.disposition} by ${c.proposed_by}. Requires a second approver.`, notes,
      el("div", {}, el("button", { onclick: () => act(`/api/cases/${c.id}/approve`, { approve: true, notes: notes.value }) }, "Approve"), " ",
        el("button", { class: "ghost", onclick: () => act(`/api/cases/${c.id}/approve`, { approve: false, notes: notes.value }) }, "Send back")));
    return box;
  }
  const sel = el("select", {}, ["CONFIRMED_FRAUD", "FALSE_POSITIVE", "ESCALATED", "STR_FILED", "CTR_FILED"].map((d) => el("option", {}, d)));
  const notes = el("textarea", { rows: 3, placeholder: "Investigation notes (min 10 characters)" });
  box.append(
    el("button", { class: "ghost", onclick: () => act(`/api/cases/${c.id}/assign`, {}) }, c.assigned_to ? `Assigned to ${c.assigned_to} — take over` : "Assign to me"),
    sel, notes,
    el("button", { onclick: () => act(`/api/cases/${c.id}/disposition`, { disposition: sel.value, notes: notes.value }) }, "Submit disposition"),
    el("button", { class: "ghost", onclick: () => act(`/api/cases/${c.id}/regenerate-summary`, {}) }, "Regenerate AI summary"));
  return box;
}

async function act(path, data) {
  try { await post(path, data); toast("Saved"); await openCase(selectedCase); await loadQueue(); }
  catch (e) { toast(e.message); }
}

["#f-status", "#f-sev", "#f-mine"].forEach((s) => $(s).addEventListener("change", loadQueue));
$("#refresh").addEventListener("click", loadQueue);

// -------------------------------------------------------------- documents
$("#doc-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const form = ev.target, btn = $("button", form), out = $("#doc-result");
  btn.disabled = true;
  try {
    const res = await api("/api/documents", { method: "POST", body: new FormData(form) });
    out.replaceChildren(`Uploaded. Document ${res.document_id} — analysing…`);
    pollDoc(res.document_id, 0);
  } catch (e) { toast(e.message); }
  finally { btn.disabled = false; }
});

async function pollDoc(id, n) {
  const out = $("#doc-result");
  const d = await api(`/api/documents/${id}`);
  if (["UPLOADED", "PROCESSING"].includes(d.status) && n < 40) { setTimeout(() => pollDoc(id, n + 1), 3000); return; }
  out.replaceChildren(
    el("h2", {}, `${d.doc_type} · ${d.status} · risk ${d.risk_level || "—"}`),
    el("h3", {}, "Integrity checks"),
    el("ul", { class: "tight" }, (d.checks || []).map((c) => el("li", { class: `check-row ${c.passed ? "" : "fail"}` },
      `${c.passed ? "✓" : "✗"} ${c.check} — ${c.detail}`))),
    el("h3", {}, "Extracted fields (identifiers tokenised)"),
    el("pre", {}, JSON.stringify(d.extracted, null, 2)));
}

// ---------------------------------------------------------------- copilot
let chatSession = null;
$("#chat-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const input = $("#chat-msg"), log = $("#chat-log"), msg = input.value.trim();
  if (!msg) return;
  input.value = "";
  log.append(el("div", { class: "msg user" }, msg));
  const pending = el("div", { class: "msg model" }, "Thinking…");
  log.append(pending);
  log.scrollTop = log.scrollHeight;
  try {
    const r = await post("/api/assistant/chat", { message: msg, session_id: chatSession });
    chatSession = r.session_id;
    const tools = (r.tools_used || []).map((t) => t.tool).join(", ");
    pending.replaceChildren(r.answer, el("div", { class: "meta" },
      [r.grounded ? "Grounded in bank policies" : "Not grounded in policy search", tools && `tools: ${tools}`].filter(Boolean).join(" · ")));
  } catch (e) { pending.replaceChildren(`Error: ${e.message}`); }
  log.scrollTop = log.scrollHeight;
});

// ---------------------------------------------------------------- metrics
async function loadMetrics() {
  try {
    const m = await api("/api/metrics");
    const open = m.by_status.filter((r) => r.status !== "CLOSED").reduce((a, r) => a + r.n, 0);
    const kpi = (v, l) => el("div", { class: "kpi" }, el("div", { class: "v" }, v), el("div", { class: "l" }, l));
    $("#kpis").replaceChildren(
      kpi(open, "Open cases"),
      kpi(m.sla_breached, "SLA breached"),
      kpi(`${m.avg_hours_to_close_30d}h`, "Avg time to close (30d)"),
      kpi(m.false_positive_rate_30d == null ? "—" : `${(m.false_positive_rate_30d * 100).toFixed(1)}%`, "False-positive rate (30d)"));
    const bars = (rows, labelKey) => {
      const max = Math.max(1, ...rows.map((r) => r.n));
      return rows.map((r) => {
        const fill = el("div", { class: "fill" });
        fill.style.width = `${(100 * r.n / max).toFixed(1)}%`; // CSSOM, allowed under strict style-src
        return el("div", { class: "bar" }, el("span", {}, r[labelKey]), el("div", { class: "track" }, fill),
          el("span", { class: "num" }, r.n));
      });
    };
    const sev = ["CRITICAL", "HIGH", "MEDIUM", "LOW"].map((s) => ({ severity: s,
      n: m.by_status.filter((r) => r.severity === s && r.status !== "CLOSED").reduce((a, r) => a + r.n, 0) }));
    $("#sev-bars").replaceChildren(...bars(sev, "severity"));
    $("#typ-bars").replaceChildren(...bars(m.by_typology_30d || [], "typology"));
  } catch (e) { toast(`Could not load metrics: ${e.message}`); }
}

loadQueue();
setInterval(loadQueue, 30000);
