"""Combine ML probability and rule hits into an auditable decision."""

from __future__ import annotations

from finsentinel_common.models import Decision, RuleHit


def combine(ml_score: float, hits: list[RuleHit]) -> float:
    """Noisy-OR: each independent signal can only increase risk.

    risk = 1 - (1 - ml) * Π(1 - rule_i)
    """
    keep = 1.0 - ml_score
    for h in hits:
        keep *= 1.0 - h.score
    return round(1.0 - keep, 4)


def decide(risk: float, hits: list[RuleHit], review_t: float, block_t: float) -> Decision:
    if any(h.hard_block for h in hits):
        return Decision.BLOCK
    if risk >= block_t:
        return Decision.BLOCK
    if risk >= review_t:
        return Decision.REVIEW
    return Decision.APPROVE
