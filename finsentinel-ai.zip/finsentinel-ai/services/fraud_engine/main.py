"""Fraud Engine — real-time transaction risk scoring.

Two entry points:
  POST /pubsub/transactions   Pub/Sub push (async path, ordered per account)
  POST /v1/score              synchronous scoring for card/UPI authorisation
                              (called service-to-service by the ingest API)

Each transaction: features (Redis) -> rules + ML -> decision -> publish to
`fraud-decisions` (BigQuery subscription persists every decision) and, when
not APPROVE, to `fraud-alerts` (case service opens an investigation).
Processing is idempotent on transaction_id, so Pub/Sub redeliveries are safe.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone

from fastapi import Depends, Request

from finsentinel_common.config import get_settings
from finsentinel_common.features import FeatureStore, TxnView
from finsentinel_common.http import create_app
from finsentinel_common.logging_setup import log
from finsentinel_common.models import Decision, FraudDecision, Transaction
from finsentinel_common.pubsub import decode_push, publish
from finsentinel_common.redis_client import get_redis
from finsentinel_common.security import verify_pubsub_push

import decision as decision_mod
import rules
import scorer

logger = logging.getLogger("fraud_engine")
settings = get_settings()
app = create_app("FinSentinel Fraud Engine")

_watchlist_cache: dict = {"at": 0.0, "items": set()}


def _watchlist() -> set[str]:
    """Sanctions / internal block list kept in Redis, refreshed every 60s.
    Loaded by tools/load_watchlist.py from the bank's screening source."""
    now = time.time()
    if now - _watchlist_cache["at"] > 60:
        try:
            _watchlist_cache["items"] = set(get_redis().smembers("watchlist"))
            _watchlist_cache["at"] = now
        except Exception:  # noqa: BLE001 - keep last known list on Redis blip
            logger.warning("watchlist refresh failed; using cached copy")
    return _watchlist_cache["items"]


def score_transaction(txn: Transaction) -> FraudDecision:
    start = time.perf_counter()
    store = FeatureStore(get_redis(), ctr_threshold=settings.ctr_threshold_inr)
    features = store.compute_and_update(TxnView.from_model(txn))
    txn_dict = txn.model_dump(mode="json")

    hits = rules.evaluate(features, txn_dict, {"watchlist": _watchlist()})
    ml_p, model_version, contrib = scorer.score(features)
    risk = decision_mod.combine(ml_p, hits)
    verdict = decision_mod.decide(risk, hits, settings.review_threshold, settings.block_threshold)

    return FraudDecision(
        transaction_id=txn.transaction_id,
        account_id=txn.account_id,
        customer_id=txn.customer_id,
        amount=float(txn.amount),
        currency=txn.currency,
        channel=txn.channel.value,
        event_time=txn.event_time.isoformat(),
        decision=verdict,
        risk_score=risk,
        ml_score=round(ml_p, 4),
        model_version=model_version,
        rule_hits=hits,
        top_features=contrib,
        features=features,
        regulatory_flags=rules.regulatory_flags(txn_dict, settings.ctr_threshold_inr),
        latency_ms=round((time.perf_counter() - start) * 1000, 2),
        scored_at=datetime.now(timezone.utc).isoformat(),
    )


def _emit(txn: Transaction, d: FraudDecision) -> None:
    publish(settings.topic_decisions, d.to_bigquery_row(), ordering_key=txn.account_id)
    if d.decision != Decision.APPROVE or d.regulatory_flags:
        publish(
            settings.topic_alerts,
            {"decision": d.model_dump(mode="json", exclude={"features"}), "transaction": txn.model_dump(mode="json")},
            ordering_key=txn.account_id,
            severity=d.decision.value,
        )


def _process(txn: Transaction) -> FraudDecision | None:
    r = get_redis()
    done_key = f"done:{txn.transaction_id}"
    if r.exists(done_key):
        return None  # duplicate delivery
    d = score_transaction(txn)
    _emit(txn, d)
    r.set(done_key, d.decision.value, ex=7 * 86400)
    log(logger, logging.INFO, "scored", transaction_id=txn.transaction_id, decision=d.decision.value,
        risk=d.risk_score, latency_ms=d.latency_ms, model=d.model_version)
    return d


@app.post("/pubsub/transactions", dependencies=[Depends(verify_pubsub_push)])
async def pubsub_transactions(request: Request):
    payload, _, message_id = decode_push(await request.json())
    try:
        txn = Transaction.model_validate(payload)
    except Exception:  # noqa: BLE001
        # Schema-invalid events are already filtered at ingest; ack and log to avoid poison loops.
        log(logger, logging.ERROR, "invalid transaction on topic", message_id=message_id)
        return {"status": "rejected"}
    _process(txn)
    return {"status": "ok"}


@app.post("/v1/score")
async def score_sync(txn: Transaction):
    """Synchronous scoring. Cloud Run IAM (roles/run.invoker) restricts callers
    to the ingest service account; ingress is internal-only."""
    d = _process(txn)
    if d is None:
        prior = get_redis().get(f"done:{txn.transaction_id}")
        return {"transaction_id": txn.transaction_id, "decision": prior, "duplicate": True}
    return d.model_dump(mode="json")
