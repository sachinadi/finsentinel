"""ML scoring: Vertex AI endpoint with a strict latency budget and safe fallback.

If the endpoint is slow or unavailable the engine must still decide within
the payment authorisation SLA, so we fall back to a transparent logistic
scorecard. The fallback is logged and surfaced in `model_version` so
monitoring can alert on degraded mode.
"""

from __future__ import annotations

import concurrent.futures
import logging
import math
from functools import lru_cache

from finsentinel_common.config import get_settings
from finsentinel_common.features import FEATURE_ORDER, to_vector

logger = logging.getLogger(__name__)

# Transparent scorecard weights (log-odds). Used as fallback and in local dev.
SCORECARD = {
    "bias": -4.2,
    "amount_zscore": 0.45,
    "txn_count_1h": 0.08,
    "is_new_device": 1.2,
    "is_new_counterparty": 0.5,
    "counterparty_fanin_24h": 0.06,
    "geo_velocity_kmh": 0.0025,
    "is_night_ist": 0.6,
    "is_international": 0.7,
    "mcc_risk": 1.1,
    "small_txn_burst_10m": 0.35,
    "near_threshold_cash_24h": 0.9,
    "passthrough_ratio_24h": 1.4,
}

_pool = concurrent.futures.ThreadPoolExecutor(max_workers=32)


def scorecard(features: dict[str, float]) -> tuple[float, dict[str, float]]:
    contributions = {k: SCORECARD[k] * features.get(k, 0.0) for k in SCORECARD if k != "bias"}
    z = SCORECARD["bias"] + sum(contributions.values())
    top = dict(sorted(contributions.items(), key=lambda kv: -abs(kv[1]))[:5])
    return 1 / (1 + math.exp(-z)), {k: round(v, 3) for k, v in top.items()}


@lru_cache(maxsize=1)
def _endpoint():
    from google.cloud import aiplatform

    s = get_settings()
    aiplatform.init(project=s.project_id, location=s.region)
    return aiplatform.Endpoint(s.vertex_endpoint_id)


def score(features: dict[str, float]) -> tuple[float, str, dict[str, float]]:
    """Return (probability_of_fraud, model_version, top_feature_contributions)."""
    s = get_settings()
    fallback_p, contrib = scorecard(features)
    if not s.vertex_endpoint_id:
        return fallback_p, "scorecard-v1", contrib
    try:
        fut = _pool.submit(lambda: _endpoint().predict(instances=[to_vector(features)]))
        pred = fut.result(timeout=s.vertex_timeout_s)
        value = pred.predictions[0]
        p = float(value[-1] if isinstance(value, list) else value)
        return p, s.model_version, contrib
    except concurrent.futures.TimeoutError:
        logger.warning("Vertex endpoint exceeded latency budget; scorecard fallback")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Vertex endpoint error (%s); scorecard fallback", type(exc).__name__)
    return fallback_p, "scorecard-v1-fallback", contrib


assert set(SCORECARD) - {"bias"} <= set(FEATURE_ORDER), "scorecard references unknown feature"
