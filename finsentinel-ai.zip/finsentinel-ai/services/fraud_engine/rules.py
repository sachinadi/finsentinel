"""Deterministic fraud & AML rules.

Rules complement the ML model: they encode known typologies and regulatory
obligations that must fire regardless of model confidence, and they are
trivially explainable to auditors. Each rule returns a RuleHit with a score
in [0,1]; scores are combined with the ML score in decision.py.

Typologies covered (frequent pain points for Indian and global banks):
  ATO          account takeover (new device + unusual amount / night activity)
  CARD_TEST    card-testing bursts of tiny authorisations
  IMPOSSIBLE   impossible travel between consecutive transactions
  MULE         money-mule pass-through and counterparty fan-in
  STRUCTURING  cash just under the reporting threshold (smurfing)
  WATCHLIST    sanctioned / internally blocked counterparties (hard block)
  HIGH_RISK_MCC gambling, quasi-cash, crypto on-ramps
"""

from __future__ import annotations

from typing import Callable

from finsentinel_common.models import RuleHit

Rule = Callable[[dict, dict, dict], "RuleHit | None"]


def r_account_takeover(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["is_new_device"] and f["amount_zscore"] > 2.5:
        score = 0.55 + 0.1 * f["is_night_ist"] + 0.1 * f["is_new_counterparty"]
        return RuleHit(code="ATO_NEW_DEVICE_SPIKE", score=min(score, 0.85), typology="ATO",
                       reason=f"New device with amount {f['amount_zscore']:.1f}σ above customer norm"
                              + (" at night (IST)" if f["is_night_ist"] else ""))
    return None


def r_card_testing(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["small_txn_burst_10m"] >= 5:
        return RuleHit(code="CARD_TESTING_BURST", score=0.7, typology="CARD_TEST",
                       reason=f"{int(f['small_txn_burst_10m'])} sub-₹100 transactions in 10 minutes")
    return None


def r_impossible_travel(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["geo_velocity_kmh"] > 900:  # faster than a commercial flight
        return RuleHit(code="IMPOSSIBLE_TRAVEL", score=0.65, typology="IMPOSSIBLE",
                       reason=f"Implied travel speed {f['geo_velocity_kmh']:.0f} km/h since last transaction")
    return None


def r_velocity(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["txn_count_1h"] >= 15:
        return RuleHit(code="HIGH_VELOCITY", score=0.45, typology="VELOCITY",
                       reason=f"{int(f['txn_count_1h'])} transactions in the past hour")
    return None


def r_mule_passthrough(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["passthrough_ratio_24h"] > 0.85 and f["amount_sum_24h_log"] > 11.5:  # > ~₹1 lakh moved
        return RuleHit(code="MULE_PASSTHROUGH", score=0.6, typology="MULE",
                       reason="Funds credited and debited out within 24h at near-equal value (pass-through)")
    return None


def r_counterparty_fanin(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["counterparty_fanin_24h"] >= 20:
        return RuleHit(code="MULE_FANIN", score=0.6, typology="MULE",
                       reason=f"Beneficiary received funds from ~{int(f['counterparty_fanin_24h'])} distinct accounts in 24h")
    return None


def r_structuring(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["near_threshold_cash_24h"] >= 2:
        return RuleHit(code="CASH_STRUCTURING", score=0.6, typology="STRUCTURING",
                       reason="Multiple cash transactions just below the CTR reporting threshold within 24h")
    return None


def r_high_risk_mcc(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    if f["mcc_risk"] >= 0.8 and f["amount_zscore"] > 1.5:
        return RuleHit(code="HIGH_RISK_MCC", score=0.4, typology="HIGH_RISK_MCC",
                       reason=f"High-risk merchant category {t.get('merchant_category_code')} with unusual amount")
    return None


def r_watchlist(f: dict, t: dict, ctx: dict) -> RuleHit | None:
    watch = ctx.get("watchlist", set())
    for field in ("counterparty_id", "merchant_id", "device_id"):
        if t.get(field) and t[field] in watch:
            return RuleHit(code="WATCHLIST_MATCH", score=1.0, typology="WATCHLIST", hard_block=True,
                           reason=f"{field} matches sanctions/internal block list")
    return None


RULES: list[Rule] = [
    r_watchlist, r_account_takeover, r_card_testing, r_impossible_travel, r_velocity,
    r_mule_passthrough, r_counterparty_fanin, r_structuring, r_high_risk_mcc,
]


def evaluate(features: dict, txn: dict, ctx: dict | None = None) -> list[RuleHit]:
    ctx = ctx or {}
    hits = []
    for rule in RULES:
        hit = rule(features, txn, ctx)
        if hit:
            hits.append(hit)
    return hits


def regulatory_flags(txn: dict, ctr_threshold: float) -> list[str]:
    """Reporting obligations independent of fraud risk (e.g. PMLA CTR)."""
    flags = []
    if txn.get("channel") in ("BRANCH_CASH", "ATM") and float(txn["amount"]) >= ctr_threshold:
        flags.append("CTR_REPORTABLE")
    if txn.get("is_international") and float(txn["amount"]) >= 500_000:
        flags.append("CROSS_BORDER_REPORTABLE")
    return flags
