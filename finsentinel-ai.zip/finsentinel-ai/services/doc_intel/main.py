"""Document Intelligence — KYC, lending and claims document processing.

Upload (analyst/KYC officer via console) -> validated & stored in a CMEK bucket
-> async processing via Pub/Sub: Document AI OCR/Form Parser -> Gemini
structured extraction (multimodal, also flags visual tampering) ->
deterministic integrity checks -> PII tokenisation/DLP -> results to Cloud SQL
and (PII-free) to BigQuery for analytics.
"""

from __future__ import annotations

import hashlib
import json
import logging
import pathlib
import time
import uuid
from typing import Literal

from fastapi import Depends, File, Form, HTTPException, Query, Request, UploadFile
from sqlalchemy import text

from finsentinel_common import audit
from finsentinel_common.config import get_settings
from finsentinel_common.db import rows, tx
from finsentinel_common.http import create_app
from finsentinel_common.logging_setup import log
from finsentinel_common.pii import tokenize
from finsentinel_common.pubsub import decode_push, publish
from finsentinel_common.security import Principal, require_role, verify_pubsub_push

import checks
import extractor

logger = logging.getLogger("doc_intel")
settings = get_settings()
app = create_app("FinSentinel Document Intelligence")

MAX_BYTES = 20 * 1024 * 1024
MAGIC = {
    b"%PDF": "application/pdf",
    b"\x89PNG": "image/png",
    b"\xff\xd8\xff": "image/jpeg",
    b"II*\x00": "image/tiff",
    b"MM\x00*": "image/tiff",
}
DocType = Literal["KYC_ID", "BANK_STATEMENT", "SALARY_SLIP", "INSURANCE_CLAIM", "INVOICE"]
SENSITIVE_FIELDS = {"id_number", "policy_number", "account_number"}

uploader = require_role("analyst", "kyc_officer", "claims_officer", "supervisor")


def _sniff(head: bytes) -> str | None:
    return next((mime for sig, mime in MAGIC.items() if head.startswith(sig)), None)


def _store(object_name: str, data: bytes, mime: str) -> str:
    if settings.is_dev:
        path = pathlib.Path(settings.local_storage_dir) / object_name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return f"file://{path}"
    from google.cloud import storage

    blob = storage.Client().bucket(settings.raw_docs_bucket).blob(object_name)
    # Bucket default CMEK key applies; if_generation_match=0 prevents overwrites.
    blob.upload_from_string(data, content_type=mime, if_generation_match=0)
    return f"gs://{settings.raw_docs_bucket}/{object_name}"


@app.post("/api/documents", status_code=202)
async def upload(
    file: UploadFile = File(...),
    customer_id: str = Form(..., min_length=4, max_length=64),
    doc_type: DocType = Form(...),
    expected_name: str | None = Form(default=None, max_length=200),
    p: Principal = Depends(uploader),
):
    data = await file.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "file exceeds 20 MB")
    mime = _sniff(data[:8])
    if not mime:
        raise HTTPException(415, "only PDF, PNG, JPEG or TIFF are accepted")
    digest = hashlib.sha256(data).hexdigest()
    doc_id = str(uuid.uuid4())
    # Object names carry no PII: tokenised customer id + random doc id.
    obj = f"{tokenize(customer_id, settings.pii_tokenization_key)}/{doc_id}"

    with tx() as conn:
        existing = conn.execute(text(
            "SELECT id, status FROM documents WHERE customer_id=:c AND doc_type=:t AND sha256=:h"),
            {"c": customer_id, "t": doc_type, "h": digest}).first()
        if existing:
            return {"document_id": str(existing[0]), "status": existing[1], "duplicate": True}
        uri = _store(obj, data, mime)
        conn.execute(text("""INSERT INTO documents (id, customer_id, doc_type, gcs_uri, sha256, mime_type, size_bytes, uploaded_by)
                             VALUES (CAST(:id AS UUID), :c, :t, :u, :h, :m, :s, :by)"""),
                     dict(id=doc_id, c=customer_id, t=doc_type, u=uri, h=digest, m=mime, s=len(data), by=p.email))
        audit.record(p.email, "DOCUMENT_UPLOADED", "document", doc_id, {"doc_type": doc_type, "bytes": len(data)}, conn=conn)

    publish(settings.topic_doc_uploaded, {"document_id": doc_id, "expected_name": expected_name})
    return {"document_id": doc_id, "status": "UPLOADED"}


def _protect(extracted: dict) -> dict:
    """Tokenise identifiers, keep last 4 for analyst recognition."""
    out = dict(extracted)
    for f in SENSITIVE_FIELDS & out.keys():
        raw = str(out[f] or "")
        if raw:
            out[f] = {"token": tokenize(raw, settings.pii_tokenization_key), "last4": raw[-4:]}
    # Free-text narrative can contain third-party PII; de-identify with Cloud DLP before storing.
    if out.get("incident_description"):
        out["incident_description"] = extractor.deidentify(out["incident_description"])
    return out


@app.post("/pubsub/documents", dependencies=[Depends(verify_pubsub_push)])
async def process(request: Request):
    payload, _, _ = decode_push(await request.json())
    doc_id = payload["document_id"]
    with tx() as conn:
        found = rows(conn.execute(text("SELECT * FROM documents WHERE id = CAST(:id AS UUID) FOR UPDATE"), {"id": doc_id}))
        if not found:
            return {"status": "missing"}
        doc = found[0]
        if doc["status"] in ("PROCESSED", "NEEDS_REVIEW"):
            return {"status": "already_processed"}
        conn.execute(text("UPDATE documents SET status='PROCESSING' WHERE id = CAST(:id AS UUID)"), {"id": doc_id})

    start = time.perf_counter()
    try:
        ocr_result = extractor.ocr(doc["gcs_uri"], doc["mime_type"], doc["doc_type"])
        extracted = extractor.extract(doc["doc_type"], doc["gcs_uri"], doc["mime_type"], ocr_result)
        results, level = checks.run_checks(doc["doc_type"], extracted, payload.get("expected_name"))
    except Exception as exc:  # noqa: BLE001
        log(logger, logging.ERROR, "document processing failed", document_id=doc_id, error=type(exc).__name__)
        with tx() as conn:
            conn.execute(text("UPDATE documents SET status='FAILED' WHERE id = CAST(:id AS UUID)"), {"id": doc_id})
        raise HTTPException(500, "processing failed") from exc  # Pub/Sub retries, then dead-letters

    status = "NEEDS_REVIEW" if level in ("HIGH", "MEDIUM") else "PROCESSED"
    protected = _protect(extracted)
    elapsed = round((time.perf_counter() - start) * 1000)
    with tx() as conn:
        conn.execute(text("""UPDATE documents SET status=:st, extracted=CAST(:e AS JSONB), checks=CAST(:c AS JSONB),
                             risk_level=:r, processed_at=now() WHERE id = CAST(:id AS UUID)"""),
                     {"st": status, "e": json.dumps(protected), "c": json.dumps(results), "r": level, "id": doc_id})
        audit.record("system:doc-intel", "DOCUMENT_PROCESSED", "document", doc_id,
                     {"risk_level": level, "failed_checks": [c["check"] for c in results if not c["passed"]]}, conn=conn)

    publish(settings.topic_doc_results, {
        "document_id": doc_id,
        "customer_token": tokenize(doc["customer_id"], settings.pii_tokenization_key),
        "doc_type": doc["doc_type"], "risk_level": level, "status": status,
        "failed_checks": [c["check"] for c in results if not c["passed"]],
        "tamper_signal_count": len(extracted.get("tamper_signals") or []),
        "pages": ocr_result.get("pages", 0), "processing_ms": elapsed,
        "processed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    })
    return {"status": status, "risk_level": level}


@app.get("/api/documents/{doc_id}")
def get_document(doc_id: str, p: Principal = Depends(uploader)):
    with tx() as conn:
        found = rows(conn.execute(text(
            "SELECT id, customer_id, doc_type, status, risk_level, extracted, checks, mime_type, size_bytes, "
            "uploaded_by, created_at, processed_at FROM documents WHERE id = CAST(:id AS UUID)"), {"id": doc_id}))
        if not found:
            raise HTTPException(404, "not found")
        audit.record(p.email, "DOCUMENT_VIEWED", "document", doc_id, conn=conn)
    d = found[0]
    return {k: (str(v) if k in ("id", "created_at", "processed_at") and v is not None else v) for k, v in d.items()}


@app.get("/api/documents")
def list_documents(customer_id: str = Query(..., min_length=4), p: Principal = Depends(uploader)):
    with tx() as conn:
        docs = rows(conn.execute(text(
            "SELECT id, doc_type, status, risk_level, created_at FROM documents WHERE customer_id=:c "
            "ORDER BY created_at DESC LIMIT 100"), {"c": customer_id}))
    return {"documents": [{**d, "id": str(d["id"]), "created_at": d["created_at"].isoformat()} for d in docs]}
