"""Deterministic integrity checks on extracted document data.

LLM extraction is good at reading documents; arithmetic and format rules are
better done in code. These checks catch the most common document-fraud
patterns seen in lending and claims: edited balances, inflated salaries,
padded invoices, expired or malformed IDs.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from difflib import SequenceMatcher

TOL = 1.0  # currency units

# Verhoeff tables (Aadhaar check digit)
_D = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],
      [4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],
      [8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]]
_P = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],
      [9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]]


def verhoeff_valid(num: str) -> bool:
    digits = re.sub(r"\D", "", num or "")
    if len(digits) != 12:
        return False
    c = 0
    for i, ch in enumerate(reversed(digits)):
        c = _D[c][_P[i % 8][int(ch)]]
    return c == 0


def _num(v) -> float | None:
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(re.sub(r"[^\d.\-]", "", str(v)))
    except ValueError:
        return None


def _date(v) -> date | None:
    if not v:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d %b %Y", "%d %B %Y"):
        try:
            return datetime.strptime(str(v).strip(), fmt).date()
        except ValueError:
            continue
    return None


def _check(name: str, passed: bool, detail: str, severity: str = "HIGH") -> dict:
    return {"check": name, "passed": bool(passed), "detail": detail, "severity": "INFO" if passed else severity}


def name_similarity(a: str | None, b: str | None) -> float:
    if not a or not b:
        return 0.0
    norm = lambda s: " ".join(sorted(re.sub(r"[^a-z ]", "", s.lower()).split()))  # noqa: E731
    return SequenceMatcher(None, norm(a), norm(b)).ratio()


def check_kyc(d: dict, expected_name: str | None, today: date | None = None) -> list[dict]:
    today = today or date.today()
    out = []
    id_type, id_no = (d.get("id_type") or "").upper(), d.get("id_number") or ""
    if id_type == "AADHAAR":
        out.append(_check("aadhaar_checksum", verhoeff_valid(id_no), "Verhoeff check digit"))
    elif id_type == "PAN":
        out.append(_check("pan_format", bool(re.fullmatch(r"[A-Z]{5}\d{4}[A-Z]", id_no.replace(" ", ""))), "PAN format AAAAA9999A"))
    expiry = _date(d.get("expiry_date"))
    if expiry:
        out.append(_check("id_not_expired", expiry >= today, f"expiry {expiry.isoformat()}"))
    dob = _date(d.get("date_of_birth"))
    if dob:
        age = (today - dob).days / 365.25
        out.append(_check("age_plausible", 18 <= age <= 110, f"age {age:.0f}", "MEDIUM"))
    if expected_name:
        sim = name_similarity(d.get("name"), expected_name)
        out.append(_check("name_match", sim >= 0.85, f"similarity {sim:.2f}", "HIGH" if sim < 0.6 else "MEDIUM"))
    return out


def check_statement(d: dict) -> list[dict]:
    out = []
    txns = d.get("transactions") or []
    bad_rows, prev = [], _num(d.get("opening_balance"))
    credits = debits = 0.0
    prev_date = None
    out_of_order = 0
    for i, t in enumerate(txns):
        cr, dr, bal = _num(t.get("credit")) or 0.0, _num(t.get("debit")) or 0.0, _num(t.get("balance"))
        credits += cr
        debits += dr
        if prev is not None and bal is not None and abs(prev + cr - dr - bal) > TOL:
            bad_rows.append(i)
        prev = bal if bal is not None else prev
        dt = _date(t.get("date"))
        if dt and prev_date and dt < prev_date:
            out_of_order += 1
        prev_date = dt or prev_date
    if txns:
        out.append(_check("running_balance", not bad_rows,
                          f"{len(bad_rows)} row(s) where balance != previous + credit - debit" + (f" (rows {bad_rows[:5]})" if bad_rows else "")))
        out.append(_check("date_order", out_of_order == 0, f"{out_of_order} out-of-order dates", "MEDIUM"))
    ob, cb = _num(d.get("opening_balance")), _num(d.get("closing_balance"))
    if ob is not None and cb is not None and txns:
        out.append(_check("opening_to_closing", abs(ob + credits - debits - cb) <= TOL,
                          f"opening {ob:,.2f} + credits {credits:,.2f} - debits {debits:,.2f} vs closing {cb:,.2f}"))
    round_credits = [c for c in (_num(t.get("credit")) for t in txns) if c and c >= 10000 and c % 1000 == 0]
    if txns:
        share = len(round_credits) / max(1, sum(1 for t in txns if _num(t.get("credit"))))
        out.append(_check("round_number_credits", share < 0.5, f"{share:.0%} of credits are round thousands", "MEDIUM"))
    return out


def check_salary(d: dict) -> list[dict]:
    g, n, ded = _num(d.get("gross_pay")), _num(d.get("net_pay")), _num(d.get("deductions_total"))
    if g is None or n is None or ded is None:
        return [_check("salary_fields_present", False, "gross/net/deductions missing", "MEDIUM")]
    return [_check("gross_minus_deductions", abs(g - ded - n) <= TOL, f"{g:,.2f} - {ded:,.2f} vs net {n:,.2f}"),
            _check("net_le_gross", n <= g, "net pay must not exceed gross")]


def check_line_items(d: dict, total_field: str) -> list[dict]:
    items = d.get("line_items") or []
    total = _num(d.get(total_field))
    out = []
    if items and total is not None:
        s = sum(_num(i.get("amount")) or 0.0 for i in items) + (_num(d.get("tax_amount")) or 0.0)
        out.append(_check("line_items_sum", abs(s - total) <= max(TOL, 0.01 * total),
                          f"items {s:,.2f} vs {total_field} {total:,.2f}"))
    incident = _date(d.get("incident_date") or d.get("invoice_date"))
    if incident:
        out.append(_check("date_not_future", incident <= date.today(), f"date {incident.isoformat()}"))
    return out


def run_checks(doc_type: str, extracted: dict, expected_name: str | None = None) -> tuple[list[dict], str]:
    if doc_type == "KYC_ID":
        checks = check_kyc(extracted, expected_name)
    elif doc_type == "BANK_STATEMENT":
        checks = check_statement(extracted)
    elif doc_type == "SALARY_SLIP":
        checks = check_salary(extracted)
    elif doc_type == "INSURANCE_CLAIM":
        checks = check_line_items(extracted, "claim_amount")
    elif doc_type == "INVOICE":
        checks = check_line_items(extracted, "total_amount")
    else:
        checks = []
    tamper = extracted.get("tamper_signals") or []
    if tamper:
        checks.append(_check("visual_tamper_signals", False, "; ".join(tamper[:5]),
                             "HIGH" if len(tamper) >= 2 else "MEDIUM"))
    failed = [c for c in checks if not c["passed"]]
    if any(c["severity"] == "HIGH" for c in failed):
        level = "HIGH"
    elif failed:
        level = "MEDIUM"
    else:
        level = "LOW"
    return checks, level
