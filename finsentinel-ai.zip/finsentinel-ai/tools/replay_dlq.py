"""Replay dead-lettered messages back to their source topic after a fix is deployed.

  python tools/replay_dlq.py --project PROJECT --subscription transactions-fraud-engine-dlq-hold \
      --topic transactions [--max 1000] [--dry-run]

Messages keep their attributes; ordering keys are not preserved by dead-lettering, so
replay transactions per account in time order (the fraud engine is idempotent on
transaction_id, so replays never double-score).
"""

from __future__ import annotations

import argparse
import json

from google.cloud import pubsub_v1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--subscription", required=True)
    ap.add_argument("--topic", required=True)
    ap.add_argument("--max", type=int, default=1000)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    sub = pubsub_v1.SubscriberClient()
    pub = pubsub_v1.PublisherClient()
    sub_path = sub.subscription_path(a.project, a.subscription)
    topic_path = pub.topic_path(a.project, a.topic)
    replayed = 0
    while replayed < a.max:
        resp = sub.pull(request={"subscription": sub_path, "max_messages": min(100, a.max - replayed)}, timeout=30)
        if not resp.received_messages:
            break
        msgs = sorted(resp.received_messages, key=lambda m: json.loads(m.message.data or b"{}").get("event_time", ""))
        for m in msgs:
            if not a.dry_run:
                attrs = {k: v for k, v in m.message.attributes.items() if not k.startswith("CloudPubSubDeadLetter")}
                pub.publish(topic_path, m.message.data, **attrs).result(timeout=30)
            replayed += 1
        if not a.dry_run:
            sub.acknowledge(request={"subscription": sub_path, "ack_ids": [m.ack_id for m in msgs]})
    print(f"{'would replay' if a.dry_run else 'replayed'} {replayed} message(s) to {a.topic}")


if __name__ == "__main__":
    main()
