"""Create topics and push subscriptions on the local Pub/Sub emulator (docker compose)."""

from __future__ import annotations

import os
import time

from google.api_core.exceptions import AlreadyExists
from google.cloud import pubsub_v1

PROJECT = os.getenv("PUBSUB_PROJECT_ID", "local-project")
ROUTES = {
    "transactions": "http://fraud_engine:8080/pubsub/transactions",
    "fraud-alerts": "http://case_service:8080/pubsub/alerts",
    "doc-uploaded": "http://doc_intel:8080/pubsub/documents",
}
SINK_ONLY = ["fraud-decisions", "case-feedback", "doc-results"]  # BigQuery subscriptions in GCP

pub, sub = pubsub_v1.PublisherClient(), pubsub_v1.SubscriberClient()
for _ in range(30):
    try:
        list(pub.list_topics(request={"project": f"projects/{PROJECT}"}))
        break
    except Exception:  # noqa: BLE001
        time.sleep(1)

for topic in list(ROUTES) + SINK_ONLY:
    try:
        pub.create_topic(name=pub.topic_path(PROJECT, topic))
    except AlreadyExists:
        pass

for topic, endpoint in ROUTES.items():
    try:
        sub.create_subscription(request={
            "name": sub.subscription_path(PROJECT, f"{topic}-push"),
            "topic": pub.topic_path(PROJECT, topic),
            "push_config": {"push_endpoint": endpoint},
            "ack_deadline_seconds": 60,
            "enable_message_ordering": topic == "transactions",
        })
    except AlreadyExists:
        pass
print("emulator ready:", ", ".join(ROUTES))
