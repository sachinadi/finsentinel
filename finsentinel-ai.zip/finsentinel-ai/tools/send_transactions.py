"""Replay a JSONL file to the ingest API with HMAC signing (demo and load test).

  python tools/send_transactions.py --url https://fraud.example.bank --file data/out/transactions.jsonl \
      --partner core-banking --secret "$PARTNER_SECRET" --batch 200 --rate 500

Timestamps are shifted so the newest event is "now" (the API rejects future times).
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import time
from datetime import datetime, timezone

import httpx


def sign(secret: str, ts: str, body: bytes) -> str:
    return hmac.new(secret.encode(), ts.encode() + b"." + body, hashlib.sha256).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--file", required=True)
    ap.add_argument("--partner", default="core-banking")
    ap.add_argument("--secret", required=True)
    ap.add_argument("--batch", type=int, default=200)
    ap.add_argument("--rate", type=float, default=200, help="transactions per second")
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args()

    rows = [json.loads(line) for line in open(a.file)]
    if a.limit:
        rows = rows[-a.limit:]
    shift = datetime.now(timezone.utc) - max(datetime.fromisoformat(r["event_time"]) for r in rows)
    for r in rows:
        r["event_time"] = (datetime.fromisoformat(r["event_time"]) + shift).isoformat()
        r.pop("_label", None)
        r.pop("_typology", None)

    sent = 0
    with httpx.Client(timeout=30) as client:
        for i in range(0, len(rows), a.batch):
            chunk = rows[i:i + a.batch]
            body = json.dumps(chunk).encode()
            ts = str(int(time.time()))
            resp = client.post(f"{a.url}/api/v1/transactions:batch", content=body, headers={
                "content-type": "application/json", "x-partner-id": a.partner, "x-timestamp": ts,
                "x-signature": sign(a.secret, ts, body)})
            resp.raise_for_status()
            sent += resp.json().get("accepted", 0)
            time.sleep(len(chunk) / a.rate)
            print(f"\rsent {sent:,}/{len(rows):,}", end="", flush=True)
    print()


if __name__ == "__main__":
    main()
