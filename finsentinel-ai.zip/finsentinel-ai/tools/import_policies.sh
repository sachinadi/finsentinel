#!/usr/bin/env bash
# Upload policy documents to GCS and import them into the Vertex AI Search data store
# that grounds the Compliance Copilot.
#
#   ./tools/import_policies.sh <PROJECT_ID> <POLICY_BUCKET> <DATA_STORE_ID> [SOURCE_DIR]
#
# Replace data/policies/*.txt (samples) with the bank's real policies, RBI master
# directions and circulars (PDF/HTML/DOCX/TXT are supported).
set -euo pipefail

PROJECT="${1:?project id}"
BUCKET="${2:?policy bucket}"
DATA_STORE="${3:?data store id}"
SRC="${4:-data/policies}"
LOCATION="${SEARCH_LOCATION:-global}"

echo "Uploading ${SRC} -> gs://${BUCKET}/policies/"
gcloud storage cp --recursive "${SRC}/*" "gs://${BUCKET}/policies/"

HOST="discoveryengine.googleapis.com"
[[ "${LOCATION}" != "global" ]] && HOST="${LOCATION}-discoveryengine.googleapis.com"

echo "Starting import into data store ${DATA_STORE} (${LOCATION})"
curl -sS -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -H "X-Goog-User-Project: ${PROJECT}" \
  "https://${HOST}/v1/projects/${PROJECT}/locations/${LOCATION}/collections/default_collection/dataStores/${DATA_STORE}/branches/0/documents:import" \
  -d "{
        \"gcsSource\": {\"inputUris\": [\"gs://${BUCKET}/policies/*\"], \"dataSchema\": \"content\"},
        \"reconciliationMode\": \"INCREMENTAL\"
      }"
echo
echo "Import started. Track it in Console > AI Applications > Data stores > ${DATA_STORE} > Activity."
