"""Load sanctions / internal block-list identifiers into Redis (set `watchlist`).

Source file: one identifier per line (counterparty ids, merchant ids, device ids),
exported from the bank's screening system (e.g. after UN/OFAC/MHA list refresh).
Runs as a Cloud Run job on a schedule; the swap is atomic so the fraud engine
never sees a half-loaded list.

  python tools/load_watchlist.py --file watchlist.txt
"""

from __future__ import annotations

import argparse
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "services" / "common"))
from finsentinel_common.redis_client import get_redis  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    a = ap.parse_args()
    items = {line.strip() for line in open(a.file) if line.strip() and not line.startswith("#")}
    r = get_redis()
    staging = "watchlist:staging"
    r.delete(staging)
    for i in range(0, len(items), 1000):
        r.sadd(staging, *list(items)[i:i + 1000])
    if items:
        r.rename(staging, "watchlist")
    print(f"watchlist now has {len(items):,} entries")


if __name__ == "__main__":
    main()
