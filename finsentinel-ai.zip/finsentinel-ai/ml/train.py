"""Train, evaluate, register and (optionally) deploy the fraud model.

  Local:   python ml/train.py --csv data/out/features.csv --out ml/artifacts
  On GCP:  python ml/train.py --bq-table PROJECT.finsentinel.training_examples \
              --out ml/artifacts --gcs-dir gs://PROJECT-ml-artifacts/fraud/$(date +%Y%m%d%H%M) \
              --endpoint-id ENDPOINT_ID --canary-percent 10

Model governance (RBI model-risk expectations / SR 11-7 style):
  * out-of-time validation (train on earlier data, test on the most recent)
  * metrics that matter for fraud: PR-AUC, recall at a fixed false-positive rate,
    alert volume at the operating threshold
  * promotion gate: refuses to register a model below --min-pr-auc
  * a model card (model_card.md) is written next to the artifact
  * new versions go to the endpoint as a canary; promote after monitoring
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_auc_score, roc_curve

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services" / "common"))
from finsentinel_common.features import FEATURE_ORDER  # noqa: E402


def load(args) -> pd.DataFrame:
    if args.csv:
        return pd.read_csv(args.csv, parse_dates=["event_time"])
    from google.cloud import bigquery

    df = bigquery.Client().query(f"SELECT * FROM `{args.bq_table}`").to_dataframe()
    df["event_time"] = pd.to_datetime(df["event_time"])
    return df


def recall_at_fpr(y, p, target_fpr=0.01) -> float:
    fpr, tpr, _ = roc_curve(y, p)
    return float(np.interp(target_fpr, fpr, tpr))


def main():
    ap = argparse.ArgumentParser()
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--csv")
    src.add_argument("--bq-table")
    ap.add_argument("--out", default="ml/artifacts")
    ap.add_argument("--test-frac", type=float, default=0.2)
    ap.add_argument("--min-pr-auc", type=float, default=0.5)
    ap.add_argument("--review-threshold", type=float, default=0.5)
    ap.add_argument("--gcs-dir")
    ap.add_argument("--endpoint-id")
    ap.add_argument("--region", default="asia-south1")
    ap.add_argument("--canary-percent", type=int, default=10)
    ap.add_argument("--serving-image", default="asia-docker.pkg.dev/vertex-ai/prediction/xgboost-cpu.2-1:latest")
    ap.add_argument("--service-account", help="SA the endpoint runs as")
    args = ap.parse_args()

    df = load(args).sort_values("event_time").reset_index(drop=True)
    cut = int(len(df) * (1 - args.test_frac))
    train, test = df.iloc[:cut], df.iloc[cut:]
    Xtr, ytr = train[FEATURE_ORDER].astype(float), train["label"].astype(int)
    Xte, yte = test[FEATURE_ORDER].astype(float), test["label"].astype(int)
    if ytr.sum() == 0 or yte.sum() == 0:
        raise SystemExit("both splits need positive examples; generate more data")

    pos_weight = float((ytr == 0).sum() / max(1, (ytr == 1).sum()))
    model = xgb.XGBClassifier(
        n_estimators=400, max_depth=6, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8,
        min_child_weight=5, reg_lambda=1.0, scale_pos_weight=pos_weight, eval_metric="aucpr",
        tree_method="hist", early_stopping_rounds=30, random_state=42,
    )
    # Hold out the tail of the training window for early stopping (still out-of-time).
    es = int(len(Xtr) * 0.85)
    model.fit(Xtr.iloc[:es], ytr.iloc[:es], eval_set=[(Xtr.iloc[es:], ytr.iloc[es:])], verbose=False)

    p = model.predict_proba(Xte)[:, 1]
    prec, rec, thr = precision_recall_curve(yte, p)
    idx = int(np.searchsorted(thr, args.review_threshold)) if len(thr) else 0
    metrics = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "rows_train": int(len(train)), "rows_test": int(len(test)),
        "fraud_rate_test": round(float(yte.mean()), 5),
        "roc_auc": round(float(roc_auc_score(yte, p)), 4),
        "pr_auc": round(float(average_precision_score(yte, p)), 4),
        "recall_at_1pct_fpr": round(recall_at_fpr(yte, p, 0.01), 4),
        "precision_at_review_threshold": round(float(prec[min(idx, len(prec) - 1)]), 4),
        "recall_at_review_threshold": round(float(rec[min(idx, len(rec) - 1)]), 4),
        "alert_rate_at_review_threshold": round(float((p >= args.review_threshold).mean()), 5),
        "best_iteration": int(model.best_iteration or 0),
        "features": FEATURE_ORDER,
    }
    if "typology" in test.columns:
        tt = test.assign(p=p)
        metrics["recall_by_typology"] = {
            str(k): round(float((g["p"] >= args.review_threshold).mean()), 3)
            for k, g in tt[tt.label == 1].groupby("typology") if str(k) not in ("", "nan")}
    importance = model.get_booster().get_score(importance_type="gain")
    metrics["feature_importance_gain"] = dict(sorted(
        {FEATURE_ORDER[int(k[1:])] if k.startswith("f") and k[1:].isdigit() else k: round(v, 2)
         for k, v in importance.items()}.items(), key=lambda kv: -kv[1])[:10])

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    # Vertex AI prebuilt XGBoost containers load `model.bst` and expect the feature
    # vector in FEATURE_ORDER, returning P(fraud) for binary:logistic.
    model.get_booster().save_model(str(out / "model.bst"))
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2))
    (out / "model_card.md").write_text(model_card(metrics, args))
    print(json.dumps({k: v for k, v in metrics.items() if k not in ("features",)}, indent=2))

    if metrics["pr_auc"] < args.min_pr_auc:
        raise SystemExit(f"promotion gate failed: PR-AUC {metrics['pr_auc']} < {args.min_pr_auc}")
    if args.gcs_dir:
        upload_and_deploy(out, metrics, args)


def model_card(m: dict, args) -> str:
    return f"""# Fraud scoring model — model card

| Item | Value |
|---|---|
| Trained | {m['trained_at']} |
| Algorithm | XGBoost gradient-boosted trees (binary:logistic), class-weighted |
| Training rows / test rows | {m['rows_train']:,} / {m['rows_test']:,} (out-of-time split) |
| ROC-AUC / PR-AUC | {m['roc_auc']} / {m['pr_auc']} |
| Recall at 1% FPR | {m['recall_at_1pct_fpr']} |
| Precision / recall at review threshold {args.review_threshold} | {m['precision_at_review_threshold']} / {m['recall_at_review_threshold']} |
| Alert rate at review threshold | {m['alert_rate_at_review_threshold']:.3%} |

**Intended use:** risk score input to the FinSentinel decision engine, combined with deterministic rules.
The model never blocks a transaction on its own outside the configured thresholds; analysts make final determinations.

**Features:** {', '.join(m['features'])}. No protected attributes (gender, religion, caste, age) are used as inputs.

**Known limitations:** trained on {'synthetic' if args.csv else 'production'} data; recalibrate thresholds after
deployment using alert-volume targets. Monitor feature drift and PR-AUC on analyst-labelled outcomes weekly.

**Top features by gain:** {json.dumps(m['feature_importance_gain'])}
"""


def upload_and_deploy(out: pathlib.Path, metrics: dict, args) -> None:
    from google.cloud import aiplatform, storage

    bucket, _, prefix = args.gcs_dir.removeprefix("gs://").partition("/")
    client = storage.Client()
    for name in ("model.bst", "metrics.json", "model_card.md"):
        client.bucket(bucket).blob(f"{prefix}/{name}").upload_from_filename(str(out / name))

    aiplatform.init(location=args.region)
    existing = aiplatform.Model.list(filter='display_name="finsentinel-fraud-xgb"')
    model = aiplatform.Model.upload(
        display_name="finsentinel-fraud-xgb",
        artifact_uri=args.gcs_dir,
        serving_container_image_uri=args.serving_image,
        parent_model=existing[0].resource_name if existing else None,
        is_default_version=False,
        version_aliases=["challenger"],
        labels={"app": "finsentinel", "pr_auc": str(metrics["pr_auc"]).replace(".", "_")},
    )
    print(f"registered {model.resource_name} version {model.version_id}")
    if args.endpoint_id:
        endpoint = aiplatform.Endpoint(args.endpoint_id)
        has_traffic = bool(endpoint.traffic_split)
        model.deploy(
            endpoint=endpoint,
            deployed_model_display_name=f"fraud-xgb-v{model.version_id}",
            machine_type="n2-standard-4",
            min_replica_count=2, max_replica_count=20,
            traffic_percentage=args.canary_percent if has_traffic else 100,
            service_account=args.service_account,
        )
        print(f"deployed to endpoint {args.endpoint_id} at {args.canary_percent if has_traffic else 100}% traffic")


if __name__ == "__main__":
    main()
