"""Replay historical transactions through the *production* feature code.

For bootstrapping (before labelled production data exists) we replay a
history file through finsentinel_common.features.FeatureStore against an
in-memory Redis. Once the platform is live, use the BigQuery view
`training_examples` instead (sql/bigquery/training_view.sql) — it joins the
feature snapshots logged at decision time with analyst labels.

Usage:
  python ml/build_features.py --in data/out/transactions.jsonl --out data/out/features.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import pathlib
import sys
from datetime import datetime

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services" / "common"))

import fakeredis  # noqa: E402

from finsentinel_common.features import FEATURE_ORDER, FeatureStore, TxnView  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    store = FeatureStore(fakeredis.FakeRedis(decode_responses=True))
    n = 0
    with open(a.inp) as fin, open(a.out, "w", newline="") as fout:
        w = csv.writer(fout)
        w.writerow(["transaction_id", "event_time", *FEATURE_ORDER, "label", "typology"])
        for line in fin:
            t = json.loads(line)
            geo = t.get("geo") or {}
            view = TxnView(
                transaction_id=t["transaction_id"], account_id=t["account_id"], amount=float(t["amount"]),
                direction=t.get("direction", "DEBIT"), channel=t["channel"],
                ts=datetime.fromisoformat(t["event_time"]).timestamp(),
                counterparty_id=t.get("counterparty_id"), device_id=t.get("device_id"),
                lat=geo.get("lat"), lon=geo.get("lon"), is_international=t.get("is_international", False),
                card_present=t.get("card_present"), mcc=t.get("merchant_category_code"),
            )
            f = store.compute_and_update(view)
            w.writerow([t["transaction_id"], t["event_time"], *[f[k] for k in FEATURE_ORDER],
                        t.get("_label", 0), t.get("_typology", "")])
            n += 1
    print(f"wrote {n:,} feature rows to {a.out}")


if __name__ == "__main__":
    main()
