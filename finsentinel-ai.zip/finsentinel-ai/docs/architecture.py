"""Generates docs/architecture.svg and docs/architecture.png.

    python docs/architecture.py

Kept as code so the diagram is versioned and reviewable alongside the system.
"""

from __future__ import annotations

import pathlib

W, H = 1760, 1150
OUT = pathlib.Path(__file__).parent

C = {
    "ink": "#1b2420", "muted": "#5b6862", "line": "#9aa6a0", "bg": "#ffffff",
    "run": "#e6f2ec", "run_s": "#0f6b4f",
    "ps": "#fdf3df", "ps_s": "#a86f0c",
    "ai": "#ece9fb", "ai_s": "#5a48b8",
    "data": "#e7eef8", "data_s": "#2f5d9a",
    "sec": "#f7e8e6", "sec_s": "#a3352c",
    "edge": "#f1f1ef", "edge_s": "#4a4f4c",
}
# column x positions inside the region
COL = {1: 560, 2: 790, 3: 1020, 4: 1250, 5: 1480}
BW = 205

parts: list[str] = []
under: list[str] = []  # lane backgrounds, drawn beneath everything else


def esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def box(x, y, w, h, title, sub="", kind="run", r=8, title_size=14):
    fill, stroke = C[kind], C[f"{kind}_s"]
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="1.4"/>')
    ty = y + (h / 2 if not sub else h / 2 - 7) + 5
    parts.append(f'<text x="{x + w / 2}" y="{ty}" text-anchor="middle" font-size="{title_size}" font-weight="600" fill="{C["ink"]}">{esc(title)}</text>')
    if sub:
        for i, line in enumerate(sub.split("\n")):
            parts.append(f'<text x="{x + w / 2}" y="{ty + 17 + i * 14}" text-anchor="middle" font-size="11.5" fill="{C["muted"]}">{esc(line)}</text>')
    return (x, y, w, h)


def cbox(col, y, h, title, sub="", kind="run"):
    return box(COL[col], y, BW, h, title, sub, kind)


def arrow(points, label="", dashed=False, color=None, lx=None, ly=None, anchor="middle"):
    color = color or C["edge_s"]
    d = "M " + " L ".join(f"{x} {y}" for x, y in points)
    dash = ' stroke-dasharray="6 4"' if dashed else ""
    parts.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="1.6"{dash} marker-end="url(#arrow)"/>')
    if label:
        if lx is None:
            (x1, y1), (x2, y2) = points[0], points[1]
            lx, ly = (x1 + x2) / 2, (y1 + y2) / 2 - 6
        tw = 6.2 * len(label) + 8
        rx = lx - tw / 2 if anchor == "middle" else (lx - 4 if anchor == "start" else lx - tw + 4)
        parts.append(f'<rect x="{rx}" y="{ly - 11}" width="{tw}" height="15" fill="#ffffff" opacity="0.92"/>')
        parts.append(f'<text x="{lx}" y="{ly}" text-anchor="{anchor}" font-size="11" fill="{C["muted"]}">{esc(label)}</text>')


def badge(x, y, n):
    parts.append(f'<circle cx="{x}" cy="{y}" r="11" fill="{C["run_s"]}"/>'
                 f'<text x="{x}" y="{y + 4}" text-anchor="middle" font-size="12" font-weight="700" fill="#fff">{n}</text>')


def lane(y, h, label):
    under.append(f'<rect x="545" y="{y}" width="1170" height="{h}" rx="6" fill="#fbfcfb" stroke="#e1e6e3"/>')
    under.append(f'<text x="557" y="{y + 18}" font-size="11.5" font-weight="700" fill="{C["muted"]}" letter-spacing="0.6">{esc(label.upper())}</text>')


# ------------------------------------------------------------------ canvas
under.append(f'<rect width="{W}" height="{H}" fill="{C["bg"]}"/>')
parts.append(f'<text x="30" y="44" font-size="24" font-weight="700" fill="{C["ink"]}">FinSentinel AI — fraud, AML, document &amp; compliance intelligence on Google Cloud</text>')
parts.append(f'<text x="30" y="68" font-size="13" fill="{C["muted"]}">Event-driven, serverless, private by default. All customer data stays in asia-south1 (Mumbai), encrypted with customer-managed keys, inside a VPC Service Controls perimeter.</text>')

# region / perimeter
parts.append('<rect x="520" y="92" width="1215" height="1035" rx="14" fill="none" stroke="#2f5d9a" stroke-width="2" stroke-dasharray="9 6"/>')
parts.append(f'<text x="536" y="114" font-size="13" font-weight="700" fill="{C["data_s"]}">Google Cloud project · region asia-south1 · VPC-SC perimeter · CMEK (Cloud KMS/HSM) · no internet egress</text>')

# ------------------------------------------------------------------ actors and edge
box(30, 170, 210, 110, "Partner systems", "Core banking · Card switch\nUPI / IMPS gateway", "edge")
box(30, 520, 210, 120, "Bank staff", "Fraud & AML analysts\nSupervisors · KYC/claims\nofficers · Auditors", "edge")

box(280, 150, 200, 150, "HTTPS Load Balancer", "Cloud Armor: WAF, partner\nIP allow-list, rate-based ban\nTLS 1.2+ · HMAC-signed\nrequests (5-min replay)", "sec", title_size=13)
box(280, 430, 200, 300, "HTTPS Load Balancer", "Cloud Armor WAF (OWASP)\ngeo policy · adaptive\nL7 DDoS protection\n\nIdentity-Aware Proxy\n(Google identity, groups)\n\napp RBAC + maker-checker\nin each service", "sec", title_size=13)

arrow([(240, 225), (280, 225)], "")
arrow([(240, 580), (280, 580)], "")

# ------------------------------------------------------------------ lane 1: real-time risk
lane(128, 210, "1 · Real-time transaction risk  (p99 < 300 ms)")
ing = cbox(1, 160, 70, "Ingest API", "Cloud Run · schema + PAN guard\nidempotency keys")
pst = cbox(2, 160, 70, "Pub/Sub: transactions", "ordered by account · DLQ", "ps")
fe = cbox(3, 160, 70, "Fraud Engine", "Cloud Run · rules + ML\nnoisy-OR decision")
rd = cbox(4, 160, 70, "Memorystore (Redis HA)", "velocity, device, geo,\nfan-in features · TLS", "data")
vx = cbox(5, 160, 70, "Vertex AI endpoint", "XGBoost fraud model\ncanary · scorecard fallback", "ai")
psa = cbox(2, 255, 62, "Pub/Sub: fraud-alerts", "REVIEW / BLOCK / CTR", "ps")
psd = cbox(4, 255, 62, "Pub/Sub: fraud-decisions", "every decision + features", "ps")

arrow([(480, 225), (560, 195)], "")
arrow([(765, 195), (790, 195)], "")
arrow([(995, 195), (1020, 195)], "")
arrow([(1225, 188), (1250, 188)], "")
arrow([(1250, 202), (1225, 202)], "")
arrow([(1455, 195), (1480, 195)], "")
arrow([(662, 230), (662, 248), (1080, 248), (1080, 232)], "sync score (card/UPI auth)", dashed=True, lx=870, ly=244)
arrow([(1040, 230), (1040, 286), (995, 286)], "")
arrow([(1150, 230), (1150, 286), (1250, 286)], "")
arrow([(1455, 286), (1724, 286), (1724, 900), (1352, 900), (1352, 918)], "")
badge(560, 160, 1)

# ------------------------------------------------------------------ lane 2: investigation
lane(350, 175, "2 · Investigation & case management")
con = cbox(1, 385, 70, "Analyst Console", "Cloud Run (nginx) · strict CSP")
cs = cbox(2, 385, 70, "Case Service", "Cloud Run · triage, SLA,\nmaker-checker, audit")
gm = cbox(3, 385, 70, "Gemini on Vertex AI", "case summary · STR draft\nstructured JSON output", "ai")
psf = cbox(4, 385, 70, "Pub/Sub: case-feedback", "analyst labels", "ps")
arrow([(892, 317), (892, 385)], "alerts", lx=900, ly=356, anchor="start")
arrow([(995, 420), (1020, 420)], "")
arrow([(950, 455), (950, 480), (1300, 480), (1300, 457)], "")
arrow([(1455, 420), (1712, 420), (1712, 900)], "")
arrow([(480, 470), (560, 420)], "")
arrow([(765, 420), (790, 420)], "")
badge(790, 385, 2)

# ------------------------------------------------------------------ lane 3: documents
lane(537, 190, "3 · Document intelligence — KYC, lending & claims")
di = cbox(1, 572, 70, "Doc Intelligence", "Cloud Run · magic-byte check\ntokenised identifiers")
gcs = cbox(2, 572, 70, "Cloud Storage", "raw documents · CMEK\nversioned · no public access", "data")
dai = cbox(3, 572, 70, "Document AI (Mumbai)", "OCR · Form Parser", "ai")
gm2 = cbox(4, 572, 70, "Gemini multimodal", "schema extraction +\ntamper signals", "ai")
dlp = cbox(5, 572, 70, "Cloud DLP", "de-identify free text\n(Aadhaar, PAN, names…)", "ai")
psu = cbox(2, 655, 56, "Pub/Sub: doc-uploaded", "async processing", "ps")
psr = cbox(4, 655, 56, "Pub/Sub: doc-results", "PII-free outcomes", "ps")
arrow([(480, 600), (560, 607)], "")
arrow([(765, 607), (790, 607)], "")
arrow([(662, 642), (662, 683), (790, 683)], "")
arrow([(995, 607), (1020, 607)], "")
arrow([(1225, 607), (1250, 607)], "")
arrow([(1455, 607), (1480, 607)], "")
arrow([(1455, 683), (1700, 683), (1700, 900)], "BigQuery subscriptions", lx=1694, ly=860, anchor="end")
parts.append(f'<text x="1028" y="700" font-size="11" fill="{C["muted"]}">deterministic checks: running balance,</text>')
parts.append(f'<text x="1028" y="714" font-size="11" fill="{C["muted"]}">Verhoeff (Aadhaar), salary maths, expiry</text>')
badge(560, 572, 3)

# ------------------------------------------------------------------ lane 4: copilot
lane(739, 140, "4 · Compliance & investigation copilot")
cp = cbox(1, 772, 70, "Compliance Copilot", "Cloud Run · injection guard\nPII masking · audited tools")
vs = cbox(2, 772, 70, "Vertex AI Search", "bank policies, RBI circulars\n(no customer data)", "ai")
gm3 = cbox(3, 772, 70, "Gemini function calling", "grounded answers\nwith citations", "ai")
arrow([(480, 700), (520, 700), (520, 807), (560, 807)], "")
arrow([(765, 800), (790, 800)], "")
arrow([(790, 815), (765, 815)], "")
arrow([(995, 807), (1020, 807)], "")
badge(560, 772, 4)

# ------------------------------------------------------------------ data band
lane(891, 110, "Data & MLOps")
sql = cbox(2, 920, 66, "Cloud SQL PostgreSQL", "HA · private IP · IAM auth\nhash-chained audit log", "data")
bq = cbox(4, 920, 66, "BigQuery", "decisions · labels · docs\npolicy-tag column security", "data")
tr = cbox(5, 920, 66, "Vertex AI training", "out-of-time eval · gate\nmodel registry · canary", "ai")
lbl = cbox(3, 920, 66, "Training view", "served features + labels\n(no training/serving skew)", "data")
# Case Service -> Cloud SQL (doc-intel and copilot also use it)
arrow([(892, 455), (892, 470), (540, 470), (540, 960), (790, 960)], "")
arrow([(1250, 953), (1225, 953)], "")
arrow([(1455, 953), (1480, 953)], "")
arrow([(1495, 920), (1495, 880), (1467, 880), (1467, 245), (1510, 245), (1510, 232)], "deploy", lx=1462, ly=520, anchor="end")

# ------------------------------------------------------------------ security band
parts.append(f'<text x="545" y="1030" font-size="11.5" font-weight="700" fill="{C["muted"]}" letter-spacing="0.6">SECURITY &amp; OPERATIONS (CROSS-CUTTING)</text>')
chips = ["Cloud KMS (CMEK, HSM, 90-day rotation)", "Secret Manager (per-secret IAM)", "Audit Logs → WORM bucket (5 yrs)",
         "Cloud Monitoring alerts & SLOs", "Artifact Registry + Binary Authorization", "Cloud Build: tests, SAST, CVE gate"]
for i, chip in enumerate(chips):
    w, x, y = 380, 545 + (i % 3) * 393, 1042 + (i // 3) * 40
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="30" rx="15" fill="{C["sec"]}" stroke="{C["sec_s"]}"/>')
    parts.append(f'<text x="{x + w / 2}" y="{y + 19}" text-anchor="middle" font-size="12" fill="{C["ink"]}">{esc(chip)}</text>')

# ------------------------------------------------------------------ legend
legend = [("run", "Cloud Run service"), ("ps", "Pub/Sub topic (+ dead-letter)"), ("ai", "Google AI service"),
          ("data", "Data store"), ("sec", "Security control"), ("edge", "External actor")]
ly = 760
parts.append(f'<text x="30" y="{ly}" font-size="12" font-weight="700" fill="{C["ink"]}">Legend</text>')
for i, (k, t) in enumerate(legend):
    yy = ly + 14 + i * 24
    parts.append(f'<rect x="30" y="{yy}" width="22" height="16" rx="4" fill="{C[k]}" stroke="{C[k + "_s"]}"/>'
                 f'<text x="60" y="{yy + 12}" font-size="12" fill="{C["ink"]}">{t}</text>')
parts.append(f'<path d="M30 {ly + 168} L 70 {ly + 168}" stroke="{C["edge_s"]}" stroke-width="1.6" stroke-dasharray="6 4" marker-end="url(#arrow)"/>'
             f'<text x="80" y="{ly + 172}" font-size="12" fill="{C["ink"]}">synchronous call</text>')
notes = ["Numbered badges = the four capabilities.", "Gemini explains and extracts; decisions",
         "come from rules + the calibrated model,", "and analysts close cases (four-eyes)."]
for i, n in enumerate(notes):
    parts.append(f'<text x="30" y="{ly + 205 + i * 16}" font-size="11.5" fill="{C["muted"]}">{esc(n)}</text>')

svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
       f'font-family="Inter, DejaVu Sans, Arial, sans-serif">'
       '<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
       f'<path d="M0 0 L10 5 L0 10 z" fill="{C["edge_s"]}"/></marker></defs>'
       + "".join(under) + "".join(parts) + "</svg>")
(OUT / "architecture.svg").write_text(svg)
try:
    import cairosvg

    cairosvg.svg2png(bytestring=svg.encode(), write_to=str(OUT / "architecture.png"), output_width=W * 2)
    print("wrote docs/architecture.svg and docs/architecture.png")
except ImportError:
    print("wrote docs/architecture.svg (pip install cairosvg for PNG)")
